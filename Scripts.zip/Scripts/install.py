'''
PLEASE DO NOT REPRODUCE OR DISTRIBUTE
NOT FOR COMMERCIAL USE

#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#With assistance from BCIT
'''
import maya.cmds as cmds
import maya.mel as mel
from functools import partial
import os
import shutil

#********************************************INSTALLING*********************************************


#if you drop file into window you need this function
def onMayaDroppedPythonFile(*args, **kwargs):
    install()
    pass
    #Script By Tyler
    #installs the Tool
def install():
    #get paths
    scriptsPath = cmds.internalVar(userScriptDir = True)
    baseIconsDir = "%sHDMAR_scripts/Icons/"%scriptsPath
    srcPath = os.path.join(os.path.dirname(__file__), "src")
    srcPath = os.path.normpath(srcPath)[:-4]
    #if already installed, delete
    if os.path.exists("%sHDMAR_scripts"%scriptsPath):
      shutil.rmtree("%sHDMAR_scripts"%scriptsPath)
    #we would move the files to the scripts folder. srcPath > scriptsPath
    src = "%s/HDMAR_scripts"%srcPath
    des = "%sHDMAR_scripts"%scriptsPath
    shutil.copytree(src, des)
    #refresh the scripts folder
    mel.eval("rehash;")
    #Get tool bar
    shelf = mel.eval("$gShelfTopLevel=$gShelfTopLevel")
    #current tab
    parent = cmds.tabLayout(shelf, query = True, selectTab = True)
    childs = cmds.layout(parent, query = True, childArray = True)
    if childs:
        for i in childs:
            if "HDMAR" == cmds.shelfButton(i, query = True, label = True):
                cmds.deleteUI(i)
    #get this script as string
    command = ""
    with open("%s/install.py"%srcPath) as fileObject:
        lines = fileObject.readlines()
    for line in lines:
        command += line
    #create toolbar button
    cmds.shelfButton(label = "HDMAR", 
        annotation = "Heavy Duty Machine Auto-Rigger (HDMAR) Project", 
        sourceType = "Python", 
        image1 = "%stoolbar_icon.png"%baseIconsDir,
        parent = parent, 
        command = command)

#********************************************ANIMATION_CURVES*********************************************

class Curves_control():
    #Script By windy
    #creates curves for the Hook (boom, arm, bucket) (the user will animate with)
    class Arm_control():
        def create(self):
            #create circle
            circleInner = cmds.circle(name = "Arm", 
                normalX = 1, 
                normalY = 0, 
                normalZ = 0, 
                radius = 2.2)
            circleOutter = cmds.circle(name = "Arm", 
                normalX = 1, 
                normalY = 0, 
                normalZ = 0, 
                radius = 2.2*1.1)
            # create text
            innerText1 = cmds.textCurves(name = "arm", font = "Calibri", text = "Arm")
            cmds.rotate(0, 90, 0, relative = True)
            cmds.CenterPivot()
            innerText2 = cmds.textCurves(name = "rotator", font = "Calibri", text = "Rotator")
            cmds.rotate(0, 90, 0, relative = True)
            cmds.CenterPivot()
            cmds.matchTransform(innerText1, innerText2, circleInner, position = True)
            cmds.setAttr("armShape.ty", 0.3)
            cmds.setAttr("rotatorShape.ty", -0.7)
            cmds.delete(innerText1[1], innerText2[1]) 
            #freeze transforms
            cmds.makeIdentity(innerText1[0], innerText2[0], apply = True)
            #get shapes
            textCurves1 = cmds.listRelatives(innerText1[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            textCurves2 = cmds.listRelatives(innerText2[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            circleCurvesInner = cmds.listRelatives(circleInner[0], shapes = True, fullPath = True)
            circleCurvesOutter = cmds.listRelatives(circleOutter[0], shapes = True, fullPath = True)
            #combine texts
            ctrlGrp = cmds.group(name = "control", world = True, empty = True)
            cmds.parent(textCurves1, textCurves2, circleCurvesInner, circleCurvesOutter, ctrlGrp, 
                shape = True, relative = True)                    
            cmds.delete(circleInner, circleOutter, innerText1[0], innerText2[0])
            
            for curve in cmds.listRelatives(ctrlGrp, allDescendents = True, type = "nurbsCurve", fullPath = True):
                cmds.setAttr("%s.overrideEnabled"%curve, 1)
                cmds.setAttr("%s.overrideColor"%curve, 14)
            
            cmds.select(clear = True)
            return ctrlGrp

    #Script By windy
    #creates curves for the Hook (boom, arm, bucket) (the user will animate with)
    class Boom_control():
        def create(self):
            #create circle
            circleInner = cmds.circle(name = "Boom", 
                normalX = 1, 
                normalY = 0, 
                normalZ = 0, 
                radius = 2.2)
            circleOutter = cmds.circle(name = "Boom", 
                normalX = 1, 
                normalY = 0, 
                normalZ = 0, 
                radius = 2.2*1.1)
            # create text
            innerText1 = cmds.textCurves(name = "Boom", 
                font = "Calibri", 
                text = "Boom")
            cmds.rotate(0, 90, 0, relative = True)
            cmds.CenterPivot()
            innerText2 = cmds.textCurves(name = "rotator", font = "Calibri", text = "Rotator")
            cmds.rotate(0, 90, 0, relative = True)
            cmds.CenterPivot()
            cmds.matchTransform(innerText1, innerText2, circleInner, position = True)
            cmds.setAttr("BoomShape.ty", 0.3)
            cmds.setAttr("rotatorShape.ty", -0.7)
            cmds.delete(innerText1[1], innerText2[1]) 
            #freeze transforms
            cmds.makeIdentity(innerText1[0], innerText2[0], apply = True)
            #get shapes
            textCurves1 = cmds.listRelatives(innerText1[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            textCurves2 = cmds.listRelatives(innerText2[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            circleCurvesInner = cmds.listRelatives(circleInner[0], shapes = True, fullPath = True)
            circleCurvesOutter = cmds.listRelatives(circleOutter[0], shapes = True, fullPath = True)
            #combine texts
            ctrlGrp = cmds.group(name = "control", world = True, empty = True)
            cmds.parent(textCurves1, textCurves2, circleCurvesInner, circleCurvesOutter, ctrlGrp, 
                shape = True, relative = True)                    
            cmds.delete(circleInner, circleOutter, innerText1[0], innerText2[0])
            
            for curve in cmds.listRelatives(ctrlGrp, allDescendents = True, type = "nurbsCurve", fullPath = True):
                cmds.setAttr("%s.overrideEnabled"%curve, 1)
                cmds.setAttr("%s.overrideColor"%curve, 14)
            
            cmds.select(clear = True)
            return ctrlGrp

    #Script By windy
    #creates curves for the Hook (boom, Boom, bucket) (the user will animate with)
    class Bucket_control():
        def create(self):
            #create circle
            circleInner = cmds.circle( name = "Bucket", normalX = 1, normalY = 0, normalZ = 0, radius = 2.2)
            circleOutter = cmds.circle( name = "Bucket", normalX = 1, normalY = 0, normalZ = 0, radius = 2.2*1.1)
            # create text
            innerText1 = cmds.textCurves(name = "Bucket", font = "Calibri", text = "Bucket")
            cmds.rotate(0, 90, 0, relative = True)
            cmds.CenterPivot()
            innerText2 = cmds.textCurves(name = "rotator", font = "Calibri", text = "Rotator")
            cmds.rotate(0, 90, 0, relative = True)
            cmds.CenterPivot()
            cmds.matchTransform(innerText1, innerText2, circleInner, position = True)
            cmds.setAttr("BucketShape.ty", 0.3)
            cmds.setAttr("rotatorShape.ty", -0.7)
            cmds.delete(innerText1[1], innerText2[1]) 
            #freeze transforms
            cmds.makeIdentity(innerText1[0], innerText2[0], apply = True)
            #get shapes
            textCurves1 = cmds.listRelatives(innerText1[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            textCurves2 = cmds.listRelatives(innerText2[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            circleCurvesInner = cmds.listRelatives(circleInner[0], shapes = True, fullPath = True)
            circleCurvesOutter = cmds.listRelatives(circleOutter[0], shapes = True, fullPath = True)
            #combine texts
            ctrlGrp = cmds.group(name = "control", world = True, empty = True)
            cmds.parent(textCurves1, textCurves2, circleCurvesInner, circleCurvesOutter, ctrlGrp, 
                shape = True, relative = True)  
                                  
            cmds.delete(circleInner, circleOutter, innerText1[0], innerText2[0])
            
            for curve in cmds.listRelatives(ctrlGrp, allDescendents = True, type = "nurbsCurve", fullPath = True):
                cmds.setAttr("%s.overrideEnabled"%curve, 1)
                cmds.setAttr("%s.overrideColor"%curve, 14)
            
            cmds.select(clear = True)
            return ctrlGrp

    #Script By Tyler Millossi
    #creates curves for the door (the user will animate with)
    class Door_control():
        def create(self):
            curve1 = cmds.curve(degree = 1, 
                point = [(0.07257, 0, -0.0546559), 
                (0.0525062, 0, -0.0632546),
                (0.0338755, 0, -0.0783025), 
                (0.0245602, 0, -0.0969331 ),
                (0.0202608, 0, -0.11628), 
                (0.0173946, 0, -0.490326 ),
                (0.0238436, 0, -0.507524), 
                (0.28324, 0, -0.834993 ),
                (0.321217, 0, -0.869388 ),
                (0.364928, 0, -0.899484 ),
                (0.42082, 0, -0.923847), 
                (0.470979, 0, -0.938895 ),
                (0.493909, 0, -0.938178 ),
                (0.940328, 0, -0.943194 ),
                (0.963258, 0, -0.934596 ),
                (0.969707, 0, -0.92528 ),
                (0.980456, 0, -0.905217), 
                (0.984039, 0, -0.112698 ),
                (0.97329, 0, -0.0912006), 
                (0.961109, 0, -0.0711368 ),
                (0.928863, 0, -0.056089 ),
                (0.0732865, 0, -0.0553724)])
            curve2 = cmds.curve(degree = 1, 
                point = [(0.163715, 0, -0.529656), 
                (0.888882, 0, -0.530775), 
                (0.886644, 0, -0.846357), 
                (0.491607, 0, -0.845238 ),
                (0.443486, 0, -0.834047 ),
                (0.396485, 0, -0.813903 ),
                (0.355079, 0, -0.774735 ),
                (0.164834, 0, -0.528537)])
            
            curve3 = cmds.curve(degree = 1, 
                point = [(0.727948, 0, -0.395639), 
                (0.841246, 0, -0.394475 ),
                (0.849783, 0, -0.398743 ),
                (0.857155, 0, -0.407667 ),
                (0.857543, 0, -0.425903 ),
                (0.852499, 0, -0.433275 ),
                (0.844351, 0, -0.437932), 
                (0.730664, 0, -0.44026), 
                (0.718636, 0, -0.434439), 
                (0.713204, 0, -0.424739 ),
                (0.713204, 0, -0.412323), 
                (0.718248, 0, -0.403011), 
                (0.727948, 0, -0.395251)])

            curve4 = cmds.curve(degree = 1, point = [
                (0.557497, 0, -0.560445 ),
                (0.595828, 0, -0.55848 ),
                (0.757998, 0, -0.8209 ),
                (0.715735, 0, -0.8209 ),
                (0.556514, 0, -0.55848 ),])

            curve5 = cmds.curve(degree = 1, point = [
                (0.629245, 0, -0.55848 ),
                (0.691164, 0, -0.556514 ),
                (0.851369, 0, -0.819917 ),
                (0.785518, 0, -0.8209 ),
                (0.628262, 0, -0.559462),])
                
            group = cmds.group(name = "control", world = True, empty = True)
            allCurves = [curve1, curve2, curve3, curve4, curve5]
            i = 1
            for curve in allCurves:
                shape = cmds.listRelatives(curve, shapes = True)
                cmds.select(shape, group)
                cmds.parent(relative = True, shape = True) 
                cmds.rename(shape[0], "control_shp%s"%i)#maybe not needed
                i += 1
            cmds.delete(allCurves)
            
            for curve in cmds.listRelatives(group, allDescendents = True, type = "nurbsCurve", fullPath = True):
                cmds.setAttr("%s.overrideEnabled"%curve, 1)
                cmds.setAttr("%s.overrideColor"%curve, 9)
                
                
            cmds.move(0, 0, -0.5, "%s.scalePivot"%group, "%s.rotatePivot"%group, absolute=True)
            cmds.select(group)
            cmds.move(0, 0, 0.5)
            cmds.makeIdentity(apply = True)
            cmds.DeleteHistory()
            cmds.select(clear = True)
            
            return group

    #Script By windy
    #creates curves for the Main/leftTrack (the user will animate with)
    class LeftTrack_control():
        def create(self):
            # create arrow
            arrowShape = cmds.curve( name= "arrow", degree = 1, point = [
                (0, 1, -5),
                (0, 2, -5),
                (0, 0, -7),
                (0, -2, -5),
                (0, -1, -5),
                (0, -1, 5),
                (0, -2, 5),
                (0, 0, 7),
                (0, 2, 5),
                (0, 1, 5),
                (0, 1, -5)] )
                
            arrowShape2 = cmds.curve( name= "arrow", degree = 1, point = [
                (0, 0.85, -5.15),
                (0, 1.7, -5.15),
                (0, 0, -6.85),
                (0, -1.7, -5.15),
                (0, -0.85, -5.15),
                (0, -0.85, 5.15),
                (0, -1.7, 5.15),
                (0, 0, 6.85),
                (0, 1.7, 5.15),
                (0, 0.85, 5.15),
                (0, 0.85, -5.15)] )

            # create text 
            innerText1 = cmds.textCurves(name = "Track", font = "Calibri", text = "Left Track Ctrl")
            cmds.rotate(0, -90, 0, relative = True)
            cmds.scale(1.9, 1.9, 1.9, relative = True)
            cmds.CenterPivot()        
            # match transform to circle
            cmds.matchTransform(innerText1 , arrowShape , position = True)              
            # delete makeTextCurve
            cmds.delete(innerText1[1])        
            # freeze rotation
            cmds.makeIdentity(innerText1[0], apply = True)       

            #get shapes
            textCurves1 = cmds.listRelatives(innerText1[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            arrowCurve = cmds.listRelatives(arrowShape, shapes = True )
            arrowCurve2 = cmds.listRelatives(arrowShape2, shapes = True )
            
            #combine curves
            ctrlGrp = cmds.group(name = "control", world = True, empty = True)
            cmds.parent( textCurves1, arrowCurve, arrowCurve2, ctrlGrp, shape = True, relative = True)                    
            cmds.delete( innerText1[0], arrowShape, arrowShape2)

            for curve in cmds.listRelatives(ctrlGrp, allDescendents = True, type = "nurbsCurve", fullPath = True):
                cmds.setAttr("%s.overrideEnabled"%curve, 1)
                cmds.setAttr("%s.overrideColor"%curve, 13)
            
            cmds.DeleteHistory()
            cmds.select(clear = True)
            return ctrlGrp

    #Script By windy
    #creates curves for the Hook (boom, arm, bucket) (the user will animate with)
    class Hook_control():
        def create(self):
            #create circle
            circleInner = cmds.circle( name = "Hook", normalX = 1, normalY = 0, normalZ = 0, radius = 2.2)
            circleOutter = cmds.circle( name = "Hook", normalX = 1, normalY = 0, normalZ = 0, radius = 2.2*1.1)
            # create text
            innerText1 = cmds.textCurves(name = "Hook", font = "Calibri", text = "Hook")
            cmds.rotate(0, 90, 0, relative = True)
            cmds.CenterPivot()
            innerText2 = cmds.textCurves(name = "rotator", font = "Calibri", text = "Control")
            cmds.rotate(0, 90, 0, relative = True)
            cmds.CenterPivot()
            cmds.matchTransform(innerText1, innerText2, circleInner, position = True)
            cmds.setAttr("HookShape.ty", 0.3)
            cmds.setAttr("rotatorShape.ty", -0.7)
            cmds.delete(innerText1[1], innerText2[1]) 
            #freeze transforms
            cmds.makeIdentity(innerText1[0], innerText2[0], apply = True)
            #get shapes
            textCurves1 = cmds.listRelatives(innerText1[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            textCurves2 = cmds.listRelatives(innerText2[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            circleCurvesInner = cmds.listRelatives(circleInner[0], 
                shapes = True, 
                fullPath = True)
            circleCurvesOutter = cmds.listRelatives(circleOutter[0], shapes = True, fullPath = True)
            #combine texts
            ctrlGrp = cmds.group(name = "control", world = True, empty = True)
            cmds.parent(textCurves1, textCurves2, circleCurvesInner, circleCurvesOutter, ctrlGrp, 
                shape = True, relative = True)                    
            cmds.delete(circleInner, circleOutter, innerText1[0], innerText2[0])
            
            for curve in cmds.listRelatives(ctrlGrp, allDescendents = True, type = "nurbsCurve", fullPath = True):
                cmds.setAttr("%s.overrideEnabled"%curve, 1)
                cmds.setAttr("%s.overrideColor"%curve, 18)
            
            cmds.select(clear = True)
            return ctrlGrp

    #Script By windy
    #creates curves for the lowerBody (the user will animate with)
    class LowerBody_control():
        def create(self):
            #create 2 circles
            circleInner = cmds.circle( name = "lowerBody", normalX = 0, normalY = 1, normalZ = 0, radius = 15)
            circleOutter = cmds.circle( name = "lowerBody", normalX = 0, normalY = 1, normalZ = 0, radius = 15.3)

            # create text 1
            innerText1 = cmds.textCurves(name = "lowerBody", font = "Calibri", text = "LowerBody Control")
            cmds.rotate(-90, -90, 0, relative = True)
            cmds.scale(2, 2, 2, relative = True)
            cmds.CenterPivot()
            # create text 2
            innerText2 = cmds.textCurves(name = "lowerBody", font = "Calibri", text = "LowerBody Control")
            cmds.rotate(-90, 90, 0, relative = True)
            cmds.scale(2, 2, 2, relative = True)
            cmds.CenterPivot()        

            # match transform to circle
            cmds.matchTransform(innerText1, innerText2 ,circleInner, position = True)
            
            # transform texts
            cmds.move(-12, 0, 0, innerText1, relative = True)
            cmds.move(12, 0, 0, innerText2, relative = True)
            
            # delete makeTextCurve
            cmds.delete(innerText1[1], innerText2[1])
            
            # freeze rotation
            cmds.makeIdentity(innerText1[0], innerText2[0], apply = True)       

            #get shapes
            textCurves1 = cmds.listRelatives(innerText1[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            textCurves2 = cmds.listRelatives(innerText2[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            circleCurvesInner = cmds.listRelatives(circleInner[0], shapes = True, fullPath = True)
            circleCurvesOutter = cmds.listRelatives(circleOutter[0], shapes = True, fullPath = True)
            
            #combine texts
            ctrlGrp = cmds.group(name = "control", world = True, empty = True)
            cmds.parent(textCurves1, textCurves2, circleCurvesInner, circleCurvesOutter, ctrlGrp, 
                shape = True, relative = True)                    
            cmds.delete(circleInner, circleOutter, innerText1[0], innerText2[0])
            

            for curve in cmds.listRelatives(ctrlGrp, allDescendents = True, type = "nurbsCurve", fullPath = True):

                cmds.setAttr("%s.overrideEnabled"%curve, 1)
                cmds.setAttr("%s.overrideColor"%curve, 18)
            
            cmds.select(clear = True)
            return ctrlGrp

    #Script By windy
    #creates curves for the Main/Root (the user will animate with)
    class Main_control():
        def create(self):
            #create 2 circles
            circleInner = cmds.circle( name = "Main", normal=(0,1,0), radius = 19.7)
            circleOutter = cmds.circle( name = "Main", normal=(0,1,0), radius = 21)

            # create arrow
            arrowShape = cmds.curve( name= "arrow", degree = 3, point = [
                (-5, 0, -19),
                (-4.222222, 0, -21.230769),
                (-2.666667, 0, -25.692308),
                (-14.333333, 0, -22.230769),
                (0, 0, -29.384615),
                (14.333333, 0, -22.230769),
                (2.666667, 0, -25.692308),
                (4.222222, 0, -21.230769),
                (5, 0, -19)] )

            # create text 1
            innerText1 = cmds.textCurves(name = "Main", font = "Calibri", text = "Main")
            cmds.rotate(-90, 0, 0, relative = True)
            cmds.scale(3, 3, 3, relative = True)
            cmds.CenterPivot()        
            # create text 2
            innerText2 = cmds.textCurves(name = "Main", font = "Calibri", text = "Ctrl")
            cmds.rotate(-90, 0, 0, relative = True)
            cmds.scale(3, 3, 3, relative = True)
            cmds.CenterPivot()        
            # match transform to circle
            cmds.matchTransform(innerText1, innerText2 ,circleInner, position = True)        
            # transform texts
            cmds.move(0, 0, -25, innerText1, relative = True)
            cmds.move(0, 0, -22.5, innerText2, relative = True)        
            # delete makeTextCurve
            cmds.delete(innerText1[1], innerText2[1])        
            # freeze rotation
            cmds.makeIdentity(innerText1[0], innerText2[0], apply = True)       

            #get shapes
            textCurves1 = cmds.listRelatives(innerText1[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            textCurves2 = cmds.listRelatives(innerText2[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            circleCurvesInner = cmds.listRelatives(circleInner[0], shapes = True, fullPath = True)
            circleCurvesOutter = cmds.listRelatives(circleOutter[0], shapes = True, fullPath = True)
            arrowCurve = cmds.listRelatives(arrowShape, shapes = True )
            
            #combine curves
            ctrlGrp = cmds.group(name = "control", world = True, empty = True)
            cmds.parent(textCurves1, textCurves2, circleCurvesInner, circleCurvesOutter, arrowCurve, ctrlGrp, 
                shape = True, relative = True)                    
            cmds.delete(circleInner, circleOutter, arrowShape, innerText1[0], innerText2[0])

            for curve in cmds.listRelatives(ctrlGrp, allDescendents = True, type = "nurbsCurve", fullPath = True):
                cmds.setAttr("%s.overrideEnabled"%curve, 1)
                cmds.setAttr("%s.overrideColor"%curve, 6)
            # ??? this loop can only work for once
            
            cmds.DeleteHistory()
            cmds.select(clear = True)
            return ctrlGrp

    #Script By windy
    #creates curves for the Main/right track (the user will animate with)
    class RightTrack_control():
        def create(self):
            # create arrow
            arrowShape = cmds.curve( name= "arrow", degree = 1, point = [
                (0, 1, -5),
                (0, 2, -5),
                (0, 0, -7),
                (0, -2, -5),
                (0, -1, -5),
                (0, -1, 5),
                (0, -2, 5),
                (0, 0, 7),
                (0, 2, 5),
                (0, 1, 5),
                (0, 1, -5)] )
                
            arrowShape2 = cmds.curve( name= "arrow", degree = 1, point = [
                (0, 0.85, -5.15),
                (0, 1.7, -5.15),
                (0, 0, -6.85),
                (0, -1.7, -5.15),
                (0, -0.85, -5.15),
                (0, -0.85, 5.15),
                (0, -1.7, 5.15),
                (0, 0, 6.85),
                (0, 1.7, 5.15),
                (0, 0.85, 5.15),
                (0, 0.85, -5.15)] )

            # create text 
            innerText1 = cmds.textCurves(name = "Track", font = "Calibri", text = "Right Track Ctrl")
            cmds.rotate(0, 90, 0, relative = True)
            cmds.scale(1.75, 1.75, 1.75, relative = True)
            cmds.CenterPivot()        
            # match transform to circle
            cmds.matchTransform(innerText1 , arrowShape , position = True)              
            # delete makeTextCurve
            cmds.delete(innerText1[1])        
            # freeze rotation
            cmds.makeIdentity(innerText1[0], apply = True)       

            #get shapes
            textCurves1 = cmds.listRelatives(innerText1[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            arrowCurve = cmds.listRelatives(arrowShape, shapes = True )
            arrowCurve2 = cmds.listRelatives(arrowShape2, shapes = True )
            
            #combine curves
            ctrlGrp = cmds.group(name = "control", world = True, empty = True)
            cmds.parent( textCurves1, arrowCurve, arrowCurve2, ctrlGrp, shape = True, relative = True)                    
            cmds.delete( innerText1[0], arrowShape, arrowShape2)

            for curve in cmds.listRelatives(ctrlGrp, allDescendents = True, type = "nurbsCurve", fullPath = True):
                cmds.setAttr("%s.overrideEnabled"%curve, 1)
                cmds.setAttr("%s.overrideColor"%curve, 13)
            
            cmds.DeleteHistory()
            cmds.select(clear = True)
            return ctrlGrp

    #Script By windy
    #creates curves for the Main/Root (the user will animate with)
    class Root_control():
        def create(self):
            # create arrow
            arrowShape = cmds.curve( name= "arrow", degree = 1, point = [
                (0, 0, -5),
                (-2, 0, -3),
                (-1, 0, -3),
                (-1, 0, -1),
                (-3, 0, -1),
                (-3, 0, -2),
                (-5, 0, 0),
                (-3, 0, 2),
                (-3, 0, 1),
                (-1, 0, 1),
                (-1, 0, 3),
                (-2, 0, 3),
                (0, 0, 5),
                (2, 0, 3),
                (1, 0, 3),
                (1, 0, 1),
                (3, 0, 1),
                (3, 0, 2),
                (5, 0, 0),
                (3, 0, -2),
                (3, 0, -1),
                (1, 0, -1),
                (1, 0, -3),
                (2, 0, -3),
                (0, 0, -5)] )

            # create text 
            innerText1 = cmds.textCurves(name = "Root", font = "Calibri", text = "Move Control")
            cmds.rotate(-90, 0, 0, relative = True)
            cmds.scale(1.5, 1.5, 1.5, relative = True)
            cmds.CenterPivot()        
            # match transform to circle
            cmds.matchTransform(innerText1 , arrowShape , position = True)              
            # delete makeTextCurve
            cmds.delete(innerText1[1])        
            # freeze rotation
            cmds.makeIdentity(innerText1[0], apply = True)       

            #get shapes
            textCurves1 = cmds.listRelatives(innerText1[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            arrowCurve = cmds.listRelatives(arrowShape, shapes = True )
            
            #combine curves
            ctrlGrp = cmds.group(name = "control", world = True, empty = True)
            cmds.parent( textCurves1, arrowCurve, ctrlGrp, shape = True, relative = True)                    
            cmds.delete( innerText1[0], arrowShape)

            for curve in cmds.listRelatives(ctrlGrp, allDescendents = True, type = "nurbsCurve", fullPath = True):
                cmds.setAttr("%s.overrideEnabled"%curve, 1)
                cmds.setAttr("%s.overrideColor"%curve, 18)
            
            
            cmds.DeleteHistory()
            cmds.select(clear = True)
            return ctrlGrp

    #Script By windy
    #creates curves for the Steer (the user will animate with)
    class Steering_control():
        def create(self):
            #create 2 circles
            circleInner = cmds.circle( name = "Steer", normalX = 0, normalY = 1, normalZ = 0, radius = 1)
            circleOutter = cmds.circle( name = "Steer", normalX = 0, normalY = 1, normalZ = 0, radius = 1.1)

            # create text 1
            innerText1 = cmds.textCurves(name = "Steer", font = "Calibri", text = "L")
            cmds.rotate(-90, 0, 0, relative = True)
            cmds.CenterPivot()
            # create text 2
            innerText2 = cmds.textCurves(name = "Steer", font = "Calibri", text = "R")
            cmds.rotate(-90, 0, 0, relative = True)
            cmds.CenterPivot()        

            # match transform to circle
            cmds.matchTransform(innerText1, innerText2 ,circleInner, position = True)
            
            # transform texts
            cmds.move(-0.6, 0, 0, innerText1, relative = True)
            cmds.move(0.6, 0, 0, innerText2, relative = True)
            
            # delete makeTextCurve
            cmds.delete(innerText1[1], innerText2[1])
            
            # freeze rotation
            cmds.makeIdentity(innerText1[0], innerText2[0], apply = True)       

            #get shapes
            textCurves1 = cmds.listRelatives(innerText1[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            textCurves2 = cmds.listRelatives(innerText2[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            circleCurvesInner = cmds.listRelatives(circleInner[0], shapes = True, fullPath = True)
            circleCurvesOutter = cmds.listRelatives(circleOutter[0], shapes = True, fullPath = True)
            
            #combine texts
            ctrlGrp = cmds.group(name = "control", world = True, empty = True)
            cmds.parent(textCurves1, textCurves2, circleCurvesInner, circleCurvesOutter, ctrlGrp, 
                shape = True, relative = True)                    
            cmds.delete(circleInner, circleOutter, innerText1[0], innerText2[0])

            for curve in cmds.listRelatives(ctrlGrp, allDescendents = True, type = "nurbsCurve", fullPath = True):
                cmds.setAttr("%s.overrideEnabled"%curve, 1)
                cmds.setAttr("%s.overrideColor"%curve, 9)
            
            cmds.select(clear = True)
            return ctrlGrp

    #Script By windy
    #creates curves for the Main/upperBody (the user will animate with)
    class UpperBody_control():
        def create(self):
            # create arrow
            arrowShape = cmds.curve( name= "arrow", degree = 1, point = [
                (0, 1, -5),
                (0, 2, -5),
                (0, 0, -7),
                (0, -2, -5),
                (0, -1, -5),
                (0, -1, 5),
                (0, -2, 5),
                (0, 0, 7),
                (0, 2, 5),
                (0, 1, 5),
                (0, 1, -5)] )
                
            arrowShape2 = cmds.curve( name= "arrow", degree = 1, point = [
                (0, 0.85, -5.15),
                (0, 1.7, -5.15),
                (0, 0, -6.85),
                (0, -1.7, -5.15),
                (0, -0.85, -5.15),
                (0, -0.85, 5.15),
                (0, -1.7, 5.15),
                (0, 0, 6.85),
                (0, 1.7, 5.15),
                (0, 0.85, 5.15),
                (0, 0.85, -5.15)] )

            # create text 
            innerText1 = cmds.textCurves(name = "upperBody", font = "Calibri", text = "UpperBody Rotation")
            cmds.rotate(0, -90, 0, relative = True)
            cmds.scale(1.4, 1.4, 1.4, relative = True)
            cmds.CenterPivot()        
            # match transform to circle
            cmds.matchTransform(innerText1 , arrowShape , position = True)              
            # delete makeTextCurve
            cmds.delete(innerText1[1])        
            # freeze rotation
            cmds.makeIdentity(innerText1[0], apply = True)       

            #get shapes
            textCurves1 = cmds.listRelatives(innerText1[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            arrowCurve = cmds.listRelatives(arrowShape, shapes = True )
            arrowCurve2 = cmds.listRelatives(arrowShape2, shapes = True )
            
            #combine curves
            ctrlGrp = cmds.group(name = "control", world = True, empty = True)
            cmds.parent( textCurves1, arrowCurve, arrowCurve2, ctrlGrp, shape = True, relative = True)                    
            cmds.delete( innerText1[0], arrowShape, arrowShape2)

            for curve in cmds.listRelatives(ctrlGrp, allDescendents = True, type = "nurbsCurve", fullPath = True):
                cmds.setAttr("%s.overrideEnabled"%curve, 1)
                cmds.setAttr("%s.overrideColor"%curve, 18)

            
            # rotate
            cmds.rotate(0,90,0)
            cmds.makeIdentity( apply=True, rotate=True)
            
            cmds.DeleteHistory()
            cmds.select(clear = True)
            return ctrlGrp


    #coming soon...maybe
    class Wheel_control():
        def create(self):
            pass
                      
#********************************************PLACEHOLDERS_CURVES*********************************************

class Curves_placeHolders():

    #Script By windy
    #creates shapes for a Hook (Boom, arm, bucket) (the user will position to model for getting placement)
    class Arm_placeHolder():
        def create(self):
            
            #create text
            innerText = cmds.textCurves(name = "ArmLoc", font = "Calibri", text = "Arm Locator")   
            cmds.scale(0.2, 0.2, 0.2, relative = True)
            cmds.rotate(0, 90, 0, relative = True)
            cmds.CenterPivot()
            
            cmds.delete(innerText[1])         
            #freeze transforms
            cmds.makeIdentity(innerText[0], apply = True)
            #get shapes
            textCurves = cmds.listRelatives(innerText[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)

            #createcube
            cubeShape = cmds.polyCube(name = "cubeShape")
            
            #selectEdges
            cmds.select("cubeShape.e[1]", "cubeShape.e[5]", "cubeShape.e[0]", "cubeShape.e[4]")
            #convert edge to curve
            cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve1")

            cmds.select("cubeShape.e[2]", "cubeShape.e[8]", "cubeShape.e[3]", "cubeShape.e[9]")
            cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve2")

            cmds.select("cubeShape.e[7]")
            cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve3")

            cmds.select("cubeShape.e[11]")
            cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve4")

            cmds.select("cubeShape.e[10]")
            cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve5")

            cmds.select("cubeShape.e[6]")
            cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve6")
            
            #creategroup
            Arm_Loc = cmds.group( em=True, name='Arm_Locator')
            
            #combine curves to group
            cmds.select("ctrlGrpCtrlCurve1Shape", 
                "ctrlGrpCtrlCurve1Shape", 
                "ctrlGrpCtrlCurve2Shape", 
                "ctrlGrpCtrlCurve3Shape", 
                "ctrlGrpCtrlCurve4Shape", 
                "ctrlGrpCtrlCurve5Shape", 
                "ctrlGrpCtrlCurve6Shape", 
                textCurves, 
                Arm_Loc)
            
            cmds.parent(relative = True, shape = True)
            
            #add locatershape in grp
            cmds.spaceLocator(name = "ctrlGrpCtrlLoc1")
            cmds.select("ctrlGrpCtrlLoc1Shape", Arm_Loc)
            cmds.parent(relative = True, shape = True)
            
            #delete Cube and empty groups
            cmds.select(cubeShape, 
                "ctrlGrpCtrlCurve1", 
                "ctrlGrpCtrlCurve2", 
                "ctrlGrpCtrlCurve3", 
                "ctrlGrpCtrlCurve4", 
                "ctrlGrpCtrlCurve5", 
                "ctrlGrpCtrlCurve6", 
                "ctrlGrpCtrlLoc1",
                "ArmLocShape")
            cmds.delete()
            
            #increase Overall Size
            cmds.select(Arm_Loc)
            cmds.scale(2.0, 2.0, 2.0, relative = True)
            cmds.makeIdentity( apply = True, scale = True)
            
            #rename the shape nodes for code reuse
            cmds.select(Arm_Loc)
            ctrlGrpShapes = cmds.ls(sl=True, dag=True, shapes=True)
            for shape in ctrlGrpShapes:
                cmds.rename(shape, "{0}Shape".format(cmds.listRelatives(shape, parent=True)[0]))

            #override color
            for curve in cmds.listRelatives(Arm_Loc, allDescendents = True, type = "nurbsCurve", fullPath = True):
                        cmds.setAttr("%s.overrideEnabled"%curve, 1)
                        cmds.setAttr("%s.overrideColor"%curve, 14)
            
            return Arm_Loc

    #Script By windy
    #creates shapes for a Hook (Boom, arm, bucket) (the user will position to model for getting placement)
    class Boom_placeHolder():
        def create(self):
            #create text
            innerText = cmds.textCurves(name = "BoomLoc", font = "Calibri", text = "Boom Locator")   
            cmds.scale(0.18, 0.18, 0.18, relative = True)
            cmds.rotate(0, 90, 0, relative = True)
            cmds.CenterPivot()
            
            cmds.delete(innerText[1])         
            #freeze transforms
            cmds.makeIdentity(innerText[0], apply = True)
            #get shapes
            textCurves = cmds.listRelatives(innerText[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            
            #createcube
            cubeShape = cmds.polyCube(name = "cubeShape")
            
            #selectEdges
            cmds.select("cubeShape.e[1]", "cubeShape.e[5]", "cubeShape.e[0]", "cubeShape.e[4]")
            #convert edge to curve
            cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve1")

            cmds.select("cubeShape.e[2]", "cubeShape.e[8]", "cubeShape.e[3]", "cubeShape.e[9]")
            cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve2")

            cmds.select("cubeShape.e[7]")
            cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve3")

            cmds.select("cubeShape.e[11]")
            cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve4")

            cmds.select("cubeShape.e[10]")
            cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve5")

            cmds.select("cubeShape.e[6]")
            cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve6")
            
            #creategroup
            Boom_Loc = cmds.group( em=True, name='Boom_Locator')
            
            #combine curves to group
            cmds.select("ctrlGrpCtrlCurve1Shape", 
                "ctrlGrpCtrlCurve1Shape", 
                "ctrlGrpCtrlCurve2Shape", 
                "ctrlGrpCtrlCurve3Shape", 
                "ctrlGrpCtrlCurve4Shape", 
                "ctrlGrpCtrlCurve5Shape", 
                "ctrlGrpCtrlCurve6Shape", 
                textCurves, 
                Boom_Loc)
            
            cmds.parent(relative = True, shape = True)
            
            #add locatershape in grp
            cmds.spaceLocator(name = "ctrlGrpCtrlLoc1")
            cmds.select("ctrlGrpCtrlLoc1Shape", Boom_Loc)
            cmds.parent(relative = True, shape = True)
            
            #delete Cube and empty groups
            cmds.select(cubeShape, 
                "ctrlGrpCtrlCurve1", 
                "ctrlGrpCtrlCurve2", 
                "ctrlGrpCtrlCurve3", 
                "ctrlGrpCtrlCurve4", 
                "ctrlGrpCtrlCurve5", 
                "ctrlGrpCtrlCurve6", 
                "ctrlGrpCtrlLoc1",
                "BoomLocShape")
            cmds.delete()
            
            #increase Overall Size
            cmds.select(Boom_Loc)
            cmds.scale(2.0, 2.0, 2.0, relative = True)
            cmds.makeIdentity( apply = True , scale=True)
            
            #rename the shape nodes for code reuse
            cmds.select(Boom_Loc)
            ctrlGrpShapes = cmds.ls(sl=True, dag=True, shapes=True)
            for shape in ctrlGrpShapes:
                cmds.rename(shape, "{0}Shape".format(cmds.listRelatives(shape, parent=True)[0]))

            #override color
            for curve in cmds.listRelatives(Boom_Loc, allDescendents = True, type = "nurbsCurve", fullPath = True ):
                        cmds.setAttr("%s.overrideEnabled"%curve, 1)
                        cmds.setAttr("%s.overrideColor"%curve, 14)
            
            return Boom_Loc 

    #Script By windy
    #creates shapes for a Hook (Boom, arm, bucket) (the user will position to model for getting placement)
    class Bucket_placeHolder():
        def create(self):
            
            #create text
            innerText = cmds.textCurves(name = "BucketLoc", font = "Calibri", text = "Bucket Locator")   
            cmds.scale(0.17, 0.17, 0.17, relative = True)
            cmds.rotate(0, 90, 0, relative = True)
            cmds.CenterPivot()
            
            cmds.delete(innerText[1])         
            #freeze transforms
            cmds.makeIdentity(innerText[0], apply = True)
            #get shapes
            textCurves = cmds.listRelatives(innerText[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            
            #createcube
            cubeShape = cmds.polyCube(name = "cubeShape")
            
            #selectEdges
            cmds.select("cubeShape.e[1]", "cubeShape.e[5]", "cubeShape.e[0]", "cubeShape.e[4]")
            #convert edge to curve
            cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve1")

            cmds.select("cubeShape.e[2]", "cubeShape.e[8]", "cubeShape.e[3]", "cubeShape.e[9]")
            cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve2")

            cmds.select("cubeShape.e[7]")
            cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve3")

            cmds.select("cubeShape.e[11]")
            cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve4")

            cmds.select("cubeShape.e[10]")
            cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve5")

            cmds.select("cubeShape.e[6]")
            cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve6")
            
            #creategroup
            Bucket_Loc = cmds.group( em=True, name='Bucket_Locator')
            
            #combine curves to group
            cmds.select("ctrlGrpCtrlCurve1Shape", 
                "ctrlGrpCtrlCurve1Shape", 
                "ctrlGrpCtrlCurve2Shape", 
                "ctrlGrpCtrlCurve3Shape", 
                "ctrlGrpCtrlCurve4Shape", 
                "ctrlGrpCtrlCurve5Shape", 
                "ctrlGrpCtrlCurve6Shape", 
                textCurves, 
                Bucket_Loc)
            
            cmds.parent(relative = True, shape = True)
            
            #add locatershape in grp
            cmds.spaceLocator(name = "ctrlGrpCtrlLoc1")
            cmds.select("ctrlGrpCtrlLoc1Shape", Bucket_Loc)
            cmds.parent(relative = True, shape = True)
            
            #delete Cube and empty groups
            cmds.select(cubeShape, 
                "ctrlGrpCtrlCurve1", 
                "ctrlGrpCtrlCurve2", 
                "ctrlGrpCtrlCurve3", 
                "ctrlGrpCtrlCurve4", 
                "ctrlGrpCtrlCurve5", 
                "ctrlGrpCtrlCurve6", 
                "ctrlGrpCtrlLoc1",
                "BucketLocShape")
            cmds.delete()
            
            #increase Overall Size
            cmds.select(Bucket_Loc)
            cmds.scale(2.0, 2.0, 2.0, relative = True)
            cmds.makeIdentity( apply = True, scale = True)
            
            #rename the shape nodes for code reuse
            cmds.select(Bucket_Loc)
            ctrlGrpShapes = cmds.ls(sl=True, dag=True, shapes=True)
            for shape in ctrlGrpShapes:
                cmds.rename(shape, "{0}Shape".format(cmds.listRelatives(shape, parent=True)[0]))

            #override color
            for curve in cmds.listRelatives(Bucket_Loc, allDescendents = True, type = "nurbsCurve", fullPath = True):
                        cmds.setAttr("%s.overrideEnabled"%curve, 1)
                        cmds.setAttr("%s.overrideColor"%curve, 14)
            
            return Bucket_Loc

    #Script By Tyler Millossi
    #creates shapes for a door (the user will position to model for getting placement)
    class Door_placeHolder():
        def create(self):
            curve1 = cmds.curve(degree = 1, 
                point = [(0.07257, 0, -0.0546559), 
                (0.0525062, 0, -0.0632546),
                (0.0338755, 0, -0.0783025), 
                (0.0245602, 0, -0.0969331 ),
                (0.0202608, 0, -0.11628), 
                (0.0173946, 0, -0.490326 ),
                (0.0238436, 0, -0.507524), 
                (0.28324, 0, -0.834993 ),
                (0.321217, 0, -0.869388 ),
                (0.364928, 0, -0.899484 ),
                (0.42082, 0, -0.923847), 
                (0.470979, 0, -0.938895 ),
                (0.493909, 0, -0.938178 ),
                (0.940328, 0, -0.943194 ),
                (0.963258, 0, -0.934596 ),
                (0.969707, 0, -0.92528 ),
                (0.980456, 0, -0.905217), 
                (0.984039, 0, -0.112698 ),
                (0.97329, 0, -0.0912006), 
                (0.961109, 0, -0.0711368 ),
                (0.928863, 0, -0.056089 ),
                (0.0732865, 0, -0.0553724)])
            curve2 = cmds.curve(degree = 1, 
                point = [(0.163715, 0, -0.529656), 
                (0.888882, 0, -0.530775), 
                (0.886644, 0, -0.846357), 
                (0.491607, 0, -0.845238 ),
                (0.443486, 0, -0.834047 ),
                (0.396485, 0, -0.813903 ),
                (0.355079, 0, -0.774735 ),
                (0.164834, 0, -0.528537)])
            
            curve3 = cmds.curve(degree = 1, 
                point = [(0.727948, 0, -0.395639), 
                (0.841246, 0, -0.394475 ),
                (0.849783, 0, -0.398743 ),
                (0.857155, 0, -0.407667 ),
                (0.857543, 0, -0.425903 ),
                (0.852499, 0, -0.433275 ),
                (0.844351, 0, -0.437932), 
                (0.730664, 0, -0.44026), 
                (0.718636, 0, -0.434439), 
                (0.713204, 0, -0.424739 ),
                (0.713204, 0, -0.412323), 
                (0.718248, 0, -0.403011), 
                (0.727948, 0, -0.395251)])

            curve4 = cmds.curve(degree = 1, point = [
                (0.557497, 0, -0.560445 ),
                (0.595828, 0, -0.55848 ),
                (0.757998, 0, -0.8209 ),
                (0.715735, 0, -0.8209 ),
                (0.556514, 0, -0.55848 ),])

            curve5 = cmds.curve(degree = 1, point = [
                (0.629245, 0, -0.55848 ),
                (0.691164, 0, -0.556514 ),
                (0.851369, 0, -0.819917 ),
                (0.785518, 0, -0.8209 ),
                (0.628262, 0, -0.559462),])
                
            group = cmds.group(name = "control", world = True, empty = True)
            allCurves = [curve1, curve2, curve3, curve4, curve5]
            i = 1
            for curve in allCurves:
                shape = cmds.listRelatives(curve, shapes = True)
                cmds.select(shape, group)
                cmds.parent(relative = True, shape = True) 
                cmds.rename(shape[0], "control_shp%s"%i)#maybe not needed
                i += 1
            cmds.delete(allCurves)
            
            cmds.move(0, 0, -0.5, "%s.scalePivot"%group, "%s.rotatePivot"%group, absolute=True)
            cmds.select(group)
            cmds.move(0, 0, 0.5)
            cmds.makeIdentity(apply = True)
            cmds.DeleteHistory()
            cmds.select(clear = True)
            
            return group

    #Script By windy
    #creates curves for the Hook (boom, arm, bucket) (the user will animate with)
    class FinalDrive_placeHolder():
        def create(self): 
            #create circle
            circleInner = cmds.circle( name = "Track", normalX = 1, normalY = 0, normalZ = 0, radius = 1)
            circleOutter = cmds.circle( name = "Track", normalX = 0, normalY = 1, normalZ = 0, radius = 1)
            circleZ = cmds.circle( name = "Track", normalX = 0, normalY = 0, normalZ = 1, radius = 1)
            # create text
            innerText1 = cmds.textCurves(name = "Track", font = "Calibri", text = "FinalDrive Locator")
            cmds.rotate(0, 90, 0, relative = True)
            cmds.scale(0.3, 0.3, 0.3, relative = True)
            cmds.CenterPivot()
            # match transform
            cmds.matchTransform(innerText1, circleInner, position = True)
            # delete make curve
            cmds.delete(innerText1[1]) 
            #freeze transforms
            cmds.makeIdentity(innerText1[0], apply = True)
            
            #get shapes
            textCurves1 = cmds.listRelatives(innerText1[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            circleCurvesInner = cmds.listRelatives(circleInner[0], shapes = True, fullPath = True)
            circleCurvesOutter = cmds.listRelatives(circleOutter[0], shapes = True, fullPath = True)
            circleCurvesZ = cmds.listRelatives(circleZ[0], shapes = True, fullPath = True)
           
            #combine curves
            ctrlGrp = cmds.group(name = "FinalDrive Locator", world = True, empty = True)
            cmds.parent(textCurves1, circleCurvesInner, circleCurvesOutter, circleCurvesZ, ctrlGrp, 
                shape = True, relative = True)                    
            cmds.delete(circleInner, circleOutter, circleZ, innerText1[0])
            
            #add locatershape in ctrlGrp
            cmds.spaceLocator(name = "ctrlGrpCtrlLoc1")
            cmds.select("ctrlGrpCtrlLoc1Shape", ctrlGrp)
            cmds.parent(relative = True, shape = True)
            cmds.delete("ctrlGrpCtrlLoc1")
            
            #increase overall size
            cmds.select(ctrlGrp)
            cmds.scale(3.0, 3.0, 3.0, relative = True)
            cmds.makeIdentity( apply = True)
            
            # override color
            for curve in cmds.listRelatives(ctrlGrp, allDescendents = True, type = "nurbsCurve", fullPath = True):
                cmds.setAttr("%s.overrideEnabled"%curve, 1)
                cmds.setAttr("%s.overrideColor"%curve, 13)
            
            cmds.select(clear = True)
            return ctrlGrp

    #Script By windy
    #creates curves for the FrontIdler (the user will animate with)
    class FrontIdler_placeHolder():
        def create(self):
            #create circle
            circleInner = cmds.circle( name = "Track", normalX = 1, normalY = 0, normalZ = 0, radius = 1)
            circleOutter = cmds.circle( name = "Track", normalX = 0, normalY = 1, normalZ = 0, radius = 1)
            circleZ = cmds.circle( name = "Track", normalX = 0, normalY = 0, normalZ = 1, radius = 1)
            # create text
            innerText1 = cmds.textCurves(name = "Track", font = "Calibri", text = "Front Idler Locator")
            cmds.rotate(0, 90, 0, relative = True)
            cmds.scale(0.3, 0.3, 0.3, relative = True)
            cmds.CenterPivot()
            # match transform
            cmds.matchTransform(innerText1, circleInner, position = True)
            # delete make curve
            cmds.delete(innerText1[1]) 
            #freeze transforms
            cmds.makeIdentity(innerText1[0], apply = True)
            
            
            #get shapes
            textCurves1 = cmds.listRelatives(innerText1[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            circleCurvesInner = cmds.listRelatives(circleInner[0], shapes = True, fullPath = True)
            circleCurvesOutter = cmds.listRelatives(circleOutter[0], shapes = True, fullPath = True)
            circleCurvesZ = cmds.listRelatives(circleZ[0], shapes = True, fullPath = True)
           
            #combine curves
            ctrlGrp = cmds.group(name = "Front Idler Locator", world = True, empty = True)
            cmds.parent(textCurves1, circleCurvesInner, circleCurvesOutter, circleCurvesZ, ctrlGrp, 
                shape = True, relative = True)                    
            cmds.delete(circleInner, circleOutter, circleZ, innerText1[0])
            
            #add locatershape in ctrlGrp
            cmds.spaceLocator(name = "ctrlGrpCtrlLoc1")
            cmds.select("ctrlGrpCtrlLoc1Shape", ctrlGrp)
            cmds.parent(relative = True, shape = True)
            cmds.delete("ctrlGrpCtrlLoc1")
            
            #increase overall size
            cmds.select(ctrlGrp)
            cmds.scale(3.0, 3.0, 3.0, relative = True)
            cmds.makeIdentity( apply = True)
            
            # override color
            for curve in cmds.listRelatives(ctrlGrp, allDescendents = True, type = "nurbsCurve", fullPath = True):
                cmds.setAttr("%s.overrideEnabled"%curve, 1)
                cmds.setAttr("%s.overrideColor"%curve, 13)
            
            cmds.select(clear = True)
            return ctrlGrp
            
    #Script By windy
    #creates shapes for a Hook (Boom, arm, bucket) (the user will position to model for getting placement)
    class Hook_placeHolder():
        def create(self):
            
            #create text
            innerText = cmds.textCurves(name = "HookLoc", font = "Calibri", text = "Hook Locator")   
            cmds.scale(0.19, 0.19, 0.19, relative = True)
            cmds.rotate(0, 90, 0, relative = True)
            cmds.CenterPivot()
            
            cmds.delete(innerText[1])         
            #freeze transforms
            cmds.makeIdentity(innerText[0], apply = True)
            #get shapes
            textCurves = cmds.listRelatives(innerText[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)

            #createcube
            cubeShape = cmds.polyCube(name = "cubeShape")
            
            #selectEdges
            cmds.select("cubeShape.e[1]", "cubeShape.e[5]", "cubeShape.e[0]", "cubeShape.e[4]")
            #convert edge to curve
            cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve1")

            cmds.select("cubeShape.e[2]", "cubeShape.e[8]", "cubeShape.e[3]", "cubeShape.e[9]")
            cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve2")

            cmds.select("cubeShape.e[7]")
            cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve3")

            cmds.select("cubeShape.e[11]")
            cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve4")

            cmds.select("cubeShape.e[10]")
            cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve5")

            cmds.select("cubeShape.e[6]")
            cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve6")
            
            #creategroup
            Hook_Loc = cmds.group( em=True, name='Hook_Locator')
            
            #combine curves to group
            cmds.select("ctrlGrpCtrlCurve1Shape", 
                "ctrlGrpCtrlCurve1Shape", 
                "ctrlGrpCtrlCurve2Shape", 
                "ctrlGrpCtrlCurve3Shape", 
                "ctrlGrpCtrlCurve4Shape", 
                "ctrlGrpCtrlCurve5Shape", 
                "ctrlGrpCtrlCurve6Shape", 
                textCurves, 
                Hook_Loc)
            
            cmds.parent(relative = True, shape = True)
            
            #add locatershape in grp
            cmds.spaceLocator(name = "ctrlGrpCtrlLoc1")
            cmds.select("ctrlGrpCtrlLoc1Shape", Hook_Loc)
            cmds.parent(relative = True, shape = True)
            
            #delete Cube and empty groups
            cmds.select(cubeShape, 
                "ctrlGrpCtrlCurve1", 
                "ctrlGrpCtrlCurve2", 
                "ctrlGrpCtrlCurve3", 
                "ctrlGrpCtrlCurve4", 
                "ctrlGrpCtrlCurve5", 
                "ctrlGrpCtrlCurve6", 
                "ctrlGrpCtrlLoc1",
                "HookLocShape")
            cmds.delete()
            
            #increase Overall Size
            cmds.select(Hook_Loc)
            cmds.scale(2.0, 2.0, 2.0, relative = True)
            cmds.makeIdentity( apply = True, scale = True)
            
            #rename the shape nodes for code reuse
            cmds.select(Hook_Loc)
            ctrlGrpShapes = cmds.ls(sl=True, dag=True, shapes=True)
            for shape in ctrlGrpShapes:
                cmds.rename(shape, "{0}Shape".format(cmds.listRelatives(shape, parent=True)[0]))

            #override color
            for curve in cmds.listRelatives(Hook_Loc, allDescendents = True, type = "nurbsCurve", fullPath = True):
                        cmds.setAttr("%s.overrideEnabled"%curve, 1)
                        cmds.setAttr("%s.overrideColor"%curve, 14)
            
            return Hook_Loc

    #Script By windy
    #creates shapes for a lowerBody (the user will position to model for getting placement)
    class LowerBody_placeHolder():
        def create(self):
            #create 2 circles
            circleInner = cmds.circle( name = "lowerBody", normalX = 0, normalY = 1, normalZ = 0, radius = 15)
            circleOutter = cmds.circle( name = "lowerBody", normalX = 0, normalY = 1, normalZ = 0, radius = 15.3)

            # create cross
            arrowShape = cmds.curve( name= "arrow", degree = 1, point = [
                (0, 0, -5),
                (-2, 0, -3),
                (-1, 0, -3),
                (-1, 0, -1),
                (-3, 0, -1),
                (-3, 0, -2),
                (-5, 0, 0),
                (-3, 0, 2),
                (-3, 0, 1),
                (-1, 0, 1),
                (-1, 0, 3),
                (-2, 0, 3),
                (0, 0, 5),
                (2, 0, 3),
                (1, 0, 3),
                (1, 0, 1),
                (3, 0, 1),
                (3, 0, 2),
                (5, 0, 0),
                (3, 0, -2),
                (3, 0, -1),
                (1, 0, -1),
                (1, 0, -3),
                (2, 0, -3),
                (0, 0, -5)] )
            
            # create cross
            curve1 = cmds.curve( name= "linear", degree = 1, point = [(0, 0, -15), (0, 0, 15)])
            curve2 = cmds.curve( name= "linear", degree = 1, point = [(-15, 0, 0), (15, 0, 0)])
            curve3 = cmds.curve( name= "linear", degree = 1, point = [(0, -5, 0), (0, 5, 0)])
            
            # create text 1
            innerText1 = cmds.textCurves(name = "lowerBody", font = "Calibri", text = "LowerBody Locator")
            cmds.rotate(-90, -90, 0, relative = True)
            cmds.scale(2, 2, 2, relative = True)
            cmds.CenterPivot()
            # create text 2
            innerText2 = cmds.textCurves(name = "lowerBody", font = "Calibri", text = "LowerBody Locator")
            cmds.rotate(-90, 90, 0, relative = True)
            cmds.scale(2, 2, 2, relative = True)
            cmds.CenterPivot()        

            # match transform to circle
            cmds.matchTransform(innerText1, innerText2 ,circleInner, position = True)
            
            # transform texts
            cmds.move(-12, 0, 0, innerText1, relative = True)
            cmds.move(12, 0, 0, innerText2, relative = True)
            
            # delete makeTextCurve
            cmds.delete(innerText1[1], innerText2[1])
            
            # freeze rotation
            cmds.makeIdentity(innerText1[0], innerText2[0], apply = True)       

            #get shapes
            textCurves1 = cmds.listRelatives(innerText1[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            textCurves2 = cmds.listRelatives(innerText2[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            circleCurvesInner = cmds.listRelatives(circleInner[0], shapes = True, fullPath = True)
            circleCurvesOutter = cmds.listRelatives(circleOutter[0], shapes = True, fullPath = True)
            curve1Curve = cmds.listRelatives(curve1, shapes = True)
            curve2Curve = cmds.listRelatives(curve2, shapes = True)
            curve3Curve = cmds.listRelatives(curve3, shapes = True)
            arrowCurve = cmds.listRelatives(arrowShape, shapes = True)
        
            #combine texts
            ctrlGrp = cmds.group(name = "control", world = True, empty = True)
            cmds.parent(textCurves1, textCurves2, 
                        circleCurvesInner, circleCurvesOutter, 
                        curve1Curve, curve2Curve, curve3Curve, arrowCurve,
                        ctrlGrp, shape = True, relative = True)                    
            cmds.delete(circleInner, circleOutter, 
                        innerText1[0], innerText2[0],
                        curve1, curve2, curve3, arrowShape)

            # override color
            for curve in cmds.listRelatives(ctrlGrp, allDescendents = True, type = "nurbsCurve", fullPath = True):
                cmds.setAttr("%s.overrideEnabled"%curve, 1)
                cmds.setAttr("%s.overrideColor"%curve, 18)
            
            cmds.select(clear = True)
            return ctrlGrp
            
    #Script By windy
    #creates shapes for a main (the user will position to model for getting placement)
    class Main_placeHolder():
        def create(self):
            #create 2 circles
            circleInner = cmds.circle( name = "Main", normalX = 0, normalY = 1, normalZ = 0, radius = 20)
            circleOutter = cmds.circle( name = "Main", normalX = 0, normalY = 1, normalZ = 0, radius = 21)

            # create cross
            arrowShape = cmds.curve( name= "arrow", degree = 1, point = [
                (0, 0, -5),
                (-2, 0, -3),
                (-1, 0, -3),
                (-1, 0, -1),
                (-3, 0, -1),
                (-3, 0, -2),
                (-5, 0, 0),
                (-3, 0, 2),
                (-3, 0, 1),
                (-1, 0, 1),
                (-1, 0, 3),
                (-2, 0, 3),
                (0, 0, 5),
                (2, 0, 3),
                (1, 0, 3),
                (1, 0, 1),
                (3, 0, 1),
                (3, 0, 2),
                (5, 0, 0),
                (3, 0, -2),
                (3, 0, -1),
                (1, 0, -1),
                (1, 0, -3),
                (2, 0, -3),
                (0, 0, -5)] )
            # cross
            curve1 = cmds.curve( name= "linear", degree = 1, point = [(0, 0, -20), (0, 0, 20)])
            curve2 = cmds.curve( name= "linear", degree = 1, point = [(-20, 0, 0), (20, 0, 0)])
            curve3 = cmds.curve( name= "linear", degree = 1, point = [(0, -8, 0), (0, 8, 0)])
            
            # create text 1
            innerText1 = cmds.textCurves(name = "Main", font = "Calibri", text = "Main Locator")
            cmds.rotate(-90, -90, 0, relative = True)
            cmds.scale(2.5, 2.5, 2.5, relative = True)
            cmds.CenterPivot()
            # create text 2
            innerText2 = cmds.textCurves(name = "Main", font = "Calibri", text = "Main Locator")
            cmds.rotate(-90, 90, 0, relative = True)
            cmds.scale(2.5, 2.5, 2.5, relative = True)
            cmds.CenterPivot()        

            # match transform to circle
            cmds.matchTransform(innerText1, innerText2 ,circleInner, position = True)
            
            # transform texts
            cmds.move(-17, 0, 0, innerText1, relative = True)
            cmds.move(17, 0, 0, innerText2, relative = True)
            
            # delete makeTextCurve
            cmds.delete(innerText1[1], innerText2[1])
            
            # freeze rotation
            cmds.makeIdentity(innerText1[0], innerText2[0], apply = True)       

            #get shapes
            textCurves1 = cmds.listRelatives(innerText1[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            textCurves2 = cmds.listRelatives(innerText2[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            circleCurvesInner = cmds.listRelatives(circleInner[0], shapes = True, fullPath = True)
            circleCurvesOutter = cmds.listRelatives(circleOutter[0], shapes = True, fullPath = True)
            curve1Curve = cmds.listRelatives(curve1, shapes = True)
            curve2Curve = cmds.listRelatives(curve2, shapes = True)
            curve3Curve = cmds.listRelatives(curve3, shapes = True)
            arrowCurve = cmds.listRelatives(arrowShape, shapes = True)
        
            #combine texts
            ctrlGrp = cmds.group(name = "control", world = True, empty = True)
            cmds.parent(textCurves1, textCurves2, 
                        circleCurvesInner, circleCurvesOutter, 
                        curve1Curve, curve2Curve, curve3Curve, arrowCurve,
                        ctrlGrp, shape = True, relative = True)                    
            cmds.delete(circleInner, circleOutter, 
                        innerText1[0], innerText2[0],
                        curve1, curve2, curve3, arrowShape)

            # override color
            for curve in cmds.listRelatives(ctrlGrp, allDescendents = True, type = "nurbsCurve", fullPath = True):
                cmds.setAttr("%s.overrideEnabled"%curve, 1)
                cmds.setAttr("%s.overrideColor"%curve, 6)

            
            cmds.select(clear = True)
            return ctrlGrp

    #Script By windy
    #creates curves for the roller (the user will animate with)
    class Roller_placeHolder():
        def create(self): 
            #create circle
            circleInner = cmds.circle( name = "Track", normalX = 1, normalY = 0, normalZ = 0, radius = 1)
            circleOutter = cmds.circle( name = "Track", normalX = 0, normalY = 1, normalZ = 0, radius = 1)
            circleZ = cmds.circle( name = "Track", normalX = 0, normalY = 0, normalZ = 1, radius = 1)
            # create text
            innerText1 = cmds.textCurves(name = "Track", font = "Calibri", text = "Roller Locator")
            cmds.rotate(0, 90, 0, relative = True)
            cmds.scale(0.3, 0.3, 0.3, relative = True)
            cmds.CenterPivot()
            # match transform
            cmds.matchTransform(innerText1, circleInner, position = True)
            # delete make curve
            cmds.delete(innerText1[1]) 
            #freeze transforms
            cmds.makeIdentity(innerText1[0], apply = True)
            
            #get shapes
            textCurves1 = cmds.listRelatives(innerText1[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            circleCurvesInner = cmds.listRelatives(circleInner[0], shapes = True, fullPath = True)
            circleCurvesOutter = cmds.listRelatives(circleOutter[0], shapes = True, fullPath = True)
            circleCurvesZ = cmds.listRelatives(circleZ[0], shapes = True, fullPath = True)
           
            #combine curves
            ctrlGrp = cmds.group(name = "Roller Locator", world = True, empty = True)
            cmds.parent(textCurves1, circleCurvesInner, circleCurvesOutter, circleCurvesZ, ctrlGrp, 
                shape = True, relative = True)                    
            cmds.delete(circleInner, circleOutter, circleZ, innerText1[0])
            
            #add locatershape in ctrlGrp
            cmds.spaceLocator(name = "ctrlGrpCtrlLoc1")
            cmds.select("ctrlGrpCtrlLoc1Shape", ctrlGrp)
            cmds.parent(relative = True, shape = True)
            cmds.delete("ctrlGrpCtrlLoc1")
            
            #increase overall size
            #cmds.select(ctrlGrp)
            #cmds.scale(3.0, 3.0, 3.0, relative = True)
            #cmds.makeIdentity( apply = True)
            
            # override color
            for curve in cmds.listRelatives(ctrlGrp, allDescendents = True, type = "nurbsCurve", fullPath = True):
                cmds.setAttr("%s.overrideEnabled"%curve, 1)
                cmds.setAttr("%s.overrideColor"%curve, 13)
            
            cmds.select(clear = True)
            return ctrlGrp

    #Script By windy
    #creates shapes for a Root (the user will position to model for getting placement)
    class Root_placeHolder():
        def create(self):
            #create 2 circles
            circleInner = cmds.circle( name = "Root", normalX = 0, normalY = 1, normalZ = 0, radius = 17)
            circleOutter = cmds.circle( name = "Root", normalX = 0, normalY = 1, normalZ = 0, radius = 17.2)

            # create cross
            arrowShape = cmds.curve( name= "arrow", degree = 1, point = [
                (0, 0, -5),
                (-2, 0, -3),
                (-1, 0, -3),
                (-1, 0, -1),
                (-3, 0, -1),
                (-3, 0, -2),
                (-5, 0, 0),
                (-3, 0, 2),
                (-3, 0, 1),
                (-1, 0, 1),
                (-1, 0, 3),
                (-2, 0, 3),
                (0, 0, 5),
                (2, 0, 3),
                (1, 0, 3),
                (1, 0, 1),
                (3, 0, 1),
                (3, 0, 2),
                (5, 0, 0),
                (3, 0, -2),
                (3, 0, -1),
                (1, 0, -1),
                (1, 0, -3),
                (2, 0, -3),
                (0, 0, -5)] )
            
            # create cross
            curve1 = cmds.curve( name= "linear", degree = 1, point = [(0, 0, -17), (0, 0, 17)])
            curve2 = cmds.curve( name= "linear", degree = 1, point = [(-17, 0, 0), (17, 0, 0)])
            curve3 = cmds.curve( name= "linear", degree = 1, point = [(0, -5, 0), (0, 5, 0)])

            # create text 1
            innerText1 = cmds.textCurves(name = "Root", font = "Calibri", text = "Root Locator")
            cmds.rotate(-90, -90, 0, relative = True)
            cmds.scale(2.3, 2.3, 2.3, relative = True)
            cmds.CenterPivot()
            # create text 2
            innerText2 = cmds.textCurves(name = "Root", font = "Calibri", text = "Root Locator")
            cmds.rotate(-90, 90, 0, relative = True)
            cmds.scale(2.3, 2.3, 2.3, relative = True)
            cmds.CenterPivot()        

            # match transform to circle
            cmds.matchTransform(innerText1, innerText2 ,circleInner, position = True)
            
            # transform texts
            cmds.move(-14, 0, 0, innerText1, relative = True)
            cmds.move(14, 0, 0, innerText2, relative = True)
            
            # delete makeTextCurve
            cmds.delete(innerText1[1], innerText2[1])
            
            # freeze rotation
            cmds.makeIdentity(innerText1[0], innerText2[0], apply = True)       

            #get shapes
            textCurves1 = cmds.listRelatives(innerText1[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            textCurves2 = cmds.listRelatives(innerText2[0],
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            circleCurvesInner = cmds.listRelatives(circleInner[0], shapes = True, fullPath = True)
            circleCurvesOutter = cmds.listRelatives(circleOutter[0], shapes = True, fullPath = True)
            curve1Curve = cmds.listRelatives(curve1, shapes = True)
            curve2Curve = cmds.listRelatives(curve2, shapes = True)
            curve3Curve = cmds.listRelatives(curve3, shapes = True)
            arrowCurve = cmds.listRelatives(arrowShape, shapes = True)
        
            #combine texts
            ctrlGrp = cmds.group(name = "control", world = True, empty = True)
            cmds.parent(textCurves1, textCurves2, 
                        circleCurvesInner, circleCurvesOutter, 
                        curve1Curve, curve2Curve, curve3Curve, arrowCurve,
                        ctrlGrp, shape = True, relative = True)                    
            cmds.delete(circleInner, circleOutter, 
                        innerText1[0], innerText2[0],
                        curve1, curve2, curve3, arrowShape)

            # override color
            for curve in cmds.listRelatives(ctrlGrp, allDescendents = True, type = "nurbsCurve", fullPath = True):
                cmds.setAttr("%s.overrideEnabled"%curve, 1)
                cmds.setAttr("%s.overrideColor"%curve, 18)
            # ??? this loop can only work for once
            
            cmds.select(clear = True)
            return ctrlGrp
            

    #Script By windy
    #creates shapes for a Steering (the user will position to model for getting placement)
    class Steering_placeHolder():
        def create(self):
            #create 2 circles
            circleInner = cmds.circle( name = "Steering", normalX = 0, normalY = 1, normalZ = 0, radius = 1)
            circleOutter = cmds.circle( name = "Steering", normalX = 0, normalY = 1, normalZ = 0, radius = 1.1)

            # create cross
            
            curve1 = cmds.curve( name= "linear", degree = 1, point = [(0, 0, -1), (0, 0, 1)])
            curve2 = cmds.curve( name= "linear", degree = 1, point = [(-1, 0, 0), (1, 0, 0)])
            curve3 = cmds.curve( name= "linear", degree = 1, point = [(0, -0.5, 0), (0, 0.5, 0)])

            # create text 1
            innerText1 = cmds.textCurves(name = "Steering", font = "Calibri", text = "Left")
            cmds.rotate(-90, 0, 0, relative = True)
            cmds.scale(0.3, 0.3, 0.3, relative = True)
            cmds.CenterPivot()
            # create text 2
            innerText2 = cmds.textCurves(name = "Steering", font = "Calibri", text = "Right")
            cmds.rotate(-90, 0, 0, relative = True)
            cmds.scale(0.3, 0.3, 0.3, relative = True)
            cmds.CenterPivot()        

            # match transform to circle
            cmds.matchTransform(innerText1, innerText2 ,circleInner, position = True)
            
            # transform texts
            cmds.move(-0.6, 0, 0, innerText1, relative = True)
            cmds.move(0.6, 0, 0, innerText2, relative = True)
            
            # delete makeTextCurve
            cmds.delete(innerText1[1], innerText2[1])
            
            # freeze rotation
            cmds.makeIdentity(innerText1[0], innerText2[0], apply = True)       

            #get shapes
            textCurves1 = cmds.listRelatives(innerText1[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            textCurves2 = cmds.listRelatives(innerText2[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            circleCurvesInner = cmds.listRelatives(circleInner[0], shapes = True, fullPath = True)
            circleCurvesOutter = cmds.listRelatives(circleOutter[0], shapes = True, fullPath = True)
            curve1Curve = cmds.listRelatives(curve1, shapes = True)
            curve2Curve = cmds.listRelatives(curve2, shapes = True)
            curve3Curve = cmds.listRelatives(curve3, shapes = True)
        
            #combine texts
            ctrlGrp = cmds.group(name = "control", world = True, empty = True)
            cmds.parent(textCurves1, textCurves2, 
                        circleCurvesInner, circleCurvesOutter, 
                        curve1Curve, curve2Curve, curve3Curve,
                        ctrlGrp, shape = True, relative = True)                    
            cmds.delete(circleInner, circleOutter, 
                        innerText1[0], innerText2[0],
                        curve1, curve2, curve3)

            # override color
            for curve in cmds.listRelatives(ctrlGrp, allDescendents = True, type = "nurbsCurve", fullPath = True):
                cmds.setAttr("%s.overrideEnabled"%curve, 1)
                cmds.setAttr("%s.overrideColor"%curve, 9)
            
            cmds.select(clear = True)
            return ctrlGrp

    #Script By windy
    #creates shapes for a Track (the user will position to model for getting placement)
    class Track_placeHolder():
        def create(self):
            # cross
            curve1 = cmds.curve( name= "linear", degree = 1, point = [(-3, 3, 0),
                                                                      (3, 3, 0),
                                                                      (3, -3, 0),
                                                                      (-3, -3, 0),
                                                                      (-3, 3, 0)])
            curve2 = cmds.curve( name= "linear", degree = 1, point = [(-2, 2, 0), 
                                                                      (2, 2, 0),
                                                                      (2, -2, 0), 
                                                                      (-2, -2, 0),
                                                                      (-2, 2, 0)])
            curve3 = cmds.curve( name= "linear", degree = 1, point = [(-2, 2, 0), (2, -2, 0)])
            curve4 = cmds.curve( name= "linear", degree = 1, point = [(2, 2, 0), (-2, -2, 0)])
            
            # create text 1
            innerText1 = cmds.textCurves(name = "Track", font = "Calibri", text = "Track End Point")
            cmds.rotate(0, 0, 0, relative = True)
            cmds.scale(0.9, 0.9, 0.9, relative = True)
            cmds.CenterPivot()
            # create text 2
            innerText2 = cmds.textCurves(name = "Track", font = "Calibri", text = "Track End Point")
            cmds.rotate(0, 180, 0, relative = True)
            cmds.scale(0.9, 0.9, 0.9, relative = True)
            cmds.CenterPivot()        

            # match transform to circle
            cmds.matchTransform(innerText1, innerText2 , curve1, position = True)
            
            # transform texts
            cmds.move(0, 2.5, 0, innerText1, relative = True)
            cmds.move(0, -2.4, 0, innerText2, relative = True)
            
            # delete makeTextCurve
            cmds.delete(innerText1[1], innerText2[1])
            
            # freeze rotation
            cmds.makeIdentity(innerText1[0], innerText2[0], apply = True)       

            #get shapes
            textCurves1 = cmds.listRelatives(innerText1[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            textCurves2 = cmds.listRelatives(innerText2[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            curve1Curve = cmds.listRelatives(curve1, shapes = True)
            curve2Curve = cmds.listRelatives(curve2, shapes = True)
            curve3Curve = cmds.listRelatives(curve3, shapes = True)
            curve4Curve = cmds.listRelatives(curve4, shapes = True)

        
            #combine texts
            ctrlGrp = cmds.group(name = "control", world = True, empty = True)
            cmds.parent(textCurves1, textCurves2, 
                        curve1Curve, curve2Curve, curve3Curve, curve4Curve,
                        ctrlGrp, shape = True, relative = True)                    
            cmds.delete(innerText1[0], innerText2[0],
                        curve1, curve2, curve3, curve4)
     
            # override color
            for curve in cmds.listRelatives(ctrlGrp, allDescendents = True, type = "nurbsCurve", fullPath = True):
                cmds.setAttr("%s.overrideEnabled"%curve, 1)
                cmds.setAttr("%s.overrideColor"%curve, 13)
            
            cmds.select(clear = True)
            return ctrlGrp

    #Script By windy
    #creates shapes for a upperBody (the user will position to model for getting placement)
    class UpperBody_placeHolder():
        def create(self):
            #create 2 circles
            circleInner = cmds.circle( name = "upperBody", normalX = 0, normalY = 1, normalZ = 0, radius = 15)
            circleOutter = cmds.circle( name = "upperBody", normalX = 0, normalY = 1, normalZ = 0, radius = 15.3)

            # create cross
            arrowShape = cmds.curve( name= "arrow", degree = 1, point = [
                (0, 0, -5),
                (-2, 0, -3),
                (-1, 0, -3),
                (-1, 0, -1),
                (-3, 0, -1),
                (-3, 0, -2),
                (-5, 0, 0),
                (-3, 0, 2),
                (-3, 0, 1),
                (-1, 0, 1),
                (-1, 0, 3),
                (-2, 0, 3),
                (0, 0, 5),
                (2, 0, 3),
                (1, 0, 3),
                (1, 0, 1),
                (3, 0, 1),
                (3, 0, 2),
                (5, 0, 0),
                (3, 0, -2),
                (3, 0, -1),
                (1, 0, -1),
                (1, 0, -3),
                (2, 0, -3),
                (0, 0, -5)] )
            
            # create cross
            curve1 = cmds.curve( name= "linear", degree = 1, point = [(0, 0, -15), (0, 0, 15)])
            curve2 = cmds.curve( name= "linear", degree = 1, point = [(-15, 0, 0), (15, 0, 0)])
            curve3 = cmds.curve( name= "linear", degree = 1, point = [(0, -5, 0), (0, 5, 0)])
            
            # create text 1
            innerText1 = cmds.textCurves(name = "upperBody", font = "Calibri", text = "UpperBody Locator")
            cmds.rotate(-90, -90, 0, relative = True)
            cmds.scale(2, 2, 2, relative = True)
            cmds.CenterPivot()
            # create text 2
            innerText2 = cmds.textCurves(name = "upperBody", font = "Calibri", text = "UpperBody Locator")
            cmds.rotate(-90, 90, 0, relative = True)
            cmds.scale(2, 2, 2, relative = True)
            cmds.CenterPivot()        

            # match transform to circle
            cmds.matchTransform(innerText1, innerText2 ,circleInner, position = True)
            
            # transform texts
            cmds.move(-12, 0, 0, innerText1, relative = True)
            cmds.move(12, 0, 0, innerText2, relative = True)
            
            # delete makeTextCurve
            cmds.delete(innerText1[1], innerText2[1])
            
            # freeze rotation
            cmds.makeIdentity(innerText1[0], innerText2[0], apply = True)       

            #get shapes
            textCurves1 = cmds.listRelatives(innerText1[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            textCurves2 = cmds.listRelatives(innerText2[0], 
                allDescendents = True, 
                type = "nurbsCurve", 
                fullPath = True)
            circleCurvesInner = cmds.listRelatives(circleInner[0], shapes = True, fullPath = True)
            circleCurvesOutter = cmds.listRelatives(circleOutter[0], shapes = True, fullPath = True)
            curve1Curve = cmds.listRelatives(curve1, shapes = True)
            curve2Curve = cmds.listRelatives(curve2, shapes = True)
            curve3Curve = cmds.listRelatives(curve3, shapes = True)
            arrowCurve = cmds.listRelatives(arrowShape, shapes = True)
        
            #combine texts
            ctrlGrp = cmds.group(name = "control", world = True, empty = True)
            cmds.parent(textCurves1, textCurves2, 
                        circleCurvesInner, circleCurvesOutter, 
                        curve1Curve, curve2Curve, curve3Curve, arrowCurve,
                        ctrlGrp, shape = True, relative = True)                    
            cmds.delete(circleInner, circleOutter, 
                        innerText1[0], innerText2[0],
                        curve1, curve2, curve3, arrowShape)

            # override color
            for curve in cmds.listRelatives(ctrlGrp, allDescendents = True, type = "nurbsCurve", fullPath = True):
                cmds.setAttr("%s.overrideEnabled"%curve, 1)
                cmds.setAttr("%s.overrideColor"%curve, 18)
            
            cmds.select(clear = True)
            return ctrlGrp




    #COMING SOON...MAYBE
    class Wheel_placeHolder():
        def create(self):
            pass   

#************************************ANIMATION****************************************     

#converts the placeholder into a animation controler
class Animations_anim():
    
    #Script By Tyler Millossi
    #parent class for creating shapes for a arm (basic FK for one joint)
    #FK for a single joint
    class SingleFK_anim():
        #basic FK IK? and limited rotation, translate. No scale?
        def __init__(self, placeholder, geo):
            self.placeHolder = placeholder
            self.geo = geo
        
        def createAnimationControl(self, modName):
            #reference the class
            exec("classInstance = Curves_control.%s%s_control()"%(modName[0].upper(), modName[1:]))
            control = classInstance.create()
            classInstance = None
            return control
             
        def singleJointFK(self, module_Name, lockedAttrs, control):#lockedAttrs = ["sx", "sy", "sz"]
            #rename control
            self.animControl = cmds.rename(control, "%s_ctr"%module_Name)
            for i in cmds.listRelatives(self.animControl, allDescendents = True, type = "nurbsCurve"):
                cmds.rename(i, "%s_ctr_shp"%module_Name)
            
            #place in same location as the geo
            if type(self.geo) == type([]):
                if cmds.objExists(self.geo[0]):
                    cmds.matchTransform(self.animControl, self.placeHolder) 
            else:
                if cmds.objExists(self.geo):
                    cmds.matchTransform(self.animControl, self.placeHolder)  

            #delete placer - should this be done in the placer class?
            cmds.delete(self.placeHolder)
            
            #create joint on control location
            cmds.select(clear = True)
            self.joint_ = cmds.joint(name = "%s_jnt"%module_Name)
            cmds.setAttr("%s.visibility"%self.joint_, 0)
            cmds.matchTransform(self.joint_, self.animControl)
            
            #skin geo to joint
            clusters = []
            #if theres is a list for geo - multiple binds
            if type(self.geo) == type([]):
                for geo in self.geo:
                    #skin geo to joint
                    skinCluster = cmds.skinCluster(self.joint_, geo,## 
                        name = "%s_skinCluster"%module_Name, 
                        toSelectedBones = True, 
                        bindMethod = 0, 
                        skinMethod = 0, 
                        normalizeWeights = 1)[0]
                    clusters.append(skinCluster)
            
            else:
                #get the geo shape node for skinning
                geoShapes = cmds.listRelatives(self.geo, shapes = True)
                #skin geo to joint
                skinCluster = cmds.skinCluster(self.joint_, geoShapes[0], 
                    name = "%s_skinCluster"%module_Name, 
                    toSelectedBones = True, 
                    bindMethod = 0, 
                    skinMethod = 0, 
                    normalizeWeights = 1)[0]
                clusters.append(skinCluster)
        
            #group
            self.controlGrp = cmds.group(name = "%s_ctr_grp"%module_Name, world = True, empty = True)
            cmds.matchTransform(self.controlGrp, self.animControl)
            cmds.parent(self.animControl, self.controlGrp)      
            
            #hide and lock attributes - scale
            for attr in lockedAttrs:
                cmds.setAttr("%s.%s"%(self.animControl, attr), keyable = False, lock = True)  
            
            #apply parenting and anything needed to make this work
            cmds.parentConstraint(self.animControl, self.joint_, name = "%s_prtCt"%self.joint_)
            
            #clear Selection
            cmds.select(clear = True)
        
        def getPosInfoOfFarPoints(self, geo):
            xVal = []
            yVal = []
            zVal = []
            for vert in cmds.ls("%s.vtx[*]"%geo, flatten = True):
                vertPos = cmds.xform(vert, query = True, translation = True, worldSpace = True)
                xVal.append(vertPos[0])
                yVal.append(vertPos[1])
                zVal.append(vertPos[2]) 
            valueInfo = [[max(xVal), min(xVal)], [max(yVal), min(yVal)], [max(zVal), min(zVal)]]
            return valueInfo
    #Script By Tyler Millossi
    #creates shapes for a arm (converts the placeholders to final animation controls)
    class Arm_anim(SingleFK_anim):
        def control(self):
            #create control
            control = self.createAnimationControl("arm")

            # move the control to the right place
            # get the max distance value of mesh for x axis
            valuePos = self.getPosInfoOfFarPoints(self.geo[0])[0]  
            xVal = abs(valuePos[0]+0.5-(valuePos[1]-0.5))
            # move control
            cmds.move(xVal/2, control)     
            dup = cmds.duplicate(control, name = "Temp_1", renameChildren = True)
            cmds.move(valuePos[1]-0.5, dup)
            cmds.rotate(0, 180, 0, dup, os = True, relative = True)
            cmds.select(dup, control)
            #cmds.FreezeTransformations()
            cmds.makeIdentity(apply = True)
            # combine curve shapes
            curvesGrp = cmds.listRelatives(dup, allDescendents = True, type = "nurbsCurve", fullPath = True)
            cmds.parent(curvesGrp, control, relative = True, shape = True)
            cmds.xform(control, centerPivots = True)
            cmds.delete("Temp_1")
            
            #create single FK
            self.singleJointFK("arm", ["sx", "sy", "sz", "ry", "rz", "tx", "ty", "tz"], control)
            #module name / locked attrs / curves

    #Script By Tyler Millossi
    #creates shapes for a boom (converts the placeholders to final animation controls)
    class Boom_anim(SingleFK_anim):  
        
        def control(self):
            #create control
            control = self.createAnimationControl("boom") 
            
            # move the anim control
            # get the max distance value of mesh for x axis
            valuePos = self.getPosInfoOfFarPoints(self.geo[0])[0]  
            xVal = abs(valuePos[0]+0.5-(valuePos[1]-0.5))
            # move control
            cmds.move(xVal/2, control)     
            dup = cmds.duplicate(control, name = "Temp_1", renameChildren = True)
            cmds.move(valuePos[1]-0.5, dup)
            cmds.rotate(0, 180, 0, dup, os = True, relative = True)
            cmds.select(dup, control)
            #cmds.FreezeTransformations()
            cmds.makeIdentity(apply = True)
            # combine curve shapes
            curvesGrp = cmds.listRelatives(dup, allDescendents = True, type = "nurbsCurve", fullPath = True)
            cmds.parent(curvesGrp, control, relative = True, shape = True)
            cmds.xform(control, centerPivots = True)
            cmds.delete("Temp_1")
            
            # lock attrs
            self.singleJointFK("boom", ["sx", "sy", "sz", "ry", "rz", "tx", "ty", "tz"], control)
            #module name / locked attrs / curves

    #Script By Tyler Millossi
    #creates shapes for a bucket (converts the placeholders to final animation controls)
    class Bucket_anim(SingleFK_anim):

        def control(self):
            #create control
            control = self.createAnimationControl("bucket")

            # move the anim control
            # get the max distance value of mesh for x axis
            valuePos = self.getPosInfoOfFarPoints(self.geo[0])[0]  
            xVal = abs(valuePos[0]+0.5-(valuePos[1]-0.5))
            # move control
            cmds.move(xVal/2, control)     
            dup = cmds.duplicate(control, name = "Temp_1", renameChildren = True)
            cmds.move(valuePos[1]-0.5, dup)
            cmds.rotate(0, 180, 0, dup, os = True, relative = True)
            cmds.select(dup, control)
            #cmds.FreezeTransformations()
            cmds.makeIdentity(apply = True)
            # combine curve shapes
            curvesGrp = cmds.listRelatives(dup, allDescendents = True, type = "nurbsCurve", fullPath = True)
            cmds.parent(curvesGrp, control, relative = True, shape = True)
            cmds.xform(control, centerPivots = True)
            cmds.delete("Temp_1")
            
            #create single FK
            self.singleJointFK("bucket", ["sx", "sy", "sz", "ry", "rz", "tx", "ty", "tz"], control)
            #module name / locked attrs / curves

    #Script By Tyler Millossi
    #creates shapes for a Door (converts the placeholders to final animation controls)
    class Door_anim(SingleFK_anim):
        
        def control(self):
            #create control
            control = self.createAnimationControl("door")

            #match to current model specific transforms
            cmds.select(control)
            cmds.rotate(90, 90)
            cmds.scale(4,4,4)
            cmds.makeIdentity(apply = True)
            
            #create single FK
            self.singleJointFK("door", ["sx", "sy", "sz"], control)#module name / locked attrs / curves    

    #Script By Tyler Millossi
    #parent class for creating IK for a arm (basic IK for three joints)
    #IK for a single joint
    class hookIK_anim():
        #basic FK IK? and limited rotation, translate. No scale?
        def __init__(self, placeholder, geo):
            pass
        
        def createHookIKControl(self, modName):
            #reference the class
            exec("classInstance = Curves_control.%s%s_control()"%(modName[0].upper(), modName[1:]))
            control = classInstance.create()
            return control
            
        def threeJointIK(self, module_Name, lockedAttrs, control):#lockedAttrs = ["sx", "sy", "sz"]
            #rename control
            self.animControl = cmds.rename(control, "%s_ctr"%module_Name)

            #clear Selection
            cmds.select(clear = True)
            
            #user no longer wants the boom
        def deleteControl(self):
            #delete controller
            if cmds.objExists(self.animControl):
                cmds.delete(self.animControl)
            #delete joint
            if cmds.objExists(self.joint_):
                cmds.delete(self.joint_)

    #Script By tyler millossi
    #creates shapes for a track (converts the placeholders to final animation controls)
    class LeftTrack_anim(SingleFK_anim):
        def __init__(self, geo, children):
            self.geo = geo
            self.children = children
            self.joints = children[1]   
        
        def control(self):    
            #create control
            control = self.createAnimationControl("leftTrack") 
            #move to correct location and rotation
            cmds.rotate(0,180, control)
            farX = 0
            maxY = -100000
            minY = +100000
            maxZ = -100000
            minZ = +100000
            #organize the list better
            geo = [self.geo[0], self.geo[1]]
            geo.extend(self.geo[2])
            #get position info
            for g in geo:
                valuePos = self.getPosInfoOfFarPoints(g)
                if valuePos[0][0] > farX:
                    farX = valuePos[0][0]
                if valuePos[1][0] > maxY:
                    maxY = valuePos[1][0]
                if valuePos[1][1] < minY:
                    minY = valuePos[1][1]
                if valuePos[2][0] > maxZ:
                    maxZ = valuePos[2][0]
                if valuePos[2][1] < minZ:
                    minZ = valuePos[2][1]
            #place controller
            cmds.move(farX + 1, 
                      minY + (maxY - (minY))/2,
                      minZ + (maxZ - (minZ))/2,
                      control)
            cmds.makeIdentity(control, apply = True)
            
            #rename
            self.animControl = cmds.rename(control, "leftTrack_ctr")
            for i in cmds.listRelatives(self.animControl, allDescendents = True, type = "nurbsCurve"):
                cmds.rename(i, "leftTrack_ctr_shp")
            
            #grouping
            group = cmds.group(name = "leftTrack_ctr_grp", world = True, empty = True)
            cmds.matchTransform(group, self.animControl)
            cmds.parent(self.animControl, group)
            for i in self.children[2:]:
                cmds.parent(i, self.animControl)
            #things that cause double transform
            for i in self.children[0]:
                cmds.setAttr("%s.inheritsTransform"%i, 0)
                cmds.parent(i, group)  
                cmds.move(0,0,0, i, objectSpace = True)           
            
            #hide and lock attributes - main control
            for attr in ["sx", "sy", "sz"]:
                cmds.setAttr("%s.%s"%(self.animControl, attr), keyable = False, lock = True)  
            
            #hide and lock attributes - wheel controls
            wheels = cmds.ls("leftTrack_roller_*_ctr")
            wheels.append("leftTrack_front_ctr")
            wheels.append("leftTrack_back_ctr")
            for wheel in wheels:
                for attr in ["sx", "sy", "sz", "rx", "ry", "rz", "tz"]:
                    cmds.setAttr("%s.%s"%(wheel, attr), keyable = False, lock = True) 
            
            #need to name/rename everything unique
            for obj in cmds.listRelatives(group, allDescendents = True):
                if not "left" in obj:
                    cmds.rename(obj, "leftTrack_%s"%obj)
                    
    #Script By tyler millossi
    #creates shapes for a lowerBody (converts the placeholders to final animation controls)
    class LowerBody_anim(SingleFK_anim):
        def control(self):
            #create control
            control = self.createAnimationControl("lowerBody")
            
            #create single FK
            self.singleJointFK("lowerBody", ["sx", "sy", "sz"], control)#module name / locked attrs / curves

    #Script By tyler millossi
    #creates shapes for a main (converts the placeholders to final animation controls)
    class Main_anim(SingleFK_anim):
        def control(self):
            #create control
            control = self.createAnimationControl("main")
            moveControl = self.createAnimationControl("root")
            
            #position Info - get the position the control z should be - moveControl
            YValue = []
            geoTransformNodes = []
            for geo in self.geo:
                geoTransformNodes.extend(cmds.listRelatives(geo, parent = True))
                YValue.append(self.getPosInfoOfFarPoints(geo)[1][0] + 0.1)
            geoMaxY = max(YValue)
            
            cmds.move(0, geoMaxY+2, 0, moveControl)
            cmds.xform(moveControl, pivots = (0, -geoMaxY, 0))
            cmds.makeIdentity(moveControl, apply = True)
            
            #match to current model specific transforms - control
            cmds.rotate(0,180,0, control)
            cmds.makeIdentity(control, apply = True)
            
            #delete old placeholder
            cmds.delete(self.placeHolder)
            
            #rename
            self.animControlMain = cmds.rename(control, "main_ctr")
            self.animControlMove = cmds.rename(moveControl, "move_ctr")
            for i in cmds.listRelatives(self.animControlMain, allDescendents = True, type = "nurbsCurve"):
                cmds.rename(i, "main_ctr_shp")
            
            #create groups
            self.HDMAR_grp = cmds.group(name = "main_top_grp", world = True, empty = True)
            self.controlGrp = cmds.group(name = "main_ctr_grp", world = True, empty = True)
            self.geoGrp = cmds.group(name = "main_geo_grp", world = True, empty = True)
            self.skeletonGrp = cmds.group(name = "main_jnt_grp", world = True, empty = True)
            self.moveControlGrp = cmds.group(name = "move_ctr_grp", world = True, empty = True)

            #create hierarchy
            cmds.parent(self.animControlMove, self.moveControlGrp)
            cmds.parent(self.moveControlGrp, self.animControlMain)
            cmds.parent(self.animControlMain, self.controlGrp)
            cmds.parent(geoTransformNodes, self.geoGrp)
            cmds.parent(self.skeletonGrp, self.geoGrp, self.controlGrp, self.HDMAR_grp)
            
            #cleanup - trash anything that made it into geo that isnt geo
            inGeo = cmds.listRelatives(self.geoGrp, 
                children = True,
                type = "transform",
                allDescendents = True)
            for thing in inGeo:
                if not thing in geoTransformNodes:
                    cmds.delete(thing)
            
    #Script By tyler millossi
    #creates shapes for a track (converts the placeholders to final animation controls)
    class RightTrack_anim(SingleFK_anim):
        def __init__(self, geo, children):
            self.geo = geo
            self.children = children
            self.joints = children[1]   
        
        def control(self):    
            #create control
            control = self.createAnimationControl("rightTrack") 
            #move to correct location and rotation
            cmds.rotate(0,180, control)
            farX = 0
            maxY = -100000
            minY = +100000
            maxZ = -100000
            minZ = +100000
            #organize the list better
            geo = [self.geo[0], self.geo[1]]
            geo.extend(self.geo[2])
            #get position info
            for g in geo:
                valuePos = self.getPosInfoOfFarPoints(g)
                if valuePos[0][1] < farX:
                    farX = valuePos[0][1]
                if valuePos[1][0] > maxY:
                    maxY = valuePos[1][0]
                if valuePos[1][1] < minY:
                    minY = valuePos[1][1]
                if valuePos[2][0] > maxZ:
                    maxZ = valuePos[2][0]
                if valuePos[2][1] < minZ:
                    minZ = valuePos[2][1]
            #place controller
            cmds.move(farX - 1, 
                      minY + (maxY - (minY))/2,
                      minZ + (maxZ - (minZ))/2,
                      control)
            cmds.makeIdentity(control, apply = True)
            
            #rename
            self.animControl = cmds.rename(control, "rightTrack_ctr")
            for i in cmds.listRelatives(self.animControl, allDescendents = True, type = "nurbsCurve"):
                cmds.rename(i, "rightTrack_ctr_shp")
            
            #grouping
            group = cmds.group(name = "rightTrack_ctr_grp", world = True, empty = True)
            cmds.matchTransform(group, self.animControl)
            cmds.parent(self.animControl, group)
            for i in self.children[2:]:
                cmds.parent(i, self.animControl)
            #things that cause double transform
            for i in self.children[0]:
                cmds.setAttr("%s.inheritsTransform"%i, 0)
                cmds.parent(i, group)  
                cmds.move(0,0,0, i, objectSpace = True)           
            
            #hide and lock attributes - main control
            for attr in ["sx", "sy", "sz"]:
                cmds.setAttr("%s.%s"%(self.animControl, attr), keyable = False, lock = True) 
                
            #hide and lock attributes - wheel controls
            wheels = cmds.ls("rightTrack_roller_*_ctr")
            wheels.append("rightTrack_front_ctr")
            wheels.append("rightTrack_back_ctr")
            for wheel in wheels:
                for attr in ["sx", "sy", "sz", "rx", "ry", "rz", "tz"]:
                    cmds.setAttr("%s.%s"%(wheel, attr), keyable = False, lock = True) 

            #need to name/rename everything unique
            for obj in cmds.listRelatives(group, allDescendents = True):
                if not "right" in obj:
                    cmds.rename(obj, "rightTrack_%s"%obj) 

    #Script By Tyler millossi
    #creates shapes for a steering (converts the placeholders to final animation controls)
    class Steering_anim(SingleFK_anim):
        
        def control(self):
            #create control
            control = self.createAnimationControl("steering")
            
            #match to current model specific transforms
            cmds.rotate(0,180,0,control)
            cmds.makeIdentity(control, apply = True)
            
            #create single FK
            self.singleJointFK("steering", ["sx", "sy", "sz"], control)#module name / locked attrs / curves

    #Script By tyler millossi
    #creates shapes for a track (converts the placeholders to final animation controls)
    class Track_anim():
        def __init__(self, *args):
            pass
        
        def control(self):
            #create control
            control = self.createAnimationControl("track")
            cmds.move(9, 2.3, 0, control)
            cmds.rotate(0,180, 0, control)
        
        def createAnimationControl(self, modName):
            #reference the class
            modName = "leftTrack"
            exec("classInstance = Curves_control.%s%s_control()"%(modName[0].upper(), modName[1:]))
            control = classInstance.create()
            return control    

    #Script By Tyler Millossi
    #creates shapes for a upperBody (converts the placeholders to final animation controls)
    class UpperBody_anim(SingleFK_anim):
        def control(self):
            #create control
            control = self.createAnimationControl("upperBody")
            
            #fix rotation
            cmds.rotate(0,-90,0, control)
            cmds.makeIdentity(control, apply = True)
            
            #position Info - get the position the control z should be
            ZValue = []
            for geo in self.geo:
                ZValue.append(self.getPosInfoOfFarPoints(geo)[2][1] - 0.1)
            geoMinZ = min(ZValue)
            
            placeholderMinZ = cmds.xform(self.placeHolder, query = True, translation = True, worldSpace = True)[2]
            cmds.move(0, 0, geoMinZ-(placeholderMinZ), control)
            cmds.xform(control, pivots = (0,0,-(geoMinZ-(placeholderMinZ))))
            cmds.makeIdentity(control, apply = True)
            
            #create single FK
            self.singleJointFK("upperBody", ["sx", "sy", "sz"], control)#module name / locked attrs / curves
            
            #limit information
            cmds.select(self.animControl)
            self.translateAmount = 2.5
            self.rotateAmount = 15
            ta = self.translateAmount
            ra = self.rotateAmount
            cmds.transformLimits(
                enableRotationX = (1, 1),
                enableRotationZ = (1, 1),
                enableTranslationX = (1, 1),
                enableTranslationY = (1, 1),
                enableTranslationZ = (1, 1),
                rotationX = (-ra, ra),
                rotationZ = (-ra, ra),
                translationX = (-ta, ta), 
                translationY = (-ta, ta),
                translationZ = (-ta, ta))

    #Script By Tyler Millossi
    #creates shapes for a wheel (converts the placeholders to final animation controls)
    class Wheel_anim(SingleFK_anim): 
        
        def control(self):
            #create control
            control = self.createAnimationControl("wheel")
            
            #create single FK
            self.singleJointFK("wheel", ["sx", "sy", "sz"], control)#module name / locked attrs / curves

#************************************************PLACERS**************************************************

#creates controls to adjust pivots. this is before they are coverted to anim controls
class Placers_placer():
    #Script By Tyler Millossi
    #creates shapes for a all placers (place holders)
    class Placer_placer():
        def __init__(self, geo):
            self.geo = geo
        
        def createPlaceHolderControl(self, modName):
            #reference the class
            if len(self.geo) == 0:
                return
            exec("classInstance = Curves_placeHolders.%s%s_placeHolder()"%(modName[0].upper(), modName[1:]))
            control = classInstance.create()
            return control
            
        def createPlacer(self, module_Name, control):
            #is list valid
            if len(self.geo) == 0:
                return
            #rename control and shapes   
            self.placerControl = cmds.rename(control, "%s_plc"%module_Name)
            for i in cmds.listRelatives(self.placerControl, allDescendents = True, type = "nurbsCurve"):
                cmds.rename(i, "%s_plc_shp"%module_Name)
            #match to current model specific transforms
            #place in same location as the geo
            if type(self.geo) == type([]):
                if len(self.geo) > 0:
                    if cmds.objExists(self.geo[0]):
                        cmds.matchTransform(self.placerControl, self.geo[0]) 
            else:
                if cmds.objExists(self.geo):
                    cmds.matchTransform(self.placerControl, self.geo) 

        #user wishes to change what geo will be the door
        def changeGeo(self, newGeo):
            if cmds.objExists(newGeo):
                self.geo = newGeo
                cmds.matchTransform(self.placerControl, self.geo)
        
        #user no longer wants the arm
        def deletePlacer(self):
            if cmds.objExists(self.placerControl):
                cmds.delete(self.placerControl)
    
    #Script By Tyler Millossi
    #creates shapes for a bucket (place holders)
    class Bucket_placer(Placer_placer):
        def placer(self):
            #make a control
            control = self.createPlaceHolderControl("bucket")
            #name and place the placer
            self.createPlacer("bucket", control)

    #Script By Tyler Millossi
    #creates shapes for a arm (place holders)
    class Arm_placer(Placer_placer):    
        def placer(self):
            #make a control
            control = self.createPlaceHolderControl("arm")
            #name and place the placer
            self.createPlacer("arm", control)

    #Script By Tyler Millossi
    #creates shapes for a boom (place holders)
    class Boom_placer(Placer_placer):
        def placer(self):
            #make a control
            control = self.createPlaceHolderControl("boom")
            #name and place the placer
            self.createPlacer("boom", control)

    #Script By Tyler Millossi
    #creates shapes for a door (place holders)
    class Door_placer(Placer_placer):
        def placer(self):
            #make a control
            control = self.createPlaceHolderControl("door")
            #match to current model specific transforms
            cmds.select(control)
            cmds.rotate(90, 90)
            cmds.scale(4,4,4)
            cmds.makeIdentity(apply = True)
            #name and place the placer
            self.createPlacer("door", control)
            
    #Script By ...
    #creates shapes for a Final Drive (place holders)
    class FinalDrive_placer(Placer_placer):
        def placer(self):
            return  
            
    #Script By ...
    #creates shapes for a Front Idler (place holders)
    class FrontIdler_placer(Placer_placer):        
        def placer(self):
            return

    #Script By ...
    #creates shapes for a lowerBody (place holders)
    class LowerBody_placer(Placer_placer):
        def placer(self):
            #make a control
            control = self.createPlaceHolderControl("lowerBody")
            #name and place the placer
            self.createPlacer("lowerBody", control)

    #Script By ...
    #creates shapes for a main (place holders)
    class Main_placer(Placer_placer):
        def placer(self):
            #make a control
            control = self.createPlaceHolderControl("main")
            #name and place the placer
            self.createPlacer("main", control)
            #snap to grid
            cmds.move(0,0,0, self.placerControl)
            #hide and lock attributes - scale
            lockedAttrs = ["tx", "ty", "tz", "rx", "ry", "rz", "sx", "sy", "sz"]
            for attr in lockedAttrs:
                cmds.setAttr("%s.%s"%(self.placerControl, attr), keyable = False, lock = True)  

    #Script By ...
    #creates shapes for rollers (place holders)
    class Rollers_placer(Placer_placer):    
        def placer(self):
            return

    #Script By tyler millossi
    #creates shapes for a Steering (place holders)
    class Steering_placer(Placer_placer):
        def placer(self):
            #make a control
            control = self.createPlaceHolderControl("steering")
            #rotate correctly
            cmds.rotate(0,180,0, control)
            cmds.makeIdentity(control, apply = True)
            #name and place the placer
            self.createPlacer("steering", control)

    #Script By ...
    #creates shapes for a track (place holders)
    class Track_placer():
        def __init__(self, *args):
            pass
              
        def placer(self):
            self.geo = "tempName"
            self.placerControl = "tempName"
            return

    #Script By Tyler Millossi
    #creates shapes for a upperBody (place holders)
    class UpperBody_placer(Placer_placer):    
        def placer(self):
            #make a control
            control = self.createPlaceHolderControl("upperBody")
            #name and place the placer
            self.createPlacer("upperBody", control)
        
    #Script By ...
    #creates shapes for a track (place holders)
    class Wheel_placer(Placer_placer):
        def placer(self):
            #make a control
            control = self.createPlaceHolderControl("wheel")
            #name and place the placer
            self.createPlacer("wheel", control)

#**************************************************MAIN**************************************************************
#Script By Tyler Millossi
#Functions for UI to use (parent class)
class Main():
    def getPlacerClass(self, moduleName, geo):
        #self.setNamespaceToTool()
        #disable Soft select - soft select will change the creation process of the curves
        mel.eval("softSelect -e -softSelectEnabled false;")
        #delete old placer if exists
        try:
            exec("self.%s_placer_classInstance.deletePlacer()"%moduleName)
        except:
            pass
        #create placer
        geo = self.getOnlyMeshFromSelection(geo)
        exec("self.%s_placer_classInstance = Placers_placer.%s%s_placer(geo)"%(moduleName, 
            moduleName[0].upper(), 
            moduleName[1:]))
        exec("control = self.%s_placer_classInstance.placer()"%moduleName)
        return control
        
    def deletePlacerClass(self, moduleName):
        exec("self.%s_placer_classInstance.deletePlacer()"%moduleName)
        exec("self.%s_placer_classInstance = None"%moduleName)
        
    def changeGeoPlacerClass(self, moduleName, newGeo):
        geo = self.getOnlyMeshFromSelection(newGeo)
        exec("self.%s_placer_classInstance.changeGeo(geo)"%moduleName)
    
    #come back to this
    def getAnimClass(self, moduleName):
        #self.setNamespaceToTool()
        #disable Soft select - soft select will change the creation process of the curves
        mel.eval("softSelect -e -softSelectEnabled false;")
        #get info for create anim control
        exec("geo = self.%s_placer_classInstance.geo"%moduleName)
        #add geo to namespace
        
        exec("placeholder = self.%s_placer_classInstance.placerControl"%(moduleName))
        #create anim control
        exec("self.%s_anim_classInstance = Animations_anim.%s%s_anim(placeholder, geo)"%(moduleName, 
            moduleName[0].upper(), 
            moduleName[1:]))
        exec("self.%s_anim_classInstance.control()"%moduleName)
        #parenting
        self.parentGroupsAndJoints(moduleName)
        
        cmds.select(clear = True)
        
    def deleteAnimClass(self, moduleName):
        #because of arm parenting, call a function to unparent
        if moduleName == "boom" or moduleName == "arm":
            self.keepChildrenDelete(moduleName)
        #delete control and set instance to None
        exec("self.%s_anim_classInstance.deleteControl()"%moduleName)
        exec("self.%s_anim_classInstance = None"%moduleName)
    
    def checkHookCanIK(self):
        #if three class exists
        if cmds.objExists("boom_ctr_grp") and cmds.objExists("arm_ctr_grp") and cmds.objExists("bucket_ctr_grp"):
            return True
        else: return False

    def createhookIK(self):
        #create IK
    
        #got to delete stuff
        cmds.parent("bucket_ctr_grp", world = True)
        constraints = cmds.listRelatives("boom_jnt", allDescendents = True, type = "parentConstraint")
        cmds.delete("boom_ctr_grp", constraints)

        #create skinning bones so there can be IK / FK switching
        Ikreturns = cmds.ikHandle(name = "bucket_ikH", startJoint = "boom_jnt", endEffector = "bucket_jnt", solver = "ikSCsolver")
        cmds.rename("effector1", "bucket_efr")
        
        #bucket control drives Ik joint
        cmds.parent(Ikreturns[0], "bucket_ctr")
        cmds.setAttr("%s.visibility"%Ikreturns[0], 0)
        
        #constrain the rotation of the control to the joint
        cmds.orientConstraint("bucket_ctr", "bucket_jnt", name = "bucket_jnt_ortCt")
        
        #lock ik control attrs
        for attr in ["ry", "rz", "tx"]:
            cmds.setAttr("%s.%s"%("bucket_ctr", attr), keyable = False, lock = True)
        
        #unlock ik control attrs
        for attr in ["ty", "tz"]:
            cmds.setAttr("%s.%s"%("bucket_ctr", attr), keyable = True, lock = False)
        
        self.parentGroupsAndJoints("IKbucket")   
                    
    def keepChildrenDelete(self, moduleName):
        if cmds.objExists("bucket_jnt") and cmds.objExists("bucket_ctr_grp"):
            cmds.parent("bucket_jnt", "bucket_ctr_grp", world = True)
         
        if cmds.objExists("arm_jnt") and cmds.objExists("arm_ctr_grp"):
            cmds.parent("arm_jnt", "arm_ctr_grp", world = True) 
    
    def checkCanCreateTrack(self, *args):
        #if front and back exists
        try:
            back = self.getParent(self.finalDrive_placer_classInstance.geo[-1])
            front = self.getParent(self.frontIdler_placer_classInstance.geo[-1])
            canRun = True
        except:
            canRun = False
        if canRun:
            try:
                rollers = []
                for g in self.rollers_placer_classInstance.geo:
                    rollers.append(self.getParent(g))
            except:
                rollers = []
        else:
            print "something happend, not able to create track"
            return
        cmds.button("HDMAR_custom_track_btn", edit = True, enable = False)
        #get UI info
        bothSides = cmds.checkBox("HDMAR_track_left_right_chb", query = True, value = True)
        if bothSides:
            left = cmds.textFieldGrp("HDMAR_track_left_TFG", query = True, text = True)
            right = cmds.textFieldGrp("HDMAR_track_right_TFG", query = True, text = True)
        treadAmount = cmds.intSliderGrp("HDMAR_track_treadAmount_ISG", query = True, value = True)
        treadGeo = cmds.optionMenu("HDMAR_track_treadAmount_OM", query = True, value = True)
            
        #create track - left
        trackInfo = self.createTrack(treadAmount, front, back, treadGeo, rollers)
        geo = [front, back, rollers]
        self.createTrackControls(trackInfo, geo, "left")
        self.parentGroupsAndJoints("leftTrack")
        
        #check if option to create other side
        if bothSides:
            front_2 = cmds.ls(front.replace(left,right,1))[0]
            back_2 = cmds.ls(back.replace(left,right,1))[0]
            rollers_2 = []
            for i in range(len(rollers)):
                rollers_2.append(cmds.ls(rollers[i].replace(left,right,1))[0])   
            
            #create track - right
            trackInfo_2 = self.createTrack(treadAmount, front_2, back_2, treadGeo, rollers_2)
            geo_2 = [front_2, back_2, rollers_2]
            self.createTrackControls(trackInfo_2, geo_2, "right") 
            self.parentGroupsAndJoints("rightTrack")

        #create anim control    
    def createTrackControls(self, trackInfo, geo, side):
        #rename
        cmds.rename("treadCurve_cirBaseWire", "%s_treadCurve_cirBaseWire"%side)
        
        #track info == locatorGroup, valueInfoF, valueInfoB
        locatorGroup = trackInfo[0]
        locators = cmds.listRelatives(locatorGroup, 
                        children = True, 
                        allDescendents = True, 
                        type = "transform")
        valueInfoF = trackInfo[1]
        valueInfoB = trackInfo[2]
        rollerInfo = trackInfo[3]
        objects = trackInfo[4]
        pushOut = 0.5
        
        #for determining distance
        plusMas = cmds.shadingNode("plusMinusAverage", asUtility = True, name = "%sspinTrack_masterRotations_pluMin"%side)
        
        #organize info for creating controls
        wheels = [["front", valueInfoF, locators[6:11], [geo[0]]], ["back", valueInfoB, locators[:5], [geo[1]]]]
        for i in range(len(rollerInfo)):
            wheels.append(["roller_%s"%i, rollerInfo[i], locators[11+i*2:11+i*2+2], [geo[2][i]]])
        
        #create each control
        groups = objects
        joints = []
        for control in wheels:
            #get controller size
            distance = self.getDistanceBetweenTwoNumbers(control[1][1][0], control[1][1][1])
            
            #create circle control
            circleControl = cmds.circle(name = "%sTrack_%s_ctr"%(side, control[0]),
                radius = distance/2,
                constructionHistory = False)[0]
            cmds.rotate(0,90, circleControl)
            if side == "left": valX_ = control[1][0][0] + pushOut
            else: valX_ = control[1][0][1] - (pushOut)
            cmds.move(valX_,
                control[1][1][0] - self.getDistanceBetweenTwoNumbers(control[1][1][0], control[1][1][1])/2,
                control[1][2][0] - self.getDistanceBetweenTwoNumbers(control[1][2][0], control[1][2][1])/2,
                circleControl)
            
            #skin the geo to joint
            cmds.select(clear = True)
            joint_ = cmds.joint(name = "%sTrack_%s_jnt"%(side, control[0]))
            joints.append(joint_)
            cmds.move(control[1][0][0] - self.getDistanceBetweenTwoNumbers(control[1][0][0], control[1][0][1])/2,
                      control[1][1][0] - self.getDistanceBetweenTwoNumbers(control[1][1][0], control[1][1][1])/2,
                      control[1][2][0] - self.getDistanceBetweenTwoNumbers(control[1][2][0], control[1][2][1])/2,
                      joint_)
            #skin geo to joint
            for geometery in control[3]:
                #get the geo shape node for skinning
                geoShapes = cmds.listRelatives(geometery, shapes = True)
                #skin geo to joint
                skinCluster = cmds.skinCluster(joint_, geoShapes[0], 
                    name = "%sTrack_%s_skinCluster"%(side, control[0]), 
                    toSelectedBones = True, 
                    bindMethod = 0, 
                    skinMethod = 0, 
                    normalizeWeights = 1)[0]
            
            #parent the locators to the control
            cmds.parent(control[2], circleControl)   
            
            #parent constrain the joint to the control
            cmds.parentConstraint(circleControl, joint_, maintainOffset = True, name = "%s_prtCt"%circleControl, skipRotate = "x")
            
    ##########NEED TO CALCULATE FOR TRANSLATE TO USE FOR SPIN#################valGroup
    
            #create multiply divide node for the rotation of the wheel            
            #distance / circumference = revolutions
            spinZMulDiv1 = cmds.shadingNode("multiplyDivide", asUtility = True, name = "%sTrack_%s_spin_mulDiv"%(side, control[0]))
            cmds.setAttr("%s.operation"%spinZMulDiv1, 2)#division
            cmds.connectAttr("%s.output1D"%plusMas, "%s.input1X"%spinZMulDiv1)#translateZ
            cmds.setAttr("%s.input2X"%spinZMulDiv1, 3.14159265*distance)#pie*Diameter = circumference
            
            #revolutions to degrees
            spinZMulDiv2 = cmds.shadingNode("multiplyDivide", asUtility = True, name = "%sTrack_%s_degrees_mulDiv"%(side, control[0]))
            cmds.connectAttr("%s.outputX"%spinZMulDiv1, "%s.input1X"%spinZMulDiv2)
            cmds.setAttr("%s.input2X"%spinZMulDiv2, 360.0)#revolutions to degrees
            
            #user can edit
            spinZMulDiv3 = cmds.shadingNode("multiplyDivide", asUtility = True, name = "%sTrack_%s_factor_mulDiv"%(side, control[0]))
            cmds.connectAttr("%s.outputX"%spinZMulDiv2, "%s.input1X"%spinZMulDiv3)
            cmds.setAttr("%s.input2X"%spinZMulDiv3, 1)
            
            #offset
            plus = cmds.shadingNode("plusMinusAverage", asUtility = True, name = "%sTrack_%s_offset_pluMin"%(side, control[0]))
            cmds.connectAttr("%s.outputX"%spinZMulDiv3, "%s.input1D[0]"%plus)
            
    ######################CONNECT#########################
            cmds.connectAttr("%s.output1D"%plus, "%s.rx"%joint_)                                    
            
            #create control group
            group = cmds.group(name = "%sTrack_%s_ctr_grp"%(side, control[0]), world = True, empty = True)
            cmds.matchTransform(group, circleControl)
            cmds.parent(circleControl, group)
            groups.append(group)
            
        groups.insert(1, joints)
        groups.append(cmds.listRelatives(locatorGroup, type = "transform", children = True, allDescendents = True))
        #should be any locators leftover
        
        #create anim control
        exec("self.%sTrack_anim_classInstance = Animations_anim.%s%sTrack_anim(geo, groups)"%(side, side[0].upper(), side[1:]))
        exec("self.%sTrack_anim_classInstance.control()"%side) 
        
        #fix parenting
        for i in ["%sTrack_TreadFull"%side, "%s_treadCurve_cirBaseWire"%side]:
            cmds.parent(i, "%sTrack_ctr"%side)
            cmds.setAttr("%s.inheritsTransform"%i, 1)
            cmds.move(0, 0, 0, i)
        
        #fix track geo
        geoGroup = cmds.group(name = "%sTrack_geo_grp"%side, world = True, empty = True)
        cmds.parent("%sTrack_TreadFull"%side, world = True)
        cmds.move(0, 0, 0, "%sTrack_TreadFull"%side)
        cmds.parentConstraint("%sTrack_ctr"%side, geoGroup)
        cmds.parent("%sTrack_TreadFull"%side, geoGroup)
        
        #zero track ctr
        values =  cmds.xform("%sTrack_ctr"%side, query = True, objectSpace = True, translation = True, absolute = True)
        cmds.move(values[0],values[1],values[2], cmds.ls("%sTrack_ctr_shp*.cv[*]"%side), relative = True)
        childs = cmds.listRelatives("%sTrack_ctr"%side, children = True, type = "transform")
        cmds.parent(childs, "%sTrack_ctr"%side, world = True)
        cmds.makeIdentity("%sTrack_ctr"%side)
        cmds.parent("%sTrack_ctr"%side, "%sTrack_ctr_grp"%side)
        cmds.move(0,0,0,"%sTrack_ctr"%side, objectSpace = True)
        cmds.parent(childs, "%sTrack_ctr"%side)

        #handle track rotation
    ##########NEED TO CALCULATE FOR TRANSLATE TO USE FOR SPIN#################valGroup 
        
        arcLenLen = cmds.arclen("%sTrack_treadCurve_cir"%side)

        #create multiply divide node for the rotation of the wheel            
        #distance / circumference = revolutions
        spinZMulDiv1 = cmds.shadingNode("multiplyDivide", asUtility = True, name = "%sSpinTrack_trackSpins_mulDiv"%side)
        cmds.setAttr("%s.operation"%spinZMulDiv1, 2)#division
        cmds.connectAttr("%s.output1D"%plusMas, "%s.input1X"%spinZMulDiv1)
        cmds.setAttr("%s.input2X"%spinZMulDiv1,arcLenLen)
        
        #revolutions to degrees
        spinZMulDiv2 = cmds.shadingNode("multiplyDivide", asUtility = True, name = "%sSpinTrack_trackDegrees_mulDiv"%side)
        cmds.connectAttr("%s.outputX"%spinZMulDiv1, "%s.input1X"%spinZMulDiv2)
        cmds.setAttr("%s.input2X"%spinZMulDiv2, 360.0)
        
        #scale rotation factor
        spinZMulDiv3 = cmds.shadingNode("multiplyDivide", asUtility = True, name = "%sSpinTrack_trackFactor_mulDiv"%side)
        cmds.connectAttr("%s.outputX"%spinZMulDiv2, "%s.input1X"%spinZMulDiv3)
        cmds.setAttr("%s.input2X"%spinZMulDiv3, 1.0)

        #offset
        plus = cmds.shadingNode("plusMinusAverage", asUtility = True, name = "%sSpinTrack_track_offset_pluMin"%side)
        cmds.connectAttr("%s.outputX"%spinZMulDiv3, "%s.input1D[0]"%plus)
        cmds.connectAttr("%s.output1D"%plus, "%sTrack_TreadFull.rx"%side)
        #connect offset
        cmds.addAttr("%sTrack_ctr"%side, 
            longName = "treadRotationOffset", 
            attributeType = "double", 
            defaultValue = 1.0, 
            hidden = False, 
            keyable = True)
        cmds.connectAttr("%s.treadRotationOffset"%("%sTrack_ctr"%side), "%s.input1D[1]"%plus)
        
        #connectFactor
        cmds.addAttr("%sTrack_ctr"%side, 
            longName = "spinFactor", 
            attributeType = "double", 
            defaultValue = 1.0, 
            hidden = False, 
            keyable = True)
        for i in cmds.ls("%s*actor*"%side, type = "multiplyDivide"):
            cmds.connectAttr("%sTrack_ctr.spinFactor"%side, "%s.input2X"%i)
            
        #connectOffset
        for i in cmds.ls("%s*offset*"%side)[1:]:
            ctrl = "%sctr"%i.partition("offset_pluMin")[0]
            cmds.addAttr(ctrl, 
            longName = "rotationOffset", 
            attributeType = "double", 
            defaultValue = 1.0, 
            hidden = False, 
            keyable = True)
            cmds.connectAttr("%s.rotationOffset"%(ctrl), "%s.input1D[1]"%i)

        #add the translates to get the rotation for all spins
        cmds.connectAttr("%sTrack_ctr.tz"%side, "%s.input1D[0]"%plusMas)
        self.connectControlsZtoTrack()
        
        cmds.addAttr("%sTrack_ctr"%side, 
            longName = "rotationOffset", 
            attributeType = "double", 
            defaultValue = 0.0, 
            hidden = False, 
            keyable = True)
        cmds.connectAttr("%sTrack_ctr.rotationOffset"%side, "%s.input1D[1]"%plusMas)
        
        cmds.delete(locatorGroup)
    
    def connectControlsZtoTrack(self):
        for side in ["left", "right"]:
            plusMas = "%sspinTrack_masterRotations_pluMin"%side
            if cmds.objExists(plusMas):
                index = 2
                for i in ["move_ctr", "lowerBody_ctr"]:
                    if cmds.objExists(i):
                        if not cmds.listConnections("%s.input1D[%s]"%(plusMas, index)):
                            cmds.connectAttr("%s.tz"%i, "%s.input1D[%s]"%(plusMas, index))
                
                    index += 1            
        
    def createTrack(self, numOfInst, front, back, treadRepeatObj, rollers):#rollers need to be front to back
        #add function to organize from front to back
        
        #check do we have the main dirrection
        #WForward = [1.0, 0.0, 0.0, "x"]#inital values
        WForward = [0.0, 0.0, 1.0, "z"]#inital values
        treadObj = self.importTread(treadRepeatObj)
        geo = [front, back]
        
        cvPos = [[0.0,0.0],[0.0,0.0],[0.0,0.0],[0.0,0.0],[0.0,0.0],[0.0,0.0],[0.0,0.0],[0.0,0.0],[0.0,0.0],[0.0,0.0]]
        #check for positional values based on geo
        
        #get position values for front
        zForward = WForward[3] == "z"
        
        #get the Center
        cenPos = self.getCenterPointOfObjects(geo)
        
        #calculate curvePoint Position Data
        valueInfoF = self.getPosInfoOfFarPoints(front)
        midXF = self.getDistanceBetweenTwoNumbers(valueInfoF[0][0], valueInfoF[0][1])/2 + valueInfoF[0][1]
        midYF = self.getDistanceBetweenTwoNumbers(valueInfoF[1][0], valueInfoF[1][1])/2 + valueInfoF[1][1]
        midZF = self.getDistanceBetweenTwoNumbers(valueInfoF[2][0], valueInfoF[2][1])/2 + valueInfoF[2][1]
        
        valueInfoB = self.getPosInfoOfFarPoints(back)
        midXB = self.getDistanceBetweenTwoNumbers(valueInfoB[0][0], valueInfoB[0][1])/2 + valueInfoB[0][1]
        midYB = self.getDistanceBetweenTwoNumbers(valueInfoB[1][0], valueInfoB[1][1])/2 + valueInfoB[1][1]
        midZB = self.getDistanceBetweenTwoNumbers(valueInfoB[2][0], valueInfoB[2][1])/2 + valueInfoB[2][1]
        
        centerYDif=self.getDistanceBetweenTwoNumbers(valueInfoF[1][0], valueInfoB[1][0])/2
        if valueInfoF[1][0]>valueInfoB[1][0]:
            centerY = valueInfoB[1][0] + centerYDif
        else:
            centerY = valueInfoF[1][0] + centerYDif
        #               [0][0]     [0][1]        [1][0]    [1][1]       [2][0]     [2][1]
        if zForward:#[[max(xVal), min(xVal)], [max(yVal), min(yVal)], [max(zVal), min(zVal)]]
            cvPos = [[valueInfoF[1][1], midZF],#10
                    self.getPosAlongCircle(front, (135, 0, 0))[1:],#9
                    [midYF, valueInfoF[2][0]],#8
                    self.getPosAlongCircle(front, (45, 0, 0))[1:],#7
                    [valueInfoF[1][0], midZF],#6
                    [centerY, cenPos[2]],#5
                    [valueInfoB[1][0], midZB],#4
                    self.getPosAlongCircle(back, (-45, 0, 0))[1:],#3
                    [midYB, valueInfoB[2][1]],#2
                    self.getPosAlongCircle(back, (-135, 0, 0))[1:],#1
                    [valueInfoB[1][1], midZB]]#0
            distance = self.getDistanceBetweenTwoNumbers(valueInfoF[2][0], valueInfoB[2][1])
        
        else:#xForward
            cvPos = [[valueInfoF[1][1], midXF],#10
                    reversed(self.getPosAlongCircle(front, (0, 0, -135))[:-1]),#9
                    [midYF, valueInfoF[0][0]],#8
                    reversed(self.getPosAlongCircle(front, (0, 0, -45))[:-1]),#7
                    [valueInfoF[1][0], midXF],#6
                    [centerY, cenPos[0]],#5
                    [valueInfoB[1][0], midXB],#4
                    reversed(self.getPosAlongCircle(back, (0, 0, 45))[:-1]),#3
                    [midYB, valueInfoB[0][1]],#2
                    reversed(self.getPosAlongCircle(back, (0, 0, 135))[:-1]),#1
                    [valueInfoB[1][1], midXB]]#0
            distance = self.getDistanceBetweenTwoNumbers(valueInfoF[0][0], valueInfoB[0][1])

        #create circle for deformer
        treadCurve = cmds.circle(name = "treadCurve_cir",
            radius = distance/2,
            sections = 50,
            constructionHistory = False)[0]
        
        #fixes the issue with normals backward
        cmds.rotate(0, 0, -90, treadCurve)
        cmds.xform(treadCurve, centerPivots = True)
        cmds.makeIdentity(apply = True)
        
        #sections for circle with rollers
        sections = len(cvPos) + 1#extra(+1) for middle of bot
        if len(rollers) > 0:
            sections = len(cvPos) + len(rollers)*2
            
        #create circle for shape
        treadCurveShape = cmds.circle(name = "treadCurveShape_cir",
            radius = distance/2,
            sections = sections,
            constructionHistory = False)[0]
        cmds.move(cenPos[0], cenPos[1], cenPos[2], treadCurveShape)
        cmds.xform(treadCurveShape, centerPivots = True)
        cmds.makeIdentity(apply = True)
        
        #circle becomes proper shape
        cvsNum = ["10", "9", "8", "7", "6", "5", "4", "3", "2", "1", "0"]
        if zForward:
            cmds.rotate(0,90,0, treadCurve)            
            for i in range(len(cvsNum)):#11
                cmds.move(0, cvPos[i][0], cvPos[i][1], 
                    ["%s.cv[%s]"%(treadCurveShape, cvsNum[i]),
                     "%s.cv[%s]"%(treadCurveShape, cvsNum[i])])
            
            #a small scaling 
            for wheel in [[front, "6:10"], [back, "0:4"]]:
                pivot = cmds.xform(wheel[0], 
                        query = True, 
                        worldSpace = True, 
                        rotatePivot = True)
                cmds.scale(1, 1.12, 1.12, 
                    "%s.cv[%s]"%(treadCurveShape, wheel[1]), 
                    relative = True, 
                    pivot = pivot)
            
            valueInfoR = []
            if len(rollers) == 0:
                cmds.move(0, 0, cenPos[2], "%s.cv[11]"%treadCurveShape)
            else:
                #get rollers bot position Y
                index = len(cvPos)
                for i in range(index, len(rollers)+index):                    
                    valueInfo = self.getPosInfoOfFarPoints(rollers[i-len(cvPos)])
                    midZ = self.getDistanceBetweenTwoNumbers(valueInfo[2][0], valueInfo[2][1])/2 + valueInfo[2][1]
                    cmds.move(0, valueInfo[1][1], midZ, "%s.cv[%s]"%(treadCurveShape, index))
                    index += 1
                    cmds.move(0, valueInfo[1][1], midZ, "%s.cv[%s]"%(treadCurveShape, index))
                    index += 1
                    valueInfoR.append(valueInfo)
           
        else:#not done x forward
            cmds.rotate(0,180,0, treadCurve)
            for i in range(6):
                cmds.move(cvPos[i][1], cvPos[i][0], 0, 
                    ["%s.ep[%s]"%(treadCurveShape, cvsNum[i]), 
                     "%s.ep[%s]"%(treadCurveShape, cvsNum[i])])
            cmds.move(cenPos[0], cvPos[3][0], 0, "%s.ep[0]"%treadCurveShape)
            if len(rollers) == 0:
                cmds.move(cenPos[0], 0, 0, "%s.ep[4]"%treadCurveShape)
            
        #push out the curve
        if zForward:
            cmds.setAttr("%s.tx"%(treadCurveShape), cenPos[0])
            cmds.setAttr("%s.tx"%(treadCurve), cenPos[0])
        else:
            cmds.setAttr("%s.tz"%(treadCurveShape), cenPos[2])
            cmds.setAttr("%s.tz"%(treadCurve), cenPos[2])
        cmds.xform(treadCurveShape, treadCurve, centerPivots = True)
        cmds.makeIdentity(treadCurveShape, treadCurve, apply = True)
                
        #option for user to edit track before or after creation
        clusterGroup = cmds.group(name = "cluster_grp", world = True, empty = True)
        locatorGroup = cmds.group(name = "locator_grp", world = True, empty = True)
        cvs = cmds.ls("%s.cv[*]"%treadCurveShape, flatten = True)
        for i in range(len(cvs)):
            loc = cmds.spaceLocator(name = "%s_loc_%s"%(treadCurveShape, i))[0]
            cmds.scale(3,3,3, loc)
            cmds.setAttr("%s.visibility"%loc, 0)
            cvPos = cmds.xform(cvs[i], query = True, translation = True, worldSpace = True)
            cmds.move(cvPos[0], cvPos[1], cvPos[2], loc)
            cluster = cmds.cluster(cvs[i], name = "%s_clu_%s_"%(treadCurveShape, i))[1]
            cmds.setAttr("%s.visibility"%cluster, 0)
            cmds.parent(cluster, clusterGroup)
            cmds.parent(loc, locatorGroup)
            cmds.parentConstraint(loc, cluster, name = "%s_prtCt"%loc)##
        cmds.setAttr("%s.visibility"%locatorGroup, 0) 
          
        #animating the object along a curve         
        motPath = cmds.pathAnimation(treadObj, treadCurve, 
            follow = True,
            followAxis = "z",
            upAxis = "y",
            worldUpType = "normal",
            inverseUp = True,
            startTimeU = 1,
            endTimeU = numOfInst)
 
        #make linear
        cmds.keyTangent("%s_uValue"%motPath, 
            time = (1, numOfInst), 
            inTangentType = "linear", 
            outTangentType = "linear")
        
        #duplicate track on curve
        track = []
        for i in range(1, numOfInst):
            cmds.currentTime(i)
            track.append(cmds.duplicate(treadObj)[0])
        cmds.delete(motPath, treadObj)
        treadObj = cmds.polyUnite(track, n="TreadFull",ch=False)
        
        #match pivot
        cmds.matchTransform(treadObj, treadCurve, pivots = True)
        
        #create wire deformer
        wire = cmds.wire(treadObj, wire = treadCurve, name = "_wire")
        cmds.setAttr("%s.dropoffDistance[0]"%wire[0], 40)
        cmds.setAttr("treadCurve_cirBaseWire.inheritsTransform", 0)
        
        #rebuild curve
        cmds.rebuildCurve(
            treadCurveShape, 
            constructionHistory = False,
            spans = 50)#having a high number helps with wavy ness
        
        #make shape the right shape 
        blendShape = cmds.blendShape(treadCurveShape, treadCurve)[0]
        cmds.setAttr("%s.%s"%(blendShape, treadCurveShape), 1)
        
        objects = [[treadObj[0], treadCurve, treadCurveShape], clusterGroup]
        
        #visibility of curve
        for i in [treadCurveShape, treadCurve]:
            cmds.setAttr("%s.visibility"%i, 0)
        
        #needs to return info for the controls to be created
        return locatorGroup, valueInfoF, valueInfoB, valueInfoR, objects
        
    #positions along a circle
    def getPosAlongCircle(self, geo, rotate):
        valueInfo = self.getPosInfoOfFarPoints(geo)
        distance = self.getDistanceBetweenTwoNumbers(valueInfo[1][0], valueInfo[1][1])
        loc = cmds.spaceLocator(name = "diffinePointCircle_loc_temp")[0]
        cmds.matchTransform(loc, geo)
        cmds.makeIdentity(apply = True)
        cmds.rotate(rotate[0], rotate[1], rotate[2], relative = True)
        cmds.move(0,distance/2,0, relative = True, objectSpace = True)
        pos = cmds.xform(loc, query = True, worldSpace = True, rotatePivot = True)
        cmds.delete(loc)
        return pos
    
    #calculate difference between the two
    def getDistanceBetweenTwoNumbers(self, num1, num2):
        return abs(num1-(num2))
            
        #make group To get the Center of loc
    def getCenterPointOfObjects(self, objects):
        locs = []
        for obj in objects:
            loc = cmds.spaceLocator(name = "diffineCenter_loc_temp")[0]
            cmds.matchTransform(loc, obj)
            locs.append(loc)
        cmds.select(locs)    
        tempGrp = cmds.group(name = "diffineCenter_grp_temp")
        cenPos = cmds.xform(tempGrp, query = True, worldSpace = True, rotatePivot = True)
        cmds.delete(tempGrp)
        return cenPos
    
    def getPosInfoOfFarPoints(self, geo):
        xVal = []
        yVal = []
        zVal = []
        for vert in cmds.ls("%s.vtx[*]"%geo, flatten = True):
            vertPos = cmds.xform(vert, query = True, translation = True, worldSpace = True)
            xVal.append(vertPos[0])
            yVal.append(vertPos[1])
            zVal.append(vertPos[2]) 
        valueInfo = [[max(xVal), min(xVal)], [max(yVal), min(yVal)], [max(zVal), min(zVal)]]
        return valueInfo

    def importTread(self, name = "tread1"):
        path = "%sHDMAR_scripts/Geometry/%s.obj"%(cmds.internalVar(userScriptDir = True), name)
        cmds.file(path, i=True)
        return "%s_geo"%name
        
    def parentGroupsAndJoints(self, name):   
        self.connectControlsZtoTrack()
        
        parent = None
        child = None
        if name == "lowerBody":
            parent = ["move_ctr", "main_jnt_grp"]
            child = ["upperBody"]
        elif name == "upperBody":
            parent = ["lowerBody_ctr", "lowerBody_jnt"]
            child = ["steering", "boom", "door"]
        elif name == "steering" or name == "door":
            parent = ["upperBody_ctr", "upperBody_jnt"]
        elif name == "leftTrack" or name == "rightTrack":
            if cmds.objExists("move_ctr"):
                cmds.parent(cmds.ls("*Track_geo_grp"), "main_geo_grp")
            if cmds.objExists("lowerBody_ctr"):
                parent = ["lowerBody_ctr", "lowerBody_jnt"]
            elif cmds.objExists("move_ctr"):
                parent = ["move_ctr", "main_jnt_grp"]
            if parent != None: 
                cmds.parent("%s_ctr_grp"%name, parent[0])
                wheels = cmds.ls("%s_*_jnt"%name)
                for w in wheels:
                    cmds.parent(w, parent[1])
            return
        elif name == "bucket" or name == "arm" or name == "boom" :
            parent = ["upperBody_ctr", "upperBody_jnt"]
            if name == "boom": child = ["arm"]    
            if name == "arm":
                if cmds.objExists("boom_ctr"): parent = ["boom_ctr", "boom_jnt"]
                child = ["bucket"]
            if name == "bucket":
                if cmds.objExists("arm_ctr"): parent = ["arm_ctr", "arm_jnt"]
        elif name == "IKbucket":
            name = "bucket"
            parent = ["upperBody_ctr", "dontChangeJointParent"]
        elif name == "main":
            for i in ["lowerBody", "upperBody", "steering", "door", "bucket", "arm", "boom"]:
                if cmds.objExists("%s_ctr_grp"%i) and cmds.listRelatives("%s_ctr_grp"%i, parent = True) == None: 
                    cmds.parent("%s_ctr_grp"%i, "move_ctr")
                if cmds.objExists("%s_jnt"%i) and cmds.listRelatives("%s_jnt"%i, parent = True) == None:
                    cmds.parent("%s_jnt"%i, "main_jnt_grp") 
            for i in ["leftTrack", "rightTrack"]:
                if cmds.objExists("%s_geo_grp"%i):
                    cmds.parent("%s_geo_grp"%i, "main_geo_grp")
                if cmds.objExists("%s_ctr_grp"%i) and cmds.listRelatives("%s_ctr_grp"%i, parent = True) == None:
                    cmds.parent("%s_ctr_grp"%i, "move_ctr")
                    wheels = cmds.ls("%s_*_jnt"%i)
                    for w in wheels:
                        cmds.parent(w, "main_jnt_grp")
                    
        if parent != None:
            if cmds.objExists(parent[0]): cmds.parent("%s_ctr_grp"%name, parent[0])
            if cmds.objExists(parent[1]): cmds.parent("%s_jnt"%name, parent[1])  

            if child != None:
                for c in child:
                    if cmds.objExists("%s_ctr_grp"%c): cmds.parent("%s_ctr_grp"%c, "%s_ctr"%name)
                    if cmds.objExists("%s_jnt"%c): cmds.parent("%s_jnt"%c, "%s_jnt"%name)
                #for track - special case
                if name == "lowerBody":
                    wheels = cmds.ls("*Track_*_jnt")
                    if wheels:
                        for w in wheels:
                            cmds.parent(w, "lowerBody_jnt")
                        if cmds.objExists("leftTrack_ctr_grp"): cmds.parent("leftTrack_ctr_grp", "lowerBody_ctr")
                        if cmds.objExists("rightTrack_ctr_grp"): cmds.parent("rightTrack_ctr_grp", "lowerBody_ctr")
                            
        
    def getOnlyMeshFromSelection(self, geo):
        cmds.select(geo, replace = True)
        meshs = cmds.ls(selection = True, type = "mesh")
        cmds.select(meshs, replace = True)
        for g in geo:
            cmds.select(cmds.listRelatives(g, type = "mesh"), add = True)
        OnlyMeshs = cmds.ls(selection = True, type = "mesh")
        cmds.select(clear = True)
        
        return OnlyMeshs
        
    def getParent(self, geo):
        parent = cmds.listRelatives(geo, parent = True)[0].encode("utf-8")
        return parent
    
#Script By Rodolfo
#creates UI
class MainUI(Main):
    URL_ICON_PATH = "%sHDMAR_scripts/Icons/"%cmds.internalVar(userScriptDir = True)  

    # Question mark button links
    smartRigLink = "youtube.com/watch?v=MPzCYW8iG1Q"
    
    #Smart setup steps in a list
    #List of lists
    smartSetupList = [
#   Title_TX                        Icon,                  Instruction1_TX                   										Instruction2_TX                   						          Action(4)                        Action Parameter,        Button1  Button2 skip 		Require Selection?(8)
    ["Welcome to the smart setup!", "everything_icon.png", "Press 'Next' to begin",             									"",                      	                                      "",                              "",                     "Next",   0,  False],
    ["Main Controller",             "main_icon_1.png",     "Select all your geo, make sure it points at the Z+ axis",          		"Then press 'Next'",                                              "SetupSmartMainController",      "",                     "Next",   0,  True],
    #lower body (2)
	["Lower Body Controller",       "lowerBody_icon.png",  "Select the geo for the excavator's lower half",     					"Then press 'Next'",                                              "loadSelectedList",              "HDMAR_lowerBody_TFBG", "Next",   0,  True],
    ["Lower Body Controller",       "lowerBody_icon.png",  "Position the curve to the pivot of your lower half",    				"Then press 'Next'",                                              "createControlsButtonPress",     "lowerBody",            "Next",   0,  False],
    #upper body (4)
	["Set up Upper body?",          "",			           "Would you like setting up the excavator's Upper Body?",				    "(Choosing 'No' Will skip to the Tracks)",       	 			  "",   						   "",                     "Yes",    21, False],
    ["Upper Body Controller",       "upperBody_icon.png",  "Select the geo for the excavator's rotating upper half",     			"Then press 'Next'",                                              "loadSelectedList",              "HDMAR_upperBody_TFBG", "Next",   0,  True],
    ["Upper Body Controller",       "upperBody_icon.png",  "Position the curve to the pivot of your upper half",    				"Then press 'Next'",                                              "createControlsButtonPress",     "upperBody",            "Next",   0,  False],
    #door(7)
    ["Set up Door?",                "",			           "Would you like setting up the excavator's door?",                       "(Choosing 'No' will skip to the steering wheel)",       	 	  "",   						   "",                     "Yes",    10, False],
    ["Door Controller", 		    "door_icon.png", 	   "Select the geo for the excavator's door",     							"Then press 'Next'",                                              "loadSelectedList",   		   "HDMAR_door_TFBG",      "Next",   0,  True],
    ["Door Controller", 		    "door_icon.png",       "Position the curve to the pivot of your door",    						"Then press 'Next'",                                              "createControlsButtonPress",     "door",                 "Next",   0,  False],
    #steering wheel (10)
    ["Set up Steering wheel?",      "",	                   "Would you like setting up the excavator's steering wheel?",             "(Choose 'No' to skip to the excavator's boom)",       	 		  "",   						   "",                     "Yes",    13, False],
    ["Steering Wheel Controller", 	"steer_icon.png", 	   "Select the geo for the excavator's steering wheel",     				"Then press 'Next'",                                              "loadSelectedList",              "HDMAR_steering_TFBG",  "Next",   0,  True],
    ["Steering Wheel Controller", 	"steer_icon.png",      "Position the curve to the pivot of your steering wheel",    			"Then press 'Next'",                                              "createControlsButtonPress",     "steering",             "Next",   0,  False],
	#boom (!3)
    ["Set up Boom?",                "",					   "Would you like setting up the excavator's hook?",                       "(Choose 'No' to skip to the excavator's track)",       	 	  "",   						   "",                     "Yes",    21, False],
    ["Boom Controller", 		    "boom_icon.png", 	   "Select the geo for the excavator's boom",     							"Then press 'Next'",                                              "loadSelectedList",   		   "HDMAR_boom_TFBG",      "Next",   0,  True],
    ["Boom Controller", 		    "boom_icon.png",       "Position the curve to the pivot of your boom",    						"Then press 'Next'",                                              "createControlsButtonPress",     "boom",                 "Next",   0,  False],
	#arm (16)
	["Arm Controller", 		        "arm_icon.png", 	   "Select the geo for the excavator's arm",     							"Then press 'Next'",                                              "loadSelectedList",   		   "HDMAR_arm_TFBG",       "Next",   0,  True],
    ["Arm Controller", 		        "arm_icon.png",    	   "Position the curve to the pivot of your arm",    						"Then press 'Next'",                                              "createControlsButtonPress",     "arm",                  "Next",   0,  False],
	#bucket (18)
	["Bucket Controller", 	        "bucket_icon.png", 	   "Select the geo for the excavator's bucket",     						"Then press 'Next'",                                              "loadSelectedList",   	       "HDMAR_bucket_TFBG",    "Next",   0,  True],
    ["Bucket Controller", 	        "bucket_icon.png",     "Position the curve to the pivot of your bucket",    					"Then press 'Next'",                                              "createControlsButtonPress",     "bucket",               "Next",   0,  False],
	#boom IK  (20)
 	["Set up Hook IK?",             "boom_icon.png",	   "Would you like enabling an IK for the Hook?",                           "(Choose 'No' to skip to the excavator's track)",       	 	  "IKButtonPressed",   			   "",                     "Yes",    21, False],
	#tracks (21)
 	["Set up Tracks?",              "track_icon.png",	   "Would you like setting up the excavator's tracks?", 					"(This is the last set of steps)",       	 					  "",   						   "",                     "Yes",    24, False],
	["Track Controller", 	        "roller_icon.png", 	   "Select all your wheels, from the left side, in order. ",     			"From front to back. Then press 'Next'",                          "SetupGetWheelLists",   	 	   "",                     "Next",   0,  True],
	["Track Controller", 	        "track_icon.png",      "Additional options for the track generation have been made available",  "Choose if you wish to mirror your tracks and your tread amount", "SetupPassValuesAndCreateTrack", "",                     "Next",   0,  False],
	#Done (24)
    ["End of Setup",                "everything_icon.png", "All set! Press 'Next to finish",                                        "",                                                               "",                              "",                     "Next",   0,  False]
    ]

	#Keep track of which element you're pointing at
    smartSetupListElement = 0

    def createUI(self):
        
        #Search for duplicate windows
        if cmds.window("AutoRigger_WIN", exists = True):
            cmds.deleteUI("AutoRigger_WIN")
        
        #Create window with name
        cmds.window("AutoRigger_WIN", 
            title = "Heavy Duty Machine Auto Rigger", 
            sizeable = True, 
            widthHeight = (415, 750), #Maya doesn't size the window when instancing it
            closeCommand = self.closingWindowReminder)
        
        #Create UI layout for the window
        self.createUILayout()
        
        #Resize window
        cmds.window("AutoRigger_WIN", edit = True,
            widthHeight = (415, 750)) #It does resize the window here though
        
        #Display window
        cmds.showWindow("AutoRigger_WIN") 
    
    def closingWindowReminder(self):
        cmds.confirmDialog(title = "Disclaimer", 
                           message = "You will no longer be able to edit the controllers",  
                           defaultButton = "Understood")
        
    def createUILayout(self):
        DarkGray = [0.2, 0.2, 0.2]
        DarkerGray = [0.15, 0.15, 0.15]
        Blue =   [0.15, 0.25, 0.55]
        Purple = [0.31, 0.18, 0.31]
        Green =  [0.13, 0.37, 0.13]
        Orange = [0.48, 0.25, 0]
        Red = [0.4, 0.15, 0.15]
        #Create the layout holder. This carries all the column layouts used for tabs
        cmds.tabLayout("HDMAR_TabMaster_TL", 
            scrollable = True, 
            innerMarginWidth = 5, 
            innerMarginHeight = 5)

        ###Template tab
        cmds.columnLayout("HDMAR_TemplateTab_CL")

        #Choose model frame layout. Is collapsable
        cmds.frameLayout("HDMAR_ChooseModel_FL",label = "Choose Model", 
            width = 400, 
            marginWidth= 5, 
            collapsable = True, 
            collapse = False)
        cmds.separator(style = "none", height = 5)  

        #Option Menu. In demo it has multiple templates, but for our innitial project
        #it only has Excavator as an option
        cmds.optionMenu(label = "Select Template: ")
        cmds.separator(style = "none", height = 5)  
        cmds.menuItem(label = "Excavator")  
        
        #Image loaded
        cmds.iconTextButton(style = "iconOnly", 
            image1 = "%severything_icon.png"%self.URL_ICON_PATH, 
            label = "sphere", 
            height = 320,  
            scaleIcon = True) 
        cmds.separator(style = "none", height = 5)  
        
        #Row layout holding buttons
        cmds.rowLayout(numberOfColumns = 2, columnAlign1 = "center")
        cmds.button("HDMAR_StartSmart_BT",label = "Start Rig Smart Setup", command = self.StartSmartSetup )

        #Smart Setup for proxy rigging
        cmds.setParent("HDMAR_TemplateTab_CL")
        cmds.columnLayout("HDMAR_SmartSetup_CL")
     
        #Done with the frameLayout, so we go back to the column layout
        cmds.setParent("HDMAR_TemplateTab_CL")
        cmds.separator(style = "none", height = 2)  
        
        #Generate Rig Layout
        #This framelayout is invisible until the smart setup begins
        cmds.frameLayout("HDMAR_GenerateRig_FL",label = "Rig Generation Instructions", 
            width = 400,
            marginWidth = 5, 
            # collapsable = True, 
            collapse = False,
            manage=False)
        cmds.separator(style = "none", height = 1)  
        cmds.text("HDMAR_RIG_SmartSetup_Step_Title_TX",
            font = "boldLabelFont", 
            label = "Welcome to the smart setup!", 
            align = "center")

        cmds.columnLayout(columnAlign = "center", width = 400)
        cmds.iconTextButton("HDMAR_RIG_SmartSetup_Step_Icon_ITB", style = "iconOnly", 
            image1 = "%severything_icon.png"%self.URL_ICON_PATH, 
            label = "sphere", 
            width = 100, height = 100, 
            scaleIcon = True) 
        cmds.setParent("..")
        
        cmds.text("HDMAR_RIG_SmartSetup_Step_Instruction1_TX", 
            label = "You shouldn't be able to see this!", 
            align = "left")
        cmds.text("HDMAR_RIG_SmartSetup_Step_Instruction2_TX",
            label = "", 
            align = "left")
        cmds.separator(style = "none", height = 1)  

        #Generate additional fields for set
        cmds.columnLayout("HDMAR_track_smartSetup_additionalOptions_CL",manage=False)

        #Generate fields via a function inside our additional Options Column Layout
        self.generateTracksCheckboxAndTreadAmount("_smartSetup")
        cmds.setParent("..")

        #Add row with buttons
        cmds.rowLayout(numberOfColumns = 2)
        cmds.button("HDMAR_RIG_SmartSetup_NextAction_BT",label = "Next")
        cmds.button("HDMAR_RIG_SmartSetup_SecondAction_BT",label = "No", manage=False)
        
        #We're finally done with all of the first tab, so we go back to the mainTab
        cmds.setParent("HDMAR_TabMaster_TL")

        ###Manual tab
        cmds.columnLayout("HDMAR_ManualTab_CL")

        #Step 1 Add locators FrameLayout
        cmds.frameLayout("HDMAR_Step1_AddLocator_FL", label = "Step 1: Add Locators", 
            width = 400, 
            marginWidth = 5, 
            collapsable = True, 
            collapse = False) 
        
        self.createSubframeWithIconTextsButtonAndOptions("Master", 
            Blue, 
            [["main","main_icon_1.png","youtube.com/watch?v=sEI9zn7nH38&t=17s"],
            ["lowerBody","lowerBody_icon.png","youtube.com/watch?v=sEI9zn7nH38&t=52s"],
            ["upperBody","upperBody_icon.png","youtube.com/watch?v=sEI9zn7nH38&t=70s"]])
        self.createSubframeWithIconTextsButtonAndOptions("Body", 
            Purple, 
            [["door","door_icon.png","youtube.com/watch?v=sEI9zn7nH38&t=122s"],
            ["steering","steering_icon.png","youtube.com/watch?v=sEI9zn7nH38&t=139s"]])
        self.createSubframeWithIconTextsButtonAndOptions("Hook", 
            Green, 
            [["bucket","bucket_icon.png","youtube.com/watch?v=sEI9zn7nH38&t=158s"],
            ["arm","arm_icon.png","youtube.com/watch?v=sEI9zn7nH38&t=179s"],
            ["boom","boom_icon.png","youtube.com/watch?v=sEI9zn7nH38&t=200s"]])
        self.createSubframeWithIconTextsButtonAndOptions("Track", 
            Orange, 
            [["frontIdler","frontIdler_icon.png","youtube.com/watch?v=sEI9zn7nH38&t=237s"],
			["rollers","roller_icon.png","youtube.com/watch?v=sEI9zn7nH38&t=246s"],
			["finalDrive","finalDrive_icon.png","youtube.com/watch?v=sEI9zn7nH38&t=258s"],
			["track","track_icon.png","youtube.com/watch?v=sEI9zn7nH38&t=261s"]])


        #Add annotations after the fact *after creating all the text icon buttons and options
        
        #Query annotation (format HDMAR_%s_individualOption_CL )
        cmds.columnLayout("HDMAR_main_individualOption_CL", edit = True,
            annotation = "This is the main controller, which controls every other controller."\
                         "Place its pivot on the model's center mass, attached to the floor. "\
                         "Best not to move it before moving the 'ROOT' controller")
        cmds.columnLayout("HDMAR_lowerBody_individualOption_CL", edit = True,
            annotation = "This is the lowerBody controller. "\
                         "Place its pivot on the model's center mass, attached to the floor. "\
                         "Best used to translate the vehicle around")
        cmds.columnLayout("HDMAR_upperBody_individualOption_CL", edit = True,
            annotation = "This is the upperBody controller. "\
                         "Place its pivot at the center of the top body you will be rotating. "\
                         "Use it to spin the top part of the vehicle.")

        cmds.columnLayout("HDMAR_door_individualOption_CL", edit = True,
            annotation = "This is the door controller. "\
                         "Place its pivot at the hinge of the door to turn it propeTXy.")
        cmds.columnLayout("HDMAR_steering_individualOption_CL", edit = True,
            annotation = "This is the steering controller. "\
                         "Place its pivot at the center of the steering wheel to twist it.")

        cmds.columnLayout("HDMAR_bucket_individualOption_CL", edit = True,
            annotation = "This is the bucket controller. "\
                         "Place its pivot where the excavator's scoop would hinge. "\
                         "Can only be rotated in a single axis.")
        cmds.columnLayout("HDMAR_arm_individualOption_CL", edit = True,
            annotation = "This is the arm controller. "\
                         "Place its pivot where the 'elbow' of the excavator's arm is. "\
                         "Can only be rotated in a single axis.")
        cmds.columnLayout("HDMAR_boom_individualOption_CL", edit = True,
            annotation = "This is the cog controller. "\
                         "Place its pivot at the base of the excavator's arm. "\
                         "Can only be rotated in a single axis.")

        cmds.columnLayout("HDMAR_finalDrive_individualOption_CL", edit = True,
            annotation = "This is the final drive controller inside the tank tread. "\
                         "Place its pivot in the center, of where the back wheel is. "\
                         "Can only be rotated in a single axis.")
        cmds.columnLayout("HDMAR_rollers_individualOption_CL", edit = True,
            annotation = "This is the controller for the rollers. "\
                         "Place the locators at the center of each one of the inner rollers. "\
                         "Can only be rotated in a single axis.")
        cmds.columnLayout("HDMAR_frontIdler_individualOption_CL", edit = True,
            annotation = "This is the cog controller. "\
                         "Place its pivot at the base of the excavator's arm. "\
                         "Can only be rotated in a single axis.")
        cmds.columnLayout("HDMAR_track_individualOption_CL", edit = True,
            annotation = "This is the track controller. "\
                         "Place its pivot at the center mass of the treads. "\
                         "Can only be rotated in a single axis.")

        #Use extra column layout HDMAR_%s_CL_extra to add the IK button for the hook
        cmds.setParent("HDMAR_Hook_CL_extra")
        cmds.button("hookIK_btn", label = "IK", 
            backgroundColor = DarkGray, 
            enable = False, 
            width= 50, 
            command = partial(self.IKButtonPressed))

        #Add Extra Options for the COG fields
        cmds.setParent("HDMAR_upperBody_individualOption_CL")
        cmds.columnLayout()
        cmds.rowLayout(numberOfColumns=1)
        '''
        cmds.checkBox("HDMAR_upperBody_Limit_CB", label = "Limit rotation and translation", 
            align = "right", 
            changeCommand = self.toggleCOGOptions)
        '''
        cmds.setParent("..")
        cmds.columnLayout()
        cmds.floatSliderGrp("HDMAR_upperBody_RotationLimit_FSG", label = "Rotation Limits",
            field = True, 
            minValue = 0, 
            maxValue = 90, 
            fieldMinValue = 0, 
            fieldMaxValue = 360, 
            value = 15, 
            columnWidth = [[1, 90], [2, 100], [3, 175]], 
            columnAlign = [[1, "left"]],
            manage = False) 
        cmds.floatSliderGrp("HDMAR_upperBody_TranslationLimit_FSG",  label = "Translation Limits", 
            field = True,
            minValue = 0, 
            maxValue = 10, 
            fieldMinValue = 0, 
            fieldMaxValue = 100, 
            value = 2.5, 
            columnWidth = [[1, 90], [2, 100], [3, 175]], 
            manage = False )

        #Hide "Create controls" buttons for the first 3 options in the "TRACK" sub frame layout "HDMAR_%s_TFBG"%name
        cmds.button("HDMAR_finalDrive_btn", edit = True, manage = False)
        cmds.button("HDMAR_rollers_btn", edit = True, manage = False)
        cmds.button("HDMAR_frontIdler_btn",edit = True,  manage = False)

        #Disable the "Track" button
        cmds.iconTextButton("HDMAR_track_ITB",edit=True, enable = False)

        #We then add change commands to the Text Field Group Buttons for "FinalDrive" and "FrontIdle"   
        #"HDMAR_%s_TFBG"
        cmds.textFieldButtonGrp("HDMAR_finalDrive_TFBG", edit = True, 
            changeCommand = self.CheckTreadWheels, 
            forceChangeCommand = True )
        cmds.textFieldButtonGrp("HDMAR_frontIdler_TFBG", edit = True, 
            changeCommand = self.CheckTreadWheels, 
            forceChangeCommand = True )

        #Additional fields for the track button options
        cmds.setParent("HDMAR_track_individualOption_CL")
        cmds.columnLayout("HDMAR_track_individualOptionContainer_CL", edit=True, manage=False)
        cmds.separator(height = 5)
        cmds.columnLayout("HDMAR_track_additionalOptions_CL")

        #Generate fields via a function inside our additional Options Column Layout
        self.generateTracksCheckboxAndTreadAmount()
       
        #We add a row layout for the create button and question mark
        
        cmds.rowLayout(numberOfColumns=2)
        
        #We create a custom button with tyler's edit
        LightGray = [0.4, 0.4, 0.4]
        cmds.button("HDMAR_custom_track_btn", label = "Create Controls", 
            backgroundColor = LightGray, 
            enable = True, 
            command = partial(self.checkCanCreateTrack)) 
        
        cmds.button(label = "?", 
            backgroundColor = (DarkGray), 
            command = partial(self.showLink, "youtube.com/watch?v=sEI9zn7nH38&t=261s"))
        cmds.setParent("..")

        #Now that we're done witht he first frame layout, so we go back to the column Layout
        cmds.setParent("HDMAR_ManualTab_CL")
        cmds.separator(style = "none", height = 7)
        
        #Done with this tab so we'll go back to the mainTab Holder
        cmds.setParent("HDMAR_TabMaster_TL")
        
        ##EXTRAS tab
        #We create the last tab. A columnlayout for extras (Additional tools and video tutorials)
        extrasLayout = cmds.columnLayout("HDMAR_ExtrasTab_CL")
               
        #framelayout for additional tools
        additionalToolsFrameLayout = cmds.frameLayout(label = "Additional Tools", 
            collapsable = True, 
            collapse = False, 
            width = 400) 
        
        #Tablike frame with darker background #1
        cmds.text(l = "  Rename Selected Module", 
            align = "left", 
            backgroundColor = DarkerGray, 
            height = 20)
        #rowlayout and Label and input
        cmds.rowLayout(numberOfColumns = 2, 
            columnWidth2 = (75, 65), 
            columnAlign = [(1, "left")])
        cmds.text(label = "New Name:")
        terrainNameUser = cmds.textField("HDMAR_renameOBJ_TF",text = "")
        cmds.setParent(additionalToolsFrameLayout)
        
        #rowlayout with 2 buttons
        cmds.rowLayout(numberOfColumns = 2)
        cmds.button(label = "Rename", command = self.renameOBJ)
        cmds.button(label = "?", backgroundColor = DarkGray) 
        cmds.setParent(additionalToolsFrameLayout)
        
        
        #Tablike frame with darker background #2
        cmds.text(label = "  Override Color", 
            align = "left", 
            backgroundColor = DarkerGray, 
            height = 20)
        #rowlayout and Label and input
        cmds.rowLayout(numberOfColumns = 2)
        cmds.colorSliderGrp("HDMAR_colorOverride_CSG", label = "Color", 
            rgb = (0, 0, 1), 
            columnAlign = [(1, "left"), (2, "left"), (3, "left")],
            changeCommand = self.newColorOverride)
        cmds.setParent(additionalToolsFrameLayout)
              
        #parent back up 
        cmds.setParent(extrasLayout)
        
        #Frame layout: Video Tutorials
        videoTutorialsFrameLayout = cmds.frameLayout("HDMAR_VideoTutorials_FL", label = "Video Tutorials", 
            collapsable = True, 
            collapse = False, 
            width = 400, 
            marginWidth = 5) 
        #small framelayouts 5

        self.createSubframeWithIconTextsButtonForVideoTutorials("Template", 
            DarkerGray,
            [["Introduction","youtube.com/watch?v=IsyXRSbqDZ4"],
            ["Rig Generation","youtube.com/watch?v=MPzCYW8iG1Q"]])
        self.createSubframeWithIconTextsButtonForVideoTutorials("Master", 
            Blue,
            [["Main","youtube.com/watch?v=sEI9zn7nH38&t=17s"],
            ["Lower Body","youtube.com/watch?v=sEI9zn7nH38&t=52s"],
            ["Upper Body","youtube.com/watch?v=sEI9zn7nH38&t=70s"]])
        self.createSubframeWithIconTextsButtonForVideoTutorials("Body", 
            Purple,
            [["Door","youtube.com/watch?v=sEI9zn7nH38&t=122s"],
            ["Steering","youtube.com/watch?v=sEI9zn7nH38&t=139s"]])
        self.createSubframeWithIconTextsButtonForVideoTutorials("Hook",
            Green,
            [["Bucket","youtube.com/watch?v=sEI9zn7nH38&t=158s"],
            ["Arm","youtube.com/watch?v=sEI9zn7nH38&t=179s"],
            ["Boom","youtube.com/watch?v=sEI9zn7nH38&t=200s"]])
        self.createSubframeWithIconTextsButtonForVideoTutorials("Track",
            Orange,
            [["Final Drive","youtube.com/watch?v=sEI9zn7nH38&t=237s"],
            ["Rollers","youtube.com/watch?v=sEI9zn7nH38&t=246s"],
            ["Front Idler","youtube.com/watch?v=sEI9zn7nH38&t=258s"],
            ["Track","youtube.com/watch?v=sEI9zn7nH38&t=261s"]])
        
        #Done with this tab so we'll go back to the mainTab Holder
        cmds.setParent("HDMAR_TabMaster_TL")
        
        #We want to create the next tab (and name the first one)
        cmds.tabLayout("HDMAR_TabMaster_TL", edit = True, 
            tabLabel = (("HDMAR_TemplateTab_CL", "Template"), 
                        ("HDMAR_ManualTab_CL", "Manual"),
                        ("HDMAR_ExtrasTab_CL", "Extras")))
    

    # FUNCTIONS 

    def SetupSetLayoutInfo(self,*args):
        cmds.text("HDMAR_RIG_SmartSetup_Step_Title_TX", edit = True, 
            label = self.smartSetupList[self.smartSetupListElement][0])
        cmds.iconTextButton("HDMAR_RIG_SmartSetup_Step_Icon_ITB",
					edit=True, 
					image1 = "%s%s"%(self.URL_ICON_PATH, self.smartSetupList[self.smartSetupListElement][1])) 
        cmds.text("HDMAR_RIG_SmartSetup_Step_Instruction1_TX", edit = True, 
            label = self.smartSetupList[self.smartSetupListElement][2])
        cmds.text("HDMAR_RIG_SmartSetup_Step_Instruction2_TX", edit = True, 
            label = self.smartSetupList[self.smartSetupListElement][3])
        cmds.button("HDMAR_RIG_SmartSetup_NextAction_BT",
                            edit=True,
                            label=self.smartSetupList[self.smartSetupListElement][6],
                            command=partial(self.NextStepWithFunction,
                            self.smartSetupList[self.smartSetupListElement][4],
                            self.smartSetupList[self.smartSetupListElement][5],
                            self.smartSetupList[self.smartSetupListElement][8])),
        
        if(self.smartSetupList[self.smartSetupListElement][7]!=0):
            cmds.button("HDMAR_RIG_SmartSetup_SecondAction_BT", edit = True,manage = True)
            cmds.button("HDMAR_RIG_SmartSetup_SecondAction_BT", edit = True,
                command = partial(self.JumpToSmartSetupElement,self.smartSetupList[self.smartSetupListElement][7]))
        else:
            cmds.button("HDMAR_RIG_SmartSetup_SecondAction_BT",edit=True,manage=False)


    # Function to create the skeleton of the smart setup
        
    def StartSmartSetup(self,*args):

				#Disable "Start Rig Smart setup button" and Enable Instruction Frame layout
        cmds.button("HDMAR_StartSmart_BT",edit =True, enable=False)
        cmds.frameLayout("HDMAR_GenerateRig_FL",edit=True,manage=True)

        self.SetupSetLayoutInfo()
				
		
    def JumpToSmartSetupElement(self,elementNumber,*args):
			self.smartSetupListElement = elementNumber
			self.SetupSetLayoutInfo()


    #This function performs 2 functions at once, especifically to setup the Main controller
    def SetupSmartMainController(self,*args):
        self.loadSelectedList("HDMAR_main_TFBG")
        self.createControlsButtonPress("main")   

    #Receive the action's function, it's string (Optional) you want done and the next step's function
    def NextStepWithFunction(self, actionFunction = "", actionFunctionString="", requireSelection = True, *args ):

        #Do not proceed of a selection is required to continue
        if requireSelection and len(cmds.ls(selection = True, type = "transform")) == 0:
            cmds.confirmDialog(title='Step alert!', 
                message="You must have a mesh selected to continue.",
                defaultButton="OK")
            return
        
        if actionFunction != "":
            if actionFunctionString == "":
                    exec("self.%s()"%actionFunction)
            else:
                    exec("self.%s('%s')"%(actionFunction,actionFunctionString))
		
        if self.smartSetupListElement+1 >= len(self.smartSetupList):
			cmds.button("HDMAR_StartSmart_BT",edit =True, enable=True)
			cmds.frameLayout("HDMAR_GenerateRig_FL",edit=True, manage=False)
			self.smartSetupListElement = 0
        else:
            self.smartSetupListElement += 1
            self.SetupSetLayoutInfo()


    #This function gets all the objects selected and puts the first and last elements as front and final driver
    #Anything in between is set as a roller
    #If the list only has 0 or 1 element it'll return false, otherwise it will return true
    def SetupGetWheelLists(self,*args):

        wheelsList = cmds.ls(selection = True, type = "transform") #from our selection, we get all transform objects

        wheelsListLength = len(wheelsList)

        if wheelsListLength <= 1:
            return
        
        #front wheel & final drive
        self.loadSelectedList("HDMAR_frontIdler_TFBG",[wheelsList[0]])
        self.loadSelectedList("HDMAR_finalDrive_TFBG",[wheelsList[wheelsListLength-1]])
        
        if wheelsListLength > 2:
            del wheelsList[-1]
            del wheelsList[0]
            self.loadSelectedList("HDMAR_rollers_TFBG",wheelsList)

            cmds.columnLayout("HDMAR_track_smartSetup_additionalOptions_CL",edit=True,manage=True)

        return

    def SetupPassValuesAndCreateTrack(self,*args):
        cmds.columnLayout("HDMAR_track_smartSetup_additionalOptions_CL",edit=True,manage=False)
        cmds.textFieldGrp("HDMAR_track_left_TFG", edit = True, 
            text = cmds.textFieldGrp("HDMAR_track_smartSetup_left_TFG", query = True, text = True))
        cmds.textFieldGrp("HDMAR_track_right_TFG", edit = True, 
            text = cmds.textFieldGrp("HDMAR_track_smartSetup_right_TFG", query = True, text = True))
        cmds.optionMenu("HDMAR_track_treadAmount_OM", edit = True, 
            value = cmds.optionMenu("HDMAR_track_treadAmount_OM_smartSetup", query = True, value= True))
        cmds.checkBox("HDMAR_track_left_right_chb", edit = True, 
            value = cmds.checkBox("HDMAR_track_smartSetup_left_right_chb", query = True, value = True))
        self.checkCanCreateTrack()

   
    #Function to toggle Manual options    
    def toggleManualOptions(self, columnLayout, itemTextButton):
        isManaged = cmds.layout(columnLayout, query = True, manage = True)
        if isManaged:
            cmds.layout(columnLayout, edit = True, manage = False)
        else:
            cmds.layout(columnLayout, edit = True, manage = True)
            
        isItemSelected = cmds.iconTextButton(itemTextButton, query = True, backgroundColor = True)[0] > 0.3
        LightGray = [0.4,0.4,0.4]
        Grey = [0.275, 0.275, 0.275]
        if isItemSelected:
            cmds.iconTextButton(itemTextButton, edit = True, backgroundColor = Grey)
        else:
            cmds.iconTextButton(itemTextButton, edit = True, backgroundColor = LightGray)

    #Function to toggle Manual options    
    def toggleCOGOptions(self, *args):
        isToggled = cmds.checkBox("HDMAR_upperBody_Limit_CB", query = True, value = True)
        if isToggled:
            cmds.layout("HDMAR_upperBody_RotationLimit_FSG", edit = True, manage = True)
            cmds.layout("HDMAR_upperBody_TranslationLimit_FSG", edit = True, manage = True)
        else:
            cmds.layout("HDMAR_upperBody_RotationLimit_FSG", edit = True, manage = False)
            cmds.layout("HDMAR_upperBody_TranslationLimit_FSG", edit = True, manage = False)



    def toggleMirrorTrackOptions(self, additionalText="", *args):
        isToggled = cmds.checkBox("HDMAR_track%s_left_right_chb"%additionalText, query = True, value = True)
        if isToggled:
            cmds.layout("HDMAR_track%s_left_TFG"%additionalText, edit = True, manage = True)
            cmds.layout("HDMAR_track%s_right_TFG"%additionalText, edit = True, manage = True)
            cmds.text("HDMAR_track%s_mirror_explain_tx"%additionalText,edit = True, manage = True)
            
        else:
            cmds.layout("HDMAR_track%s_left_TFG"%additionalText, edit = True, manage = False)
            cmds.layout("HDMAR_track%s_right_TFG"%additionalText, edit = True, manage = False)
            cmds.text("HDMAR_track%s_mirror_explain_tx"%additionalText,edit = True, manage = False)
    

            

    def createSubframeWithIconTextsButtonAndOptions(self,name,frameColor,buttonList): 
        #name = "master", frameColor = "(0.15, 0.25, 0.55)", button list: [["root","root.png"]]
        
        #Step 1. get parent layout name

        # Master FrameLayout
        parent = "HDMAR_Step1_AddLocator_FL"
        cmds.setParent(parent)

        #step 2. create frame layout (sub frame layout)
        cmds.frameLayout("HDMAR_%s_FL"%name, label = name, 
            collapsable = True, 
            collapse = False, 
            backgroundColor = frameColor)
        #Step 3. create a column layout
        cmds.columnLayout("HDMAR_%s_CL"%name)
        #Step 4. create a row layout of X icon text buttons
        rlLength = len(buttonList)
        cmds.rowLayout("HDMAR_%s_RL"%name, numberOfColumns = rlLength+2)  
        #account for how many columns the rowlayout has
        for iconTextButton in buttonList: #each element is a list of a name and an image URL
            self.createIconTextButtonForManualSetup(iconTextButton[0], iconTextButton[1])  #name, imageURL
        cmds.columnLayout("HDMAR_%s_CL_extra"%name) #We create a column layout to contain any extras
        cmds.setParent("..")
        DarkGray = [0.2, 0.2, 0.2]

        #Step 5. create a column layout with the custom options for the button
        cmds.setParent("HDMAR_%s_CL"%name)
        cmds.columnLayout("HDMAR_%s_options_CL"%name)
        for optionColumn in buttonList: #each element is a list of a name and an image URL
            cmds.columnLayout("HDMAR_%s_individualOption_CL"%(optionColumn[0]), 
                backgroundColor = DarkGray, 
                manage = False)
            self.createManualOptions(optionColumn[0],optionColumn[2]) #column layout name for itself
            cmds.setParent("HDMAR_%s_options_CL"%name) 
            cmds.separator(style = "none", height = 1)  
        
        cmds.setParent(parent)


    def createManualOptions(self,name,tutorialLink = ""):

        cmds.columnLayout("HDMAR_%s_individualOptionContainer_CL"%name)
        cmds.rowLayout(numberOfColumns = 2)
        cmds.separator(style = "none", width = 180)
        cmds.text(label = "%s%s"%(name[0].upper(), name[1:]), align = "center")
        cmds.setParent("..")
        cmds.separator(style = "none", height = 5)

        cmds.textFieldButtonGrp("HDMAR_%s_TFBG"%name, label = "Target Geometry",                 
            buttonLabel = "Load Selected",
            buttonCommand = partial(self.loadSelectedList, "HDMAR_%s_TFBG"%name),
            editable = False, 
            columnWidth = [[1, 90], [2, 200]])
        LightGray = [0.4, 0.4, 0.4]
        DarkGray = [0.2, 0.2, 0.2]

        #Create rowlayout for create controls and tutorial button
        cmds.rowLayout(numberOfColumns = 2)
        cmds.button("HDMAR_%s_btn"%name, label = "Create Controls", 
            backgroundColor = LightGray, 
            enable = False, 
            command = partial(self.createControlsButtonPress, name)) 
        cmds.button("HDMAR_%s_question_BT"%name, 
            label = "?", 
            backgroundColor = DarkGray, 
            command = partial(self.showLink, tutorialLink)) #unhardcode color
        cmds.setParent("..")
       

    def loadSelectedList(self, textField, listSelected = [], *args):
        if len(listSelected) == 0:
            listSelected = cmds.ls(selection = True,type = "transform") 
            #from our selection, we get all transform objects
        cmds.textFieldButtonGrp("%s"%textField, edit = True, 
            text = ', '.join(listSelected),forceChangeCommand = True) 
            # Get the Text fieldbutton group, edit the text to have all the transform object names
        self.isButtonPressable("%s_btn"%textField[:-5], "%s"%textField)
        self.getPlacerClass(textField[6:-5], listSelected)
        
    def checkIfGeometryAvailable(self, textField):
        text = cmds.textFieldButtonGrp(textField, query = True, text = True)
        if len(text) > 0:
            return True
        else:
            return False
    
    def isButtonPressable(self, button, textField):
        if self.checkIfGeometryAvailable(textField):
            cmds.button(button, edit = True,enable = True)
        else:           
            cmds.button(button, edit = True, enable = False)
        #Special check for enabling and disabling the IK Button
        self.checkIKButton("hookIK_btn")
    
    def createControlsButtonPress(self, name, *args):
        self.getAnimClass(name)
        cmds.button("HDMAR_%s_btn"%name, edit = True, enable = False) 
        cmds.textFieldButtonGrp("HDMAR_%s_TFBG"%name, edit = True, enable = False) 
        self.checkIKButton("hookIK_btn")#my edit
        
    def checkIKButton(self, button):
        if self.checkHookCanIK():
            cmds.button(button, edit = True, enable = True)
        else:           
            cmds.button(button, edit = True, enable = False)
        
    def IKButtonPressed(self, *args):
        cmds.button("hookIK_btn", 
			edit = True,
            enable = False)
        self.createhookIK()
	
    def COGExtraOptions(self, columnLayout, returnToParent):
        cmds.setParent(columnLayout)
        cmds.rowLayout(numberOfColumns = 2)
        # cmds.checkBox("%s_chb"%labelObjectName, label = "Rename", align = "left")
        cmds.textField("%s_rename_TF"%labelObjectName, text = "", width = 200)
        cmds.setParent(returnToParent)

    def generateTracksCheckboxAndTreadAmount(self,additionalText = "",*args):

        cmds.checkBox("HDMAR_track%s_left_right_chb"%additionalText, 
            label = "Assign left and right tracks on X axis?", 
            align = "left", 
            changeCommand = partial(self.toggleMirrorTrackOptions,additionalText))

        cmds.separator(height = 5)
        cmds.text("HDMAR_track%s_mirror_explain_tx"%additionalText,
            label="Search and replace a name from each side of the track", 
            manage = False)

        #Following fields are only seen when the 2 track checkbox is enabled
        cmds.textFieldGrp("HDMAR_track%s_left_TFG"%additionalText, label = "Left Search: ",                 
            manage = False, 
            text = "left",
            columnWidth = [[1, 80], [2, 300]])#columnWidth = [[1, 109], [2, 256]])

        cmds.textFieldGrp("HDMAR_track%s_right_TFG"%additionalText, label = "Right Replace: ",                 
            manage = False, 
            text = "right",
            columnWidth = [[1, 80], [2, 300]])#[[1, 118], [2, 247]])

        cmds.intSliderGrp("HDMAR_track%s_treadAmount_ISG"%additionalText, label = "Amount of treads",
            field = True, 
            minValue = 8, 
            maxValue = 100, 
            fieldMinValue = 0, 
            fieldMaxValue = 300, 
            value = 140, 
            columnWidth = [[1, 90], [2, 100], [3, 175]], 
            columnAlign = [[1, "left"]],
            manage = True)
        
        #Option Menu. In demo it has multiple templates, but for our innitial project it only has 
        #Excavator as an option
        cmds.optionMenu("HDMAR_track_treadAmount_OM%s"%additionalText, label = "Select Template: ")
        cmds.separator(style = "none", height = 5)  
        cmds.menuItem(label = "tread1")  

    #Function runs when adding a Wheel on the tread. When both Final drive and Front idler

    def CheckTreadWheels(self, fromSmartSetup = False, *args):
        finalDriveValue = cmds.textFieldButtonGrp("HDMAR_finalDrive_TFBG", query = True, text = True )
        frontIdlerValue = cmds.textFieldButtonGrp("HDMAR_frontIdler_TFBG", query = True, text = True )

        if finalDriveValue != "" and frontIdlerValue != "":
            cmds.iconTextButton("HDMAR_track_ITB", edit = True, enable = True)
        else:
            cmds.iconTextButton("HDMAR_track_ITB", edit = True, enable = False)
    
    #Function to create icon text buttons for the "Manual" tab in Step 1
    def createIconTextButtonForManualSetup(self, label, imageURL): #Add itemTextButton & columnlayout
        cmds.iconTextButton("HDMAR_%s_ITB"%label, label = label, 
            style = "iconAndTextVertical", 
            image1 = "%s%s"%(self.URL_ICON_PATH,imageURL), 
            width = 60, height = 80, 
            scaleIcon = True,
            backgroundColor = (0.275,0.275,0.275),
            command = partial(self.toggleManualOptions, 
                "HDMAR_%s_individualOption_CL"%label, 
                "HDMAR_%s_ITB"%label)) 


    def createSubframeWithIconTextsButtonForVideoTutorials(self, name, frameColor, buttonList): 
        #name = "master", frameColor = "(0.15, 0.25, 0.55)", button list: [["root","youtube.com"]]
        #Step 1. get parent layout name

        # Master FrameLayout
        parent = "HDMAR_VideoTutorials_FL"
        cmds.setParent(parent)

        #step 2. create frame layout (sub frame layout)
        cmds.frameLayout("HDMAR_video_%s_FL"%name, label = name, 
            collapsable = True, 
            collapse = False, 
            backgroundColor = frameColor)
        #Step 3. create a column layout
        cmds.columnLayout("HDMAR_video_%s_CL"%name)
        #Step 4. create a row layout of X icon text buttons
        for button in buttonList: #each element is a list of a name and an image URL
            self.createHelpButtonWithLink(button[0], button[1])
        
        cmds.setParent(parent)
    

    #Function to Create help buttons for the "Extras" tab
    def createHelpButtonWithLink(self,buttonLabel, link = "youtube.com"):
        LighterGray = [0.5, 0.5, 0.5]
        cmds.button(label = buttonLabel, 
            backgroundColor = LighterGray, 
            width = 380,
            command = partial(self.showLink, link))
    
    def showLink(self, link, *args):
        cmds.showHelp("http://www.%s"%link, absolute = True)
        

### Windy Functions

    def newColorOverride(self, *args):
        # get the object list
        colorChange = cmds.ls( sl = True)
        colorShapes = cmds.listRelatives( colorChange, shapes = True )
        #get the color
        newColor = cmds.colorSliderGrp("HDMAR_colorOverride_CSG", query=True, rgb=True)
        # check if anything selected
        if colorShapes == None:
            cmds.warning("Please select an object.")
        # change color
        else:
            for curve in colorShapes:
                cmds.setAttr("%s.overrideRGBColors"%curve,1)
                cmds.setAttr("%s.overrideColorRGB"%curve, newColor[0],newColor[1],newColor[2])
  
                
    def renameOBJ(self, *args):
        userNewName = cmds.textField("HDMAR_renameOBJ_TF", query = True, text = True)
        listed_renameItem = cmds.ls(sl = True)
        # check if user selected more than one obj
        if len(listed_renameItem) > 1:
            cmds.warning("You can only select one control at a time.")
        # check if user selected anything
        elif listed_renameItem == None:
            cmds.warning("Please select an object.")
        # check if user typed anything
        elif userNewName == "":
            cmds.warning("Please type a new name.")    
        else:
            # get the name of selected obj
            listed_splitedName = listed_renameItem[0].split("_",1)
            # define related item list to find
            #look_for = ["%s_ctr"%listed_splitedName[0],"%s_ctr_shp*"%listed_splitedName[0],
            #"%s_ctr_grp"%listed_splitedName[0],"%s_geo"%listed_splitedName[0],"%s_jnt"%listed_splitedName[0],
            #"%s_jnt_prtCt"%listed_splitedName[0]]
            #allRelatedItem = cmds.ls(look_for)
            allRelatedItem = cmds.ls("%s*"%listed_splitedName[0],
                type = ("nurbsCurve","transform","mesh","joint","parentConstraint","shadingEngine"))
            
            # rename all related objects
            for obj in allRelatedItem:
                # split names
                obj_splitedName = obj.split("_",1)
                # rename to user input
                cmds.rename(obj, userNewName + "_%s"%obj_splitedName[1], ignoreShape = True)
                #self.checkNameDuplicates()
            return              
    
    def checkNameDuplicates(self,*args):
        # check if there are any duplicates
        # get all obj in the scene        
        allOBJ = cmds.ls(tr=True,sn=True,fl=True)
        for obj in allOBJ:
            # find duplicated names
            if (obj.find("|")>=0):
                # get the last name
                repeated_splitedName = obj.split("|")
                # rename duplicates
                newName = cmds.rename(obj,"%s_#"%repeated_splitedName[-1])
                return newName
            else:
                pass

    
if __name__ == "__main__":       
    UiInstance = MainUI()
    UiInstance.createUI()