import maya.cmds as cmds
import maya.mel as mel
import os
import shutil

#method for installing
#drag this file into maya window to run install.py

#################################################DRAG AND DROP####################################################################

#if you drop file into window you need this function
def onMayaDroppedPythonFile(*args, **kwargs):
    pass

#################################################PATHS VARIABLE####################################################################

#scripts filepath
scriptsPath = cmds.internalVar(userScriptDir = True)

#path of install file - see if this can be cleaned up
srcPath = os.path.join(os.path.dirname(__file__), "src")
srcPath = os.path.normpath(srcPath)[:-4]

#################################################MOVE FILES###############################################

#if already installed, delete
if os.path.exists("%sHDMAR_scripts"%scriptsPath):
  shutil.rmtree("%sHDMAR_scripts"%scriptsPath)
#we would move the files to the scripts folder. srcPath > scriptsPath
src = "%s/HDMAR_scripts"%srcPath
des = "%sHDMAR_scripts"%scriptsPath
shutil.copytree(src, des)
#refresh the scripts folder
mel.eval("rehash;")

#################################################MOVE FILES###############################################

#################################################TOOLBAR###############################################

baseIconsDir = "%sHDMAR_scripts/Icons/"%scriptsPath#where ever our path to icons is, this may change so its in the script folder toolbar_icon.png

shelf = mel.eval("$gShelfTopLevel=$gShelfTopLevel")#this is the tool bar layout

#we could add a tab instead of using current
parent = cmds.tabLayout(shelf, query = True, selectTab = True)#this is the toolbar selected tab
for i in cmds.layout(parent, query = True, childArray = True):
    if "HDMAR_Editing" == cmds.shelfButton(i, query = True, label = True):
        cmds.deleteUI(i)
#we may add as many tools as we want, this is an example
cmds.shelfButton(label = "HDMAR_Editing", 
    annotation = "Heavy Duty Machine Auto-Rigger (HDMAR) Project", 
    sourceType = "Python", 
    image1 = "%stoolbar_icon.png"%baseIconsDir,
    imageOverlayLabel = "HDMAR", 
    parent = parent, 
    command = "from HDMAR_scripts.System import UI\nUI_instance = UI.MainUI()\nUI_instance.createUI()")

print "this works, check your toolbar"