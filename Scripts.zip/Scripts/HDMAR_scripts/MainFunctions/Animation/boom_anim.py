'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By Tyler Millossi
#With assistance from BCIT
#creates shapes for a boom (converts the placeholders to final animation controls)
#Location ...
'''

import maya.cmds as cmds
from HDMAR_scripts.MainFunctions.Animation import singleFK_anim

#converts the placeholder into a animation controler
class Boom_anim(singleFK_anim.SingleFK_anim):  
    
    def control(self):
        #create control
        control = self.createAnimationControl("boom") 
        
        # move the anim control
        # get the max distance value of mesh for x axis
        valuePos = self.getPosInfoOfFarPoints(self.geo[0])[0]  
        xVal = abs(valuePos[0]+0.5-(valuePos[1]-0.5))
        # move control
        cmds.move(xVal/2, control)     
        dup = cmds.duplicate(control, name = "Temp_1", renameChildren = True)
        cmds.move(valuePos[1]-0.5, dup)
        cmds.rotate(0, 180, 0, dup, os = True, relative = True)
        cmds.select(dup, control)
        #cmds.FreezeTransformations()
        cmds.makeIdentity(apply = True)
        # combine curve shapes
        curvesGrp = cmds.listRelatives(dup, allDescendents = True, type = "nurbsCurve", fullPath = True)
        cmds.parent(curvesGrp, control, relative = True, shape = True)
        cmds.xform(control, centerPivots = True)
        cmds.delete("Temp_1")
        
        # lock attrs
        self.singleJointFK("boom", ["sx", "sy", "sz", "ry", "rz", "tx", "ty", "tz"], control)#module name / locked attrs / curves