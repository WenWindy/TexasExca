'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By Tyler
#With assistance from BCIT
#creates shapes for a steering (converts the placeholders to final animation controls)
#Location ...
'''

import maya.cmds as cmds
from HDMAR_scripts.MainFunctions.Animation import singleFK_anim

#converts the placeholder into a animation controler
class Steering_anim(singleFK_anim.SingleFK_anim):
    
    def control(self):
        #create control
        control = self.createAnimationControl("steering")
        
        #match to current model specific transforms
        cmds.rotate(0,180,0,control)
        cmds.makeIdentity(control, apply = True)
        
        #create single FK
        self.singleJointFK("steering", ["sx", "sy", "sz"], control)#module name / locked attrs / curves