'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By Tyler Millossi
#With assistance from BCIT
#parent class for creating IK for a arm (basic IK for three joints)
#Location ...
'''

import maya.cmds as cmds

#IK for a single joint
class hookIK_anim():
    print "IK for the hook"
    #basic FK IK? and limited rotation, translate. No scale?
    def __init__(self, placeholder, geo):
        pass
    
    def createHookIKControl(self, modName):
        print "create anim control"
        #reference the class
        exec("from HDMAR_scripts.Controls.Animation import %s_control"%modName)
        exec("classInstance = %s_control.%s%s_control()"%(modName, modName[0].upper(), modName[1:]))
        control = classInstance.create()
        return control
        
    def threeJointIK(self, module_Name, lockedAttrs, control):#lockedAttrs = ["sx", "sy", "sz"]
        #rename control
        self.animControl = cmds.rename(control, "%s_ctr"%module_Name)

        #clear Selection
        cmds.select(clear = True)
        
        #user no longer wants the boom
    def deleteControl(self):
        #delete controller
        if cmds.objExists(self.animControl):
            cmds.delete(self.animControl)
        #delete joint
        if cmds.objExists(self.joint_):
            cmds.delete(self.joint_)
    