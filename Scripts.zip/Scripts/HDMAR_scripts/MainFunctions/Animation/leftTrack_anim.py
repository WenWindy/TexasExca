'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By Windy Wen
#With assistance from BCIT
#creates shapes for a track (converts the placeholders to final animation controls)
#Location ...
'''


import maya.cmds as cmds
from HDMAR_scripts.MainFunctions.Animation import singleFK_anim

#converts the placeholder into a animation controler
class LeftTrack_anim(singleFK_anim.SingleFK_anim):
    def __init__(self, geo, children):
        self.geo = geo
        self.children = children
        self.joints = children[1]   
    
    def control(self):    
        #create control
        control = self.createAnimationControl("leftTrack") 
        #move to correct location and rotation
        cmds.rotate(0,180, control)
        farX = 0
        maxY = -100000
        minY = +100000
        maxZ = -100000
        minZ = +100000
        #organize the list better
        geo = [self.geo[0], self.geo[1]]
        geo.extend(self.geo[2])
        #get position info
        for g in geo:
            valuePos = self.getPosInfoOfFarPoints(g)
            if valuePos[0][0] > farX:
                farX = valuePos[0][0]
            if valuePos[1][0] > maxY:
                maxY = valuePos[1][0]
            if valuePos[1][1] < minY:
                minY = valuePos[1][1]
            if valuePos[2][0] > maxZ:
                maxZ = valuePos[2][0]
            if valuePos[2][1] < minZ:
                minZ = valuePos[2][1]
        #place controller
        cmds.move(farX + 1, 
                  minY + (maxY - (minY))/2,
                  minZ + (maxZ - (minZ))/2,
                  control)
        cmds.makeIdentity(control, apply = True)
        
        #rename
        self.animControl = cmds.rename(control, "leftTrack_ctr")
        for i in cmds.listRelatives(self.animControl, allDescendents = True, type = "nurbsCurve"):
            cmds.rename(i, "leftTrack_ctr_shp")
        
        #grouping
        group = cmds.group(name = "leftTrack_ctr_grp", world = True, empty = True)
        cmds.matchTransform(group, self.animControl)
        cmds.parent(self.animControl, group)
        for i in self.children[2:]:
            cmds.parent(i, self.animControl)
        #things that cause double transform
        for i in self.children[0]:
            cmds.setAttr("%s.inheritsTransform"%i, 0)
            cmds.parent(i, group)  
            cmds.move(0,0,0, i, objectSpace = True)           
        
        #hide and lock attributes - main control
        for attr in ["sx", "sy", "sz"]:
            cmds.setAttr("%s.%s"%(self.animControl, attr), keyable = False, lock = True)  
        
        #hide and lock attributes - wheel controls
        wheels = cmds.ls("leftTrack_roller_*_ctr")
        wheels.append("leftTrack_front_ctr")
        wheels.append("leftTrack_back_ctr")
        for wheel in wheels:
            for attr in ["sx", "sy", "sz", "rx", "ry", "rz", "tz"]:
                cmds.setAttr("%s.%s"%(wheel, attr), keyable = False, lock = True) 
        
        #need to name/rename everything unique
        for obj in cmds.listRelatives(group, allDescendents = True):
            if not "left" in obj:
                cmds.rename(obj, "leftTrack_%s"%obj)

