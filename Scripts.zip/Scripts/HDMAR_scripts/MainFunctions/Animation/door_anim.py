'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By Tyler Millossi
#With assistance from BCIT
#creates shapes for a Door (converts the placeholders to final animation controls)
#Location ...
'''

import maya.cmds as cmds
from HDMAR_scripts.MainFunctions.Animation import singleFK_anim

class Door_anim(singleFK_anim.SingleFK_anim):
    
    def control(self):
        #create control
        control = self.createAnimationControl("door")

        #match to current model specific transforms
        cmds.select(control)
        cmds.rotate(90, 90)
        cmds.scale(4,4,4)
        cmds.makeIdentity(apply = True)
        
        #create single FK
        self.singleJointFK("door", ["sx", "sy", "sz"], control)#module name / locked attrs / curves        
