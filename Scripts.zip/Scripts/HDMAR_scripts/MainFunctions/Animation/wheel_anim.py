'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By Tyler Millossi
#With assistance from BCIT
#creates shapes for a wheel (converts the placeholders to final animation controls)
#Location ...
'''

import maya.cmds as cmds
from HDMAR_scripts.MainFunctions.Animation import singleFK_anim

#converts the placeholder into a animation controler
class Wheel_anim(singleFK_anim.SingleFK_anim): 
    
    def control(self):
        #create control
        control = self.createAnimationControl("wheel")
        
        #create single FK
        self.singleJointFK("wheel", ["sx", "sy", "sz"], control)#module name / locked attrs / curves