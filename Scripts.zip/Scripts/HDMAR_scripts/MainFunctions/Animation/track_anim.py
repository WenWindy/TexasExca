'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By Windy Wen
#With assistance from BCIT
#creates shapes for a track (converts the placeholders to final animation controls)
#Location ...
'''

import maya.cmds as cmds
from HDMAR_scripts.MainFunctions.Animation import singleFK_anim

#converts the placeholder into a animation controler
class Track_anim():
    def __init__(self, *args):
        pass
    
    def control(self):
        #create control
        control = self.createAnimationControl("track")
        cmds.move(9, 2.3, 0, control)
        cmds.rotate(0,180, 0, control)
    
    def createAnimationControl(self, modName):
        #reference the class
        modName = "leftTrack"
        exec("from HDMAR_scripts.Controls.Animation import %s_control"%modName)
        exec("classInstance = %s_control.%s%s_control()"%(modName, modName[0].upper(), modName[1:]))
        control = classInstance.create()
        return control    
        