'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By Tyler
#With assistance from BCIT
#creates shapes for a lowerBody (converts the placeholders to final animation controls)
#Location ...
'''

import maya.cmds as cmds
from HDMAR_scripts.MainFunctions.Animation import singleFK_anim

#converts the placeholder into a animation controler
class LowerBody_anim(singleFK_anim.SingleFK_anim):
    def control(self):
        #create control
        control = self.createAnimationControl("lowerBody")
        
        #create single FK
        self.singleJointFK("lowerBody", ["sx", "sy", "sz"], control)#module name / locked attrs / curves
        