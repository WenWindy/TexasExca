'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By Windy Wen
#With assistance from BCIT
#creates shapes for a main (converts the placeholders to final animation controls)
#Location ...
'''

import maya.cmds as cmds
from HDMAR_scripts.MainFunctions.Animation import singleFK_anim

#converts the placeholder into a animation controler
class Main_anim(singleFK_anim.SingleFK_anim):
    def control(self):
        #create control
        control = self.createAnimationControl("main")
        moveControl = self.createAnimationControl("root")
        
        #position Info - get the position the control z should be - moveControl
        YValue = []
        geoTransformNodes = []
        for geo in self.geo:
            geoTransformNodes.extend(cmds.listRelatives(geo, parent = True))
            YValue.append(self.getPosInfoOfFarPoints(geo)[1][0] + 0.1)
        geoMaxY = max(YValue)
        
        cmds.move(0, geoMaxY+2, 0, moveControl)
        cmds.xform(moveControl, pivots = (0, -geoMaxY, 0))
        cmds.makeIdentity(moveControl, apply = True)
        
        #match to current model specific transforms - control
        cmds.rotate(0,180,0, control)
        cmds.makeIdentity(control, apply = True)
        
        #delete old placeholder
        cmds.delete(self.placeHolder)
        
        #rename
        self.animControlMain = cmds.rename(control, "main_ctr")
        self.animControlMove = cmds.rename(moveControl, "move_ctr")
        for i in cmds.listRelatives(self.animControlMain, allDescendents = True, type = "nurbsCurve"):
            cmds.rename(i, "main_ctr_shp")
        
        #create groups
        self.HDMAR_grp = cmds.group(name = "main_top_grp", world = True, empty = True)
        self.controlGrp = cmds.group(name = "main_ctr_grp", world = True, empty = True)
        self.geoGrp = cmds.group(name = "main_geo_grp", world = True, empty = True)
        self.skeletonGrp = cmds.group(name = "main_jnt_grp", world = True, empty = True)
        self.moveControlGrp = cmds.group(name = "move_ctr_grp", world = True, empty = True)

        #create hierarchy
        cmds.parent(self.animControlMove, self.moveControlGrp)
        cmds.parent(self.moveControlGrp, self.animControlMain)
        cmds.parent(self.animControlMain, self.controlGrp)
        cmds.parent(geoTransformNodes, self.geoGrp)
        cmds.parent(self.skeletonGrp, self.geoGrp, self.controlGrp, self.HDMAR_grp)
        
        #cleanup - trash anything that made it into geo that isnt geo
        inGeo = cmds.listRelatives(self.geoGrp, 
            children = True,
            type = "transform",
            allDescendents = True)
        for thing in inGeo:
            if not thing in geoTransformNodes:
                cmds.delete(thing)
        