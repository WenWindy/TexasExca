'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By Tyler Millossi
#With assistance from BCIT
#parent class for creating shapes for a arm (basic FK for one joint)
#Location ...
'''

import maya.cmds as cmds

#FK for a single joint
class SingleFK_anim():
    print "works"
    #basic FK IK? and limited rotation, translate. No scale?
    def __init__(self, placeholder, geo):
        self.placeHolder = placeholder
        self.geo = geo
    
    def createAnimationControl(self, modName):
        #reference the class
        exec("from HDMAR_scripts.Controls.Animation import %s_control"%modName)
        exec("classInstance = %s_control.%s%s_control()"%(modName, modName[0].upper(), modName[1:]))
        control = classInstance.create()
        classInstance = None
        return control
         
    def singleJointFK(self, module_Name, lockedAttrs, control):#lockedAttrs = ["sx", "sy", "sz"]
        #rename control
        self.animControl = cmds.rename(control, "%s_ctr"%module_Name)
        for i in cmds.listRelatives(self.animControl, allDescendents = True, type = "nurbsCurve"):
            cmds.rename(i, "%s_ctr_shp"%module_Name)
        
        #place in same location as the geo
        if type(self.geo) == type([]):
            if cmds.objExists(self.geo[0]):
                cmds.matchTransform(self.animControl, self.placeHolder) 
        else:
            if cmds.objExists(self.geo):
                cmds.matchTransform(self.animControl, self.placeHolder)  

        #delete placer - should this be done in the placer class?
        cmds.delete(self.placeHolder)
        
        #create joint on control location
        cmds.select(clear = True)
        self.joint_ = cmds.joint(name = "%s_jnt"%module_Name)
        cmds.setAttr("%s.visibility"%self.joint_, 0)
        cmds.matchTransform(self.joint_, self.animControl)
        
        #skin geo to joint
        clusters = []
        #if theres is a list for geo - multiple binds
        if type(self.geo) == type([]):
            for geo in self.geo:
                #skin geo to joint
                skinCluster = cmds.skinCluster(self.joint_, geo,## 
                    name = "%s_skinCluster"%module_Name, 
                    toSelectedBones = True, 
                    bindMethod = 0, 
                    skinMethod = 0, 
                    normalizeWeights = 1)[0]
                clusters.append(skinCluster)
        
        else:
            #get the geo shape node for skinning
            geoShapes = cmds.listRelatives(self.geo, shapes = True)
            #skin geo to joint
            skinCluster = cmds.skinCluster(self.joint_, geoShapes[0], 
                name = "%s_skinCluster"%module_Name, 
                toSelectedBones = True, 
                bindMethod = 0, 
                skinMethod = 0, 
                normalizeWeights = 1)[0]
            clusters.append(skinCluster)
    
        #group
        self.controlGrp = cmds.group(name = "%s_ctr_grp"%module_Name, world = True, empty = True)
        cmds.matchTransform(self.controlGrp, self.animControl)
        cmds.parent(self.animControl, self.controlGrp)      
        
        #hide and lock attributes - scale
        for attr in lockedAttrs:
            cmds.setAttr("%s.%s"%(self.animControl, attr), keyable = False, lock = True)  
        
        #apply parenting and anything needed to make this work
        cmds.parentConstraint(self.animControl, self.joint_, name = "%s_prtCt"%self.joint_)
        
        #clear Selection
        cmds.select(clear = True)
    
    def getPosInfoOfFarPoints(self, geo):
        xVal = []
        yVal = []
        zVal = []
        for vert in cmds.ls("%s.vtx[*]"%geo, flatten = True):
            vertPos = cmds.xform(vert, query = True, translation = True, worldSpace = True)
            xVal.append(vertPos[0])
            yVal.append(vertPos[1])
            zVal.append(vertPos[2]) 
        valueInfo = [[max(xVal), min(xVal)], [max(yVal), min(yVal)], [max(zVal), min(zVal)]]
        return valueInfo
        