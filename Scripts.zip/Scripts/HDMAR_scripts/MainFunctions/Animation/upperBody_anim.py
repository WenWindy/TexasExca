'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By Tyler Millossi
#With assistance from BCIT
#creates shapes for a upperBody (converts the placeholders to final animation controls)
#Location ...
'''
import maya.cmds as cmds
from HDMAR_scripts.MainFunctions.Animation import singleFK_anim

#converts the placeholder into a animation controler
class UpperBody_anim(singleFK_anim.SingleFK_anim):
    def control(self):
        #create control
        control = self.createAnimationControl("upperBody")
        
        #fix rotation
        cmds.rotate(0,-90,0, control)
        cmds.makeIdentity(control, apply = True)
        
        #position Info - get the position the control z should be
        ZValue = []
        for geo in self.geo:
            ZValue.append(self.getPosInfoOfFarPoints(geo)[2][1] - 0.1)
        geoMinZ = min(ZValue)
        
        placeholderMinZ = cmds.xform(self.placeHolder, query = True, translation = True, worldSpace = True)[2]
        cmds.move(0, 0, geoMinZ-(placeholderMinZ), control)
        cmds.xform(control, pivots = (0,0,-(geoMinZ-(placeholderMinZ))))
        cmds.makeIdentity(control, apply = True)
        
        #create single FK
        self.singleJointFK("upperBody", ["sx", "sy", "sz"], control)#module name / locked attrs / curves
        
        #limit information
        cmds.select(self.animControl)
        self.translateAmount = 2.5
        self.rotateAmount = 15
        ta = self.translateAmount
        ra = self.rotateAmount
        cmds.transformLimits(
            enableRotationX = (1, 1),
            enableRotationZ = (1, 1),
            enableTranslationX = (1, 1),
            enableTranslationY = (1, 1),
            enableTranslationZ = (1, 1),
            rotationX = (-ra, ra),
            rotationZ = (-ra, ra),
            translationX = (-ta, ta), 
            translationY = (-ta, ta),
            translationZ = (-ta, ta))