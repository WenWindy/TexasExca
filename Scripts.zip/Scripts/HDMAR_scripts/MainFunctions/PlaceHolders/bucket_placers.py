'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By Tyler Millossi
#With assistance from BCIT
#creates shapes for a bucket (place holders)
#Location ...
'''

import maya.cmds as cmds
from HDMAR_scripts.MainFunctions.PlaceHolders import placer_placers

#creates controls to adjust pivots. this is before they are coverted to anim controls
class Bucket_placer(placer_placers.Placer_placer):
    def placer(self):
        #make a control
        control = self.createPlaceHolderControl("bucket")
        #name and place the placer
        self.createPlacer("bucket", control)