'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By tyler millossi
#With assistance from BCIT
#creates shapes for a Steering (place holders)
#Location ...
'''

import maya.cmds as cmds
from HDMAR_scripts.MainFunctions.PlaceHolders import placer_placers

#creates controls to adjust pivots. this is before they are coverted to anim controls
class Steering_placer(placer_placers.Placer_placer):
    def placer(self):
        #make a control
        control = self.createPlaceHolderControl("steering")
        #rotate correctly
        cmds.rotate(0,180,0, control)
        cmds.makeIdentity(control, apply = True)
        #name and place the placer
        self.createPlacer("steering", control)