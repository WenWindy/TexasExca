'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By Tyler Millossi
#With assistance from BCIT
#creates shapes for a door (place holders)
#Location ...
'''

import maya.cmds as cmds
from HDMAR_scripts.MainFunctions.PlaceHolders import placer_placers

class Door_placer(placer_placers.Placer_placer):
    def placer(self):
        #make a control
        control = self.createPlaceHolderControl("door")
        print "control", control
        #match to current model specific transforms
        cmds.select(control)
        cmds.rotate(90, 90)
        cmds.scale(4,4,4)
        cmds.makeIdentity(apply = True)
        #name and place the placer
        self.createPlacer("door", control)
        