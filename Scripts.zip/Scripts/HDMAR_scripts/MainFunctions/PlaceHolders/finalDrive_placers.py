'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By ...
#With assistance from BCIT
#creates shapes for a Final Drive (place holders)
#Location ...
'''

import maya.cmds as cmds
from HDMAR_scripts.MainFunctions.PlaceHolders import placer_placers

class FinalDrive_placer(placer_placers.Placer_placer):
    def placer(self):
        return  

