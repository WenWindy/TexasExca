'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By Windy Wen
#With assistance from BCIT
#creates shapes for a main (place holders)
#Location ...
'''

import maya.cmds as cmds
from HDMAR_scripts.MainFunctions.PlaceHolders import placer_placers

class Main_placer(placer_placers.Placer_placer):
    def placer(self):
        #make a control
        control = self.createPlaceHolderControl("main")
        #name and place the placer
        self.createPlacer("main", control)
        #snap to grid
        cmds.move(0,0,0, self.placerControl)
        #hide and lock attributes - scale
        lockedAttrs = ["tx", "ty", "tz", "rx", "ry", "rz", "sx", "sy", "sz"]
        for attr in lockedAttrs:
            cmds.setAttr("%s.%s"%(self.placerControl, attr), keyable = False, lock = True)  
