'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By Tyler Millossi
#With assistance from BCIT
#creates shapes for a all placers (place holders)
#Location ...
'''

import maya.cmds as cmds

class Placer_placer():
    def __init__(self, geo):
        self.geo = geo
    
    def createPlaceHolderControl(self, modName):
        #reference the class
        if len(self.geo) == 0:
            return
        exec("from HDMAR_scripts.Controls.PlaceHolder import %s_placeHolder"%modName)
        exec("classInstance = %s_placeHolder.%s%s_placeHolder()"%(modName, modName[0].upper(), modName[1:]))
        control = classInstance.create()
        return control
        
    def createPlacer(self, module_Name, control):
        #is list valid
        if len(self.geo) == 0:
            return
        #rename control and shapes   
        self.placerControl = cmds.rename(control, "%s_plc"%module_Name)
        for i in cmds.listRelatives(self.placerControl, allDescendents = True, type = "nurbsCurve"):
            cmds.rename(i, "%s_plc_shp"%module_Name)
        #match to current model specific transforms
        #place in same location as the geo
        if type(self.geo) == type([]):
            if len(self.geo) > 0:
                if cmds.objExists(self.geo[0]):
                    cmds.matchTransform(self.placerControl, self.geo[0]) 
        else:
            if cmds.objExists(self.geo):
                cmds.matchTransform(self.placerControl, self.geo) 

    #user wishes to change what geo will be the door
    def changeGeo(self, newGeo):
        if cmds.objExists(newGeo):
            self.geo = newGeo
            cmds.matchTransform(self.placerControl, self.geo)
    
    #user no longer wants the arm
    def deletePlacer(self):
        if cmds.objExists(self.placerControl):
            cmds.delete(self.placerControl)
