'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By Windy Wen
#With assistance from BCIT
#creates shapes for a track (place holders)
#Location ...
'''

import maya.cmds as cmds
from HDMAR_scripts.MainFunctions.PlaceHolders import placer_placers

#creates controls to adjust pivots. this is before they are coverted to anim controls
class Track_placer():
    def __init__(self, *args):
        pass
          
    def placer(self):
        self.geo = "tempName"
        self.placerControl = "tempName"
        return