'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By Windy Wen
#With assistance from BCIT
#creates shapes for a track (place holders)
#Location ...
'''

import maya.cmds as cmds
from HDMAR_scripts.MainFunctions.PlaceHolders import placer_placers

class Wheel_placer(placer_placers.Placer_placer):
    def placer(self):
        #make a control
        control = self.createPlaceHolderControl("wheel")
        #name and place the placer
        self.createPlacer("wheel", control)