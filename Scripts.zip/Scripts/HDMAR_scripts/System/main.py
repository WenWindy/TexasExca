'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By Tyler Millossi
#With assistance from BCIT
#creates shapes for a bucket (place holders)
#Location ...
'''
import maya.cmds as cmds
import maya.mel as mel

#fix when deleting a parent in the hook the children get deleted
#need to add groups to the animControls

class Main():
    def getPlacerClass(self, moduleName, geo):
        #disable Soft select - soft select will change the creation process of the curves
        mel.eval("softSelect -e -softSelectEnabled false;")
        #delete old placer if exists
        try:
            exec("self.%s_placer_classInstance.deletePlacer()"%moduleName)
        except:
            pass
        #import module
        exec("from HDMAR_scripts.MainFunctions.PlaceHolders import %s_placers"%moduleName)
        #create placer
        geo = self.getOnlyMeshFromSelection(geo)
        exec("self.%s_placer_classInstance = %s_placers.%s%s_placer(geo)"%(moduleName, moduleName, moduleName[0].upper(), moduleName[1:]))
        #self.setNamespaceToTool()
        exec("control = self.%s_placer_classInstance.placer()"%moduleName)
        #cmds.namespace(setNamespace = ":")
        return control
        
    def deletePlacerClass(self, moduleName):
        self.setNamespaceToTool()
        exec("self.%s_placer_classInstance.deletePlacer()"%moduleName)
        cmds.namespace(setNamespace = ":")
        exec("self.%s_placer_classInstance = None"%moduleName)
        
    def changeGeoPlacerClass(self, moduleName, newGeo):
        geo = self.getOnlyMeshFromSelection(newGeo)
        exec("self.%s_placer_classInstance.changeGeo(geo)"%moduleName)
    
    #come back to this
    def getAnimClass(self, moduleName):
        #disable Soft select - soft select will change the creation process of the curves
        mel.eval("softSelect -e -softSelectEnabled false;")
        #get info for create anim control
        exec("geo = self.%s_placer_classInstance.geo"%moduleName)
        exec("placeholder = self.%s_placer_classInstance.placerControl"%(moduleName))
        #import module
        exec("from HDMAR_scripts.MainFunctions.Animation import %s_anim"%moduleName)
        #create anim control
        exec("self.%s_anim_classInstance = %s_anim.%s%s_anim(placeholder, geo)"%(moduleName, moduleName, moduleName[0].upper(), moduleName[1:]))
        #self.setNamespaceToTool()
        exec("self.%s_anim_classInstance.control()"%moduleName)
        #cmds.namespace(setNamespace = ":")
        #parenting
        self.parentGroupsAndJoints(moduleName)
        
        cmds.select(clear = True)
        
    def deleteAnimClass(self, moduleName):
        #because of arm parenting, call a function to unparent
        if moduleName == "boom" or moduleName == "arm":
            self.keepChildrenDelete(moduleName)
        #delete control and set instance to None
        exec("self.%s_anim_classInstance.deleteControl()"%moduleName)
        exec("self.%s_anim_classInstance = None"%moduleName)
    
    def checkHookCanIK(self):
        #if three class exists
        if cmds.objExists("boom_ctr_grp") and cmds.objExists("arm_ctr_grp") and cmds.objExists("bucket_ctr_grp"):
            return True
        else: return False

    def createhookIK(self):
        #create IK
    
        #got to delete stuff
        cmds.parent("bucket_ctr_grp", world = True)
        constraints = cmds.listRelatives("boom_jnt", allDescendents = True, type = "parentConstraint")
        cmds.delete("boom_ctr_grp", constraints)

        #create skinning bones so there can be IK / FK switching
        Ikreturns = cmds.ikHandle(name = "bucket_ikH", startJoint = "boom_jnt", endEffector = "bucket_jnt", solver = "ikSCsolver")
        cmds.rename("effector1", "bucket_efr")
        
        #bucket control drives Ik joint
        cmds.parent(Ikreturns[0], "bucket_ctr")
        cmds.setAttr("%s.visibility"%Ikreturns[0], 0)
        
        #constrain the rotation of the control to the joint
        cmds.orientConstraint("bucket_ctr", "bucket_jnt", name = "bucket_jnt_ortCt")
        
        #lock ik control attrs
        for attr in ["ry", "rz", "tx"]:
            cmds.setAttr("%s.%s"%("bucket_ctr", attr), keyable = False, lock = True)
        
        #unlock ik control attrs
        for attr in ["ty", "tz"]:
            cmds.setAttr("%s.%s"%("bucket_ctr", attr), keyable = True, lock = False)
        
        self.parentGroupsAndJoints("IKbucket")   
                    
    def keepChildrenDelete(self, moduleName):
        if cmds.objExists("bucket_jnt") and cmds.objExists("bucket_ctr_grp"):
            cmds.parent("bucket_jnt", "bucket_ctr_grp", world = True)
         
        if cmds.objExists("arm_jnt") and cmds.objExists("arm_ctr_grp"):
            cmds.parent("arm_jnt", "arm_ctr_grp", world = True) 
    
    def checkCanCreateTrack(self, *args):
        #if front and back exists
        try:
            back = self.getParent(self.finalDrive_placer_classInstance.geo[-1])
            front = self.getParent(self.frontIdler_placer_classInstance.geo[-1])
            canRun = True
        except:
            canRun = False
        if canRun:
            try:
                rollers = []
                for g in self.rollers_placer_classInstance.geo:
                    rollers.append(self.getParent(g))
            except:
                rollers = []
        else:
            print "something happend, not able to create track"
            return
        cmds.button("HDMAR_custom_track_btn", edit = True, enable = False)
        #get UI info
        bothSides = cmds.checkBox("HDMAR_track_left_right_chb", query = True, value = True)
        if bothSides:
            left = cmds.textFieldGrp("HDMAR_track_left_TFG", query = True, text = True)
            right = cmds.textFieldGrp("HDMAR_track_right_TFG", query = True, text = True)
        treadAmount = cmds.intSliderGrp("HDMAR_track_treadAmount_ISG", query = True, value = True)
        treadGeo = cmds.optionMenu("HDMAR_track_treadAmount_OM", query = True, value = True)
            
        #create track - left
        trackInfo = self.createTrack(treadAmount, front, back, treadGeo, rollers)
        geo = [front, back, rollers]
        self.createTrackControls(trackInfo, geo, "left")
        self.parentGroupsAndJoints("leftTrack")
        
        #check if option to create other side
        if bothSides:
            front_2 = cmds.ls(front.replace(left,right,1))[0]
            back_2 = cmds.ls(back.replace(left,right,1))[0]
            rollers_2 = []
            for i in range(len(rollers)):
                rollers_2.append(cmds.ls(rollers[i].replace(left,right,1))[0])   
            
            #create track - right
            trackInfo_2 = self.createTrack(treadAmount, front_2, back_2, treadGeo, rollers_2)
            geo_2 = [front_2, back_2, rollers_2]
            self.createTrackControls(trackInfo_2, geo_2, "right") 
            self.parentGroupsAndJoints("rightTrack")

        #create anim control    
    def createTrackControls(self, trackInfo, geo, side):
        #rename
        cmds.rename("treadCurve_cirBaseWire", "%s_treadCurve_cirBaseWire"%side)
        
        #track info == locatorGroup, valueInfoF, valueInfoB
        locatorGroup = trackInfo[0]
        locators = cmds.listRelatives(locatorGroup, 
                        children = True, 
                        allDescendents = True, 
                        type = "transform")
        valueInfoF = trackInfo[1]
        valueInfoB = trackInfo[2]
        rollerInfo = trackInfo[3]
        objects = trackInfo[4]
        pushOut = 0.5
        
        #for determining distance
        plusMas = cmds.shadingNode("plusMinusAverage", asUtility = True, name = "%sspinTrack_masterRotations_pluMin"%side)
        
        #organize info for creating controls
        wheels = [["front", valueInfoF, locators[6:11], [geo[0]]], ["back", valueInfoB, locators[:5], [geo[1]]]]
        for i in range(len(rollerInfo)):
            wheels.append(["roller_%s"%i, rollerInfo[i], locators[11+i*2:11+i*2+2], [geo[2][i]]])
        
        #create each control
        groups = objects
        joints = []
        for control in wheels:
            #get controller size
            distance = self.getDistanceBetweenTwoNumbers(control[1][1][0], control[1][1][1])
            
            #create circle control
            circleControl = cmds.circle(name = "%sTrack_%s_ctr"%(side, control[0]),
                radius = distance/2,
                constructionHistory = False)[0]
            cmds.rotate(0,90, circleControl)
            if side == "left": valX_ = control[1][0][0] + pushOut
            else: valX_ = control[1][0][1] - (pushOut)
            cmds.move(valX_,
                control[1][1][0] - self.getDistanceBetweenTwoNumbers(control[1][1][0], control[1][1][1])/2,
                control[1][2][0] - self.getDistanceBetweenTwoNumbers(control[1][2][0], control[1][2][1])/2,
                circleControl)
            
            #skin the geo to joint
            cmds.select(clear = True)
            joint_ = cmds.joint(name = "%sTrack_%s_jnt"%(side, control[0]))
            joints.append(joint_)
            cmds.move(control[1][0][0] - self.getDistanceBetweenTwoNumbers(control[1][0][0], control[1][0][1])/2,
                      control[1][1][0] - self.getDistanceBetweenTwoNumbers(control[1][1][0], control[1][1][1])/2,
                      control[1][2][0] - self.getDistanceBetweenTwoNumbers(control[1][2][0], control[1][2][1])/2,
                      joint_)
            #skin geo to joint
            for geometery in control[3]:
                #get the geo shape node for skinning
                geoShapes = cmds.listRelatives(geometery, shapes = True)
                #skin geo to joint
                skinCluster = cmds.skinCluster(joint_, geoShapes[0], 
                    name = "%sTrack_%s_skinCluster"%(side, control[0]), 
                    toSelectedBones = True, 
                    bindMethod = 0, 
                    skinMethod = 0, 
                    normalizeWeights = 1)[0]
            
            #parent the locators to the control
            cmds.parent(control[2], circleControl)   
            
            #parent constrain the joint to the control
            cmds.parentConstraint(circleControl, joint_, maintainOffset = True, name = "%s_prtCt"%circleControl, skipRotate = "x")
            
    ##########NEED TO CALCULATE FOR TRANSLATE TO USE FOR SPIN#################valGroup
    
            #create multiply divide node for the rotation of the wheel            
            #distance / circumference = revolutions
            spinZMulDiv1 = cmds.shadingNode("multiplyDivide", asUtility = True, name = "%sTrack_%s_spin_mulDiv"%(side, control[0]))
            cmds.setAttr("%s.operation"%spinZMulDiv1, 2)#division
            cmds.connectAttr("%s.output1D"%plusMas, "%s.input1X"%spinZMulDiv1)#translateZ
            cmds.setAttr("%s.input2X"%spinZMulDiv1, 3.14159265*distance)#pie*Diameter = circumference
            
            #revolutions to degrees
            spinZMulDiv2 = cmds.shadingNode("multiplyDivide", asUtility = True, name = "%sTrack_%s_degrees_mulDiv"%(side, control[0]))
            cmds.connectAttr("%s.outputX"%spinZMulDiv1, "%s.input1X"%spinZMulDiv2)
            cmds.setAttr("%s.input2X"%spinZMulDiv2, 360.0)#revolutions to degrees
            
            #user can edit
            spinZMulDiv3 = cmds.shadingNode("multiplyDivide", asUtility = True, name = "%sTrack_%s_factor_mulDiv"%(side, control[0]))
            cmds.connectAttr("%s.outputX"%spinZMulDiv2, "%s.input1X"%spinZMulDiv3)
            cmds.setAttr("%s.input2X"%spinZMulDiv3, 1)
            
            #offset
            plus = cmds.shadingNode("plusMinusAverage", asUtility = True, name = "%sTrack_%s_offset_pluMin"%(side, control[0]))
            cmds.connectAttr("%s.outputX"%spinZMulDiv3, "%s.input1D[0]"%plus)
            
    ######################CONNECT#########################
            cmds.connectAttr("%s.output1D"%plus, "%s.rx"%joint_)                                    
            
            #create control group
            group = cmds.group(name = "%sTrack_%s_ctr_grp"%(side, control[0]), world = True, empty = True)
            cmds.matchTransform(group, circleControl)
            cmds.parent(circleControl, group)
            groups.append(group)
            
        groups.insert(1, joints)
        groups.append(cmds.listRelatives(locatorGroup, type = "transform", children = True, allDescendents = True))#should be any locators leftover
        
        #import module
        exec("from HDMAR_scripts.MainFunctions.Animation import %sTrack_anim"%side)
        #create anim control
        exec("self.%sTrack_anim_classInstance = %sTrack_anim.%s%sTrack_anim(geo, groups)"%(side, side, side[0].upper(), side[1:]))
        exec("self.%sTrack_anim_classInstance.control()"%side) 
        
        #fix parenting
        for i in ["%sTrack_TreadFull"%side, "%s_treadCurve_cirBaseWire"%side]:
            cmds.parent(i, "%sTrack_ctr"%side)
            cmds.setAttr("%s.inheritsTransform"%i, 1)
            cmds.move(0, 0, 0, i)
        
        #fix track geo
        geoGroup = cmds.group(name = "%sTrack_geo_grp"%side, world = True, empty = True)
        cmds.parent("%sTrack_TreadFull"%side, world = True)
        cmds.move(0, 0, 0, "%sTrack_TreadFull"%side)
        cmds.parentConstraint("%sTrack_ctr"%side, geoGroup)
        cmds.parent("%sTrack_TreadFull"%side, geoGroup)
        
        #zero track ctr
        values =  cmds.xform("%sTrack_ctr"%side, query = True, objectSpace = True, translation = True, absolute = True)
        cmds.move(values[0],values[1],values[2], cmds.ls("%sTrack_ctr_shp*.cv[*]"%side), relative = True)
        childs = cmds.listRelatives("%sTrack_ctr"%side, children = True, type = "transform")
        cmds.parent(childs, "%sTrack_ctr"%side, world = True)
        cmds.makeIdentity("%sTrack_ctr"%side)
        cmds.parent("%sTrack_ctr"%side, "%sTrack_ctr_grp"%side)
        cmds.move(0,0,0,"%sTrack_ctr"%side, objectSpace = True)
        cmds.parent(childs, "%sTrack_ctr"%side)

        #handle track rotation
    ##########NEED TO CALCULATE FOR TRANSLATE TO USE FOR SPIN#################valGroup 
        
        arcLenLen = cmds.arclen("%sTrack_treadCurve_cir"%side)

        #create multiply divide node for the rotation of the wheel            
        #distance / circumference = revolutions
        spinZMulDiv1 = cmds.shadingNode("multiplyDivide", asUtility = True, name = "%sSpinTrack_trackSpins_mulDiv"%side)
        cmds.setAttr("%s.operation"%spinZMulDiv1, 2)#division
        cmds.connectAttr("%s.output1D"%plusMas, "%s.input1X"%spinZMulDiv1)
        cmds.setAttr("%s.input2X"%spinZMulDiv1,arcLenLen)
        
        #revolutions to degrees
        spinZMulDiv2 = cmds.shadingNode("multiplyDivide", asUtility = True, name = "%sSpinTrack_trackDegrees_mulDiv"%side)
        cmds.connectAttr("%s.outputX"%spinZMulDiv1, "%s.input1X"%spinZMulDiv2)
        cmds.setAttr("%s.input2X"%spinZMulDiv2, 360.0)
        
        #scale rotation factor
        spinZMulDiv3 = cmds.shadingNode("multiplyDivide", asUtility = True, name = "%sSpinTrack_trackFactor_mulDiv"%side)
        cmds.connectAttr("%s.outputX"%spinZMulDiv2, "%s.input1X"%spinZMulDiv3)
        cmds.setAttr("%s.input2X"%spinZMulDiv3, 1.0)

        #offset
        plus = cmds.shadingNode("plusMinusAverage", asUtility = True, name = "%sSpinTrack_track_offset_pluMin"%side)
        cmds.connectAttr("%s.outputX"%spinZMulDiv3, "%s.input1D[0]"%plus)
        cmds.connectAttr("%s.output1D"%plus, "%sTrack_TreadFull.rx"%side)
        #connect offset
        cmds.addAttr("%sTrack_ctr"%side, longName = "treadRotationOffset", attributeType = "double", defaultValue = 1.0, hidden = False, keyable = True)
        cmds.connectAttr("%s.treadRotationOffset"%("%sTrack_ctr"%side), "%s.input1D[1]"%plus)
        
        #connectFactor
        cmds.addAttr("%sTrack_ctr"%side, longName = "spinFactor", attributeType = "double", defaultValue = 1.0, hidden = False, keyable = True)
        for i in cmds.ls("%s*actor*"%side, type = "multiplyDivide"):
            cmds.connectAttr("%sTrack_ctr.spinFactor"%side, "%s.input2X"%i)
            
        #connectOffset
        for i in cmds.ls("%s*offset*"%side)[1:]:
            ctrl = "%sctr"%i.partition("offset_pluMin")[0]
            cmds.addAttr(ctrl, longName = "rotationOffset", attributeType = "double", defaultValue = 1.0, hidden = False, keyable = True)
            cmds.connectAttr("%s.rotationOffset"%(ctrl), "%s.input1D[1]"%i)

        #add the translates to get the rotation for all spins
        cmds.connectAttr("%sTrack_ctr.tz"%side, "%s.input1D[0]"%plusMas)
        self.connectControlsZtoTrack()
        
        cmds.addAttr("%sTrack_ctr"%side, longName = "rotationOffset", attributeType = "double", defaultValue = 0.0, hidden = False, keyable = True)
        cmds.connectAttr("%sTrack_ctr.rotationOffset"%side, "%s.input1D[1]"%plusMas)
        
        cmds.delete(locatorGroup)
    
    def connectControlsZtoTrack(self):
        for side in ["left", "right"]:
            plusMas = "%sspinTrack_masterRotations_pluMin"%side
            if cmds.objExists(plusMas):
                index = 2
                for i in ["move_ctr", "lowerBody_ctr"]:
                    if cmds.objExists(i):
                        if not cmds.listConnections("%s.input1D[%s]"%(plusMas, index)):
                            cmds.connectAttr("%s.tz"%i, "%s.input1D[%s]"%(plusMas, index))
                
                    index += 1            
        
    def createTrack(self, numOfInst, front, back, treadRepeatObj, rollers):#rollers need to be front to back
        #add function to organize from front to back
        
        #check do we have the main dirrection
        #WForward = [1.0, 0.0, 0.0, "x"]#inital values
        WForward = [0.0, 0.0, 1.0, "z"]#inital values
        treadObj = self.importTread(treadRepeatObj)
        geo = [front, back]
        
        cvPos = [[0.0,0.0],[0.0,0.0],[0.0,0.0],[0.0,0.0],[0.0,0.0],[0.0,0.0],[0.0,0.0],[0.0,0.0],[0.0,0.0],[0.0,0.0]]
        #check for positional values based on geo
        
        #get position values for front
        zForward = WForward[3] == "z"
        
        #get the Center
        cenPos = self.getCenterPointOfObjects(geo)
        
        #calculate curvePoint Position Data
        valueInfoF = self.getPosInfoOfFarPoints(front)
        midXF = self.getDistanceBetweenTwoNumbers(valueInfoF[0][0], valueInfoF[0][1])/2 + valueInfoF[0][1]
        midYF = self.getDistanceBetweenTwoNumbers(valueInfoF[1][0], valueInfoF[1][1])/2 + valueInfoF[1][1]
        midZF = self.getDistanceBetweenTwoNumbers(valueInfoF[2][0], valueInfoF[2][1])/2 + valueInfoF[2][1]
        
        valueInfoB = self.getPosInfoOfFarPoints(back)
        midXB = self.getDistanceBetweenTwoNumbers(valueInfoB[0][0], valueInfoB[0][1])/2 + valueInfoB[0][1]
        midYB = self.getDistanceBetweenTwoNumbers(valueInfoB[1][0], valueInfoB[1][1])/2 + valueInfoB[1][1]
        midZB = self.getDistanceBetweenTwoNumbers(valueInfoB[2][0], valueInfoB[2][1])/2 + valueInfoB[2][1]
        
        centerYDif=self.getDistanceBetweenTwoNumbers(valueInfoF[1][0], valueInfoB[1][0])/2
        if valueInfoF[1][0]>valueInfoB[1][0]:
            centerY = valueInfoB[1][0] + centerYDif
        else:
            centerY = valueInfoF[1][0] + centerYDif
        #               [0][0]     [0][1]        [1][0]    [1][1]       [2][0]     [2][1]
        if zForward:#[[max(xVal), min(xVal)], [max(yVal), min(yVal)], [max(zVal), min(zVal)]]
            cvPos = [[valueInfoF[1][1], midZF],#10
                    self.getPosAlongCircle(front, (135, 0, 0))[1:],#9
                    [midYF, valueInfoF[2][0]],#8
                    self.getPosAlongCircle(front, (45, 0, 0))[1:],#7
                    [valueInfoF[1][0], midZF],#6
                    [centerY, cenPos[2]],#5
                    [valueInfoB[1][0], midZB],#4
                    self.getPosAlongCircle(back, (-45, 0, 0))[1:],#3
                    [midYB, valueInfoB[2][1]],#2
                    self.getPosAlongCircle(back, (-135, 0, 0))[1:],#1
                    [valueInfoB[1][1], midZB]]#0
            distance = self.getDistanceBetweenTwoNumbers(valueInfoF[2][0], valueInfoB[2][1])
        
        else:#xForward
            cvPos = [[valueInfoF[1][1], midXF],#10
                    reversed(self.getPosAlongCircle(front, (0, 0, -135))[:-1]),#9
                    [midYF, valueInfoF[0][0]],#8
                    reversed(self.getPosAlongCircle(front, (0, 0, -45))[:-1]),#7
                    [valueInfoF[1][0], midXF],#6
                    [centerY, cenPos[0]],#5
                    [valueInfoB[1][0], midXB],#4
                    reversed(self.getPosAlongCircle(back, (0, 0, 45))[:-1]),#3
                    [midYB, valueInfoB[0][1]],#2
                    reversed(self.getPosAlongCircle(back, (0, 0, 135))[:-1]),#1
                    [valueInfoB[1][1], midXB]]#0
            distance = self.getDistanceBetweenTwoNumbers(valueInfoF[0][0], valueInfoB[0][1])

        #create circle for deformer
        treadCurve = cmds.circle(name = "treadCurve_cir",
            radius = distance/2,
            sections = 50,
            constructionHistory = False)[0]
        
        #fixes the issue with normals backward
        cmds.rotate(0, 0, -90, treadCurve)
        cmds.xform(treadCurve, centerPivots = True)
        cmds.makeIdentity(apply = True)
        
        #sections for circle with rollers
        sections = len(cvPos) + 1#extra(+1) for middle of bot
        if len(rollers) > 0:
            sections = len(cvPos) + len(rollers)*2
            
        #create circle for shape
        treadCurveShape = cmds.circle(name = "treadCurveShape_cir",
            radius = distance/2,
            sections = sections,
            constructionHistory = False)[0]
        cmds.move(cenPos[0], cenPos[1], cenPos[2], treadCurveShape)
        cmds.xform(treadCurveShape, centerPivots = True)
        cmds.makeIdentity(apply = True)
        
        #circle becomes proper shape
        cvsNum = ["10", "9", "8", "7", "6", "5", "4", "3", "2", "1", "0"]
        if zForward:
            cmds.rotate(0,90,0, treadCurve)            
            for i in range(len(cvsNum)):#11
                cmds.move(0, cvPos[i][0], cvPos[i][1], 
                    ["%s.cv[%s]"%(treadCurveShape, cvsNum[i]),
                     "%s.cv[%s]"%(treadCurveShape, cvsNum[i])])
            
            #a small scaling 
            for wheel in [[front, "6:10"], [back, "0:4"]]:
                pivot = cmds.xform(wheel[0], 
                        query = True, 
                        worldSpace = True, 
                        rotatePivot = True)
                cmds.scale(1, 1.12, 1.12, 
                    "%s.cv[%s]"%(treadCurveShape, wheel[1]), 
                    relative = True, 
                    pivot = pivot)
            
            valueInfoR = []
            if len(rollers) == 0:
                cmds.move(0, 0, cenPos[2], "%s.cv[11]"%treadCurveShape)
            else:
                #get rollers bot position Y
                index = len(cvPos)
                for i in range(index, len(rollers)+index):                    
                    valueInfo = self.getPosInfoOfFarPoints(rollers[i-len(cvPos)])
                    midZ = self.getDistanceBetweenTwoNumbers(valueInfo[2][0], valueInfo[2][1])/2 + valueInfo[2][1]
                    cmds.move(0, valueInfo[1][1], midZ, "%s.cv[%s]"%(treadCurveShape, index))
                    index += 1
                    cmds.move(0, valueInfo[1][1], midZ, "%s.cv[%s]"%(treadCurveShape, index))
                    index += 1
                    valueInfoR.append(valueInfo)
           
        else:#not done x forward
            cmds.rotate(0,180,0, treadCurve)
            for i in range(6):
                cmds.move(cvPos[i][1], cvPos[i][0], 0, 
                    ["%s.ep[%s]"%(treadCurveShape, cvsNum[i]), 
                     "%s.ep[%s]"%(treadCurveShape, cvsNum[i])])
            cmds.move(cenPos[0], cvPos[3][0], 0, "%s.ep[0]"%treadCurveShape)
            if len(rollers) == 0:
                cmds.move(cenPos[0], 0, 0, "%s.ep[4]"%treadCurveShape)
            
        #push out the curve
        if zForward:
            cmds.setAttr("%s.tx"%(treadCurveShape), cenPos[0])
            cmds.setAttr("%s.tx"%(treadCurve), cenPos[0])
        else:
            cmds.setAttr("%s.tz"%(treadCurveShape), cenPos[2])
            cmds.setAttr("%s.tz"%(treadCurve), cenPos[2])
        cmds.xform(treadCurveShape, treadCurve, centerPivots = True)
        cmds.makeIdentity(treadCurveShape, treadCurve, apply = True)
                
        #option for user to edit track before or after creation
        clusterGroup = cmds.group(name = "cluster_grp", world = True, empty = True)
        locatorGroup = cmds.group(name = "locator_grp", world = True, empty = True)
        cvs = cmds.ls("%s.cv[*]"%treadCurveShape, flatten = True)
        for i in range(len(cvs)):
            loc = cmds.spaceLocator(name = "%s_loc_%s"%(treadCurveShape, i))[0]
            cmds.scale(3,3,3, loc)
            cmds.setAttr("%s.visibility"%loc, 0)
            cvPos = cmds.xform(cvs[i], query = True, translation = True, worldSpace = True)
            cmds.move(cvPos[0], cvPos[1], cvPos[2], loc)
            cluster = cmds.cluster(cvs[i], name = "%s_clu_%s_"%(treadCurveShape, i))[1]
            cmds.setAttr("%s.visibility"%cluster, 0)
            cmds.parent(cluster, clusterGroup)
            cmds.parent(loc, locatorGroup)
            cmds.parentConstraint(loc, cluster, name = "%s_prtCt"%loc)##
        cmds.setAttr("%s.visibility"%locatorGroup, 0) 
          
        #animating the object along a curve         
        motPath = cmds.pathAnimation(treadObj, treadCurve, 
            follow = True,
            followAxis = "z",
            upAxis = "y",
            worldUpType = "normal",
            inverseUp = True,
            startTimeU = 1,
            endTimeU = numOfInst)
 
        #make linear
        cmds.keyTangent("%s_uValue"%motPath, 
            time = (1, numOfInst), 
            inTangentType = "linear", 
            outTangentType = "linear")
        
        #duplicate track on curve
        track = []
        for i in range(1, numOfInst):
            cmds.currentTime(i)
            track.append(cmds.duplicate(treadObj)[0])
        cmds.delete(motPath, treadObj)
        treadObj = cmds.polyUnite(track, n="TreadFull",ch=False)
        
        #match pivot
        cmds.matchTransform(treadObj, treadCurve, pivots = True)
        
        #create wire deformer
        wire = cmds.wire(treadObj, wire = treadCurve, name = "_wire")
        cmds.setAttr("%s.dropoffDistance[0]"%wire[0], 40)
        cmds.setAttr("treadCurve_cirBaseWire.inheritsTransform", 0)
        
        #rebuild curve
        cmds.rebuildCurve(
            treadCurveShape, 
            constructionHistory = False,
            spans = 50)#having a high number helps with wavy ness
        
        #make shape the right shape 
        blendShape = cmds.blendShape(treadCurveShape, treadCurve)[0]
        cmds.setAttr("%s.%s"%(blendShape, treadCurveShape), 1)
        
        objects = [[treadObj[0], treadCurve, treadCurveShape], clusterGroup]
        
        #visibility of curve
        for i in [treadCurveShape, treadCurve]:
            cmds.setAttr("%s.visibility"%i, 0)
        
        #needs to return info for the controls to be created
        return locatorGroup, valueInfoF, valueInfoB, valueInfoR, objects
        
    #positions along a circle
    def getPosAlongCircle(self, geo, rotate):
        valueInfo = self.getPosInfoOfFarPoints(geo)
        distance = self.getDistanceBetweenTwoNumbers(valueInfo[1][0], valueInfo[1][1])
        loc = cmds.spaceLocator(name = "diffinePointCircle_loc_temp")[0]
        cmds.matchTransform(loc, geo)
        cmds.makeIdentity(apply = True)
        cmds.rotate(rotate[0], rotate[1], rotate[2], relative = True)
        cmds.move(0,distance/2,0, relative = True, objectSpace = True)
        pos = cmds.xform(loc, query = True, worldSpace = True, rotatePivot = True)
        cmds.delete(loc)
        return pos
    
    #calculate difference between the two
    def getDistanceBetweenTwoNumbers(self, num1, num2):
        return abs(num1-(num2))
            
        #make group To get the Center of loc
    def getCenterPointOfObjects(self, objects):
        locs = []
        for obj in objects:
            loc = cmds.spaceLocator(name = "diffineCenter_loc_temp")[0]
            cmds.matchTransform(loc, obj)
            locs.append(loc)
        cmds.select(locs)    
        tempGrp = cmds.group(name = "diffineCenter_grp_temp")
        cenPos = cmds.xform(tempGrp, query = True, worldSpace = True, rotatePivot = True)
        cmds.delete(tempGrp)
        return cenPos
    
    def getPosInfoOfFarPoints(self, geo):
        xVal = []
        yVal = []
        zVal = []
        for vert in cmds.ls("%s.vtx[*]"%geo, flatten = True):
            vertPos = cmds.xform(vert, query = True, translation = True, worldSpace = True)
            xVal.append(vertPos[0])
            yVal.append(vertPos[1])
            zVal.append(vertPos[2]) 
        valueInfo = [[max(xVal), min(xVal)], [max(yVal), min(yVal)], [max(zVal), min(zVal)]]
        return valueInfo

    def importTread(self, name = "tread1"):
        path = "%sHDMAR_scripts/Geometry/%s.obj"%(cmds.internalVar(userScriptDir = True), name)
        cmds.file(path, i=True)
        return "%s_geo"%name
        
    def parentGroupsAndJoints(self, name):   
        self.connectControlsZtoTrack()
        
        parent = None
        child = None
        if name == "lowerBody":
            parent = ["move_ctr", "main_jnt_grp"]
            child = ["upperBody"]
        elif name == "upperBody":
            parent = ["lowerBody_ctr", "lowerBody_jnt"]
            child = ["steering", "boom", "door"]
        elif name == "steering" or name == "door":
            parent = ["upperBody_ctr", "upperBody_jnt"]
        elif name == "leftTrack" or name == "rightTrack":
            if cmds.objExists("move_ctr"):
                cmds.parent(cmds.ls("*Track_geo_grp"), "main_geo_grp")
            if cmds.objExists("lowerBody_ctr"):
                parent = ["lowerBody_ctr", "lowerBody_jnt"]
            elif cmds.objExists("move_ctr"):
                parent = ["move_ctr", "main_jnt_grp"]
            if parent != None: 
                cmds.parent("%s_ctr_grp"%name, parent[0])
                wheels = cmds.ls("%s_*_jnt"%name)
                for w in wheels:
                    cmds.parent(w, parent[1])
            return
        elif name == "bucket" or name == "arm" or name == "boom" :
            parent = ["upperBody_ctr", "upperBody_jnt"]
            if name == "boom": child = ["arm"]    
            if name == "arm":
                if cmds.objExists("boom_ctr"): parent = ["boom_ctr", "boom_jnt"]
                child = ["bucket"]
            if name == "bucket":
                if cmds.objExists("arm_ctr"): parent = ["arm_ctr", "arm_jnt"]
        elif name == "IKbucket":
            name = "bucket"
            parent = ["upperBody_ctr", "dontChangeJointParent"]
        elif name == "main":
            for i in ["lowerBody", "upperBody", "steering", "door", "bucket", "arm", "boom"]:
                if cmds.objExists("%s_ctr_grp"%i) and cmds.listRelatives("%s_ctr_grp"%i, parent = True) == None: 
                    cmds.parent("%s_ctr_grp"%i, "move_ctr")
                if cmds.objExists("%s_jnt"%i) and cmds.listRelatives("%s_jnt"%i, parent = True) == None:
                    cmds.parent("%s_jnt"%i, "main_jnt_grp") 
            for i in ["leftTrack", "rightTrack"]:
                if cmds.objExists("%s_geo_grp"%i):
                    cmds.parent("%s_geo_grp"%i, "main_geo_grp")
                if cmds.objExists("%s_ctr_grp"%i) and cmds.listRelatives("%s_ctr_grp"%i, parent = True) == None:
                    cmds.parent("%s_ctr_grp"%i, "move_ctr")
                    wheels = cmds.ls("%s_*_jnt"%i)
                    for w in wheels:
                        cmds.parent(w, "main_jnt_grp")
                    
        if parent != None:
            if cmds.objExists(parent[0]): cmds.parent("%s_ctr_grp"%name, parent[0])
            if cmds.objExists(parent[1]): cmds.parent("%s_jnt"%name, parent[1])  

            if child != None:
                for c in child:
                    if cmds.objExists("%s_ctr_grp"%c): cmds.parent("%s_ctr_grp"%c, "%s_ctr"%name)
                    if cmds.objExists("%s_jnt"%c): cmds.parent("%s_jnt"%c, "%s_jnt"%name)
                #for track - special case
                if name == "lowerBody":
                    wheels = cmds.ls("*Track_*_jnt")
                    if wheels:
                        for w in wheels:
                            cmds.parent(w, "lowerBody_jnt")
                        if cmds.objExists("leftTrack_ctr_grp"): cmds.parent("leftTrack_ctr_grp", "lowerBody_ctr")
                        if cmds.objExists("rightTrack_ctr_grp"): cmds.parent("rightTrack_ctr_grp", "lowerBody_ctr")
                            
        
    def getOnlyMeshFromSelection(self, geo):
        cmds.select(geo, replace = True)
        meshs = cmds.ls(selection = True, type = "mesh")
        cmds.select(meshs, replace = True)
        for g in geo:
            cmds.select(cmds.listRelatives(g, type = "mesh"), add = True)
        OnlyMeshs = cmds.ls(selection = True, type = "mesh")
        cmds.select(clear = True)
        
        return OnlyMeshs
        
    def getParent(self, geo):
        parent = cmds.listRelatives(geo, parent = True)[0].encode("utf-8")
        return parent
    
        
if __name__ == "__main__":        
    classInstance = Main()
    rollers = ["left_smallWheel_1_geo",
               "left_smallWheel_2_geo",
               "left_smallWheel_3_geo", 
               "left_smallWheel_4_geo",  
               "left_smallWheel_5_geo", 
               "left_smallWheel_6_geo", 
               "left_smallWheel_7_geo",
               "left_smallWheel_8_geo",]
    #rollers = []
    trackInfo = classInstance.createTrack(140, "left_frontWheel_geo", "left_backWheel_geo", "tread1", rollers)
    geo = ["left_frontWheel_geo", "left_backWheel_geo", rollers]
    classInstance.createTrackControls(trackInfo, geo, "left")
