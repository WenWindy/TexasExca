'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By Rodolfo & Windy Wen
#With assistance from BCIT
#creates shapes for a hook (place holders)
#Location ...
'''

#Add dependencies
import maya.cmds as cmds
from random import uniform as rand
from HDMAR_scripts.System import main
from functools import partial
import math

#Delete any duplicate window before creating a new one
class MainUI(main.Main):
    URL_ICON_PATH = "%sHDMAR_scripts/Icons/"%cmds.internalVar(userScriptDir = True)  

    # Question mark button links
    smartRigLink = "youtube.com/watch?v=MPzCYW8iG1Q"
    
    #Smart setup steps in a list
    #List of lists
    smartSetupList = [
#   Title_TX                        Icon,                                   			 Instruction1_TX                   										Instruction2_TX                   						  Action(4)            Action Parameter,        Button1     Button2 skip 		Require Selection?(8)
    ["Welcome to the smart setup!","everything_icon.png",       			           			        "Press 'Next' to begin",             									  				  	   "",                      	  "",                       "",        "Next",    0, 							False],
    [            "Main Controller","main_icon_1.png",   "Select all your geo, make sure it points at the Z+ axis",          										"Then press 'Next'",  "SetupSmartMainController",                       "",        "Next",    0, 							True],
    #lower body (2)
	[      "Lower Body Controller", "lowerBody_icon.png",		  		 		"Select the geo for the excavator's lower half",     													"Then press 'Next'",          "loadSelectedList",   "HDMAR_lowerBody_TFBG",        "Next",    0, 							True],
    [      "Lower Body Controller", "lowerBody_icon.png",     	 "Position the curve to the pivot of your lower half",    												 	"Then press 'Next'", "createControlsButtonPress",   					 "lowerBody",        "Next",    0, 							False],
    #upper body (4)
	[    	  "Set up Upper body?",                   "",			"Would you like setting up the excavator's Upper Body?",				"(Choosing 'No' Will skip to the Tracks)",       	 									"",   										"",         "Yes",   21, 							False],
    [      "Upper Body Controller", "upperBody_icon.png",		 "Select the geo for the excavator's rotating upper half",     													"Then press 'Next'",          "loadSelectedList",   "HDMAR_upperBody_TFBG",        "Next",    0, 							True],
    [      "Upper Body Controller", "upperBody_icon.png",    		 "Position the curve to the pivot of your upper half",    													"Then press 'Next'", "createControlsButtonPress",   					 "upperBody",        "Next",    0, 							False],
    #door(7)
[    				"Set up Door?",                   "",			      "Would you like setting up the excavator's door?","(Choosing 'No' will skip to the steering wheel)",       	 									"",   										"",         "Yes",    10, 							False],
[      			 "Door Controller", 		 "door_icon.png", 								  "Select the geo for the excavator's door",     													"Then press 'Next'",          "loadSelectedList",   		 "HDMAR_door_TFBG",        "Next",    0, 							True],
[      			 "Door Controller", 		 "door_icon.png",    				   "Position the curve to the pivot of your door",    													"Then press 'Next'", "createControlsButtonPress",   							  "door",        "Next",    0, 							False],
    #steering wheel (10)
    [     "Set up Steering wheel?",                   "",	"Would you like setting up the excavator's steering wheel?",  "(Choose 'No' to skip to the excavator's boom)",       	 									"",   										"",         "Yes",   13, 							False],
    [  "Steering Wheel Controller", 		"steer_icon.png", 			  "Select the geo for the excavator's steering wheel",     													"Then press 'Next'",          "loadSelectedList",    "HDMAR_steering_TFBG",        "Next",    0, 							True],
    [  "Steering Wheel Controller", 		"steer_icon.png",    "Position the curve to the pivot of your steering wheel",    													"Then press 'Next'", "createControlsButtonPress",   						"steering",        "Next",    0, 							False],
	#boom (!3)
[    				"Set up Boom?",                   "",						"Would you like setting up the excavator's hook?", "(Choose 'No' to skip to the excavator's track)",       	 									"",   										"",         "Yes",    21, 							False],
    [  			 "Boom Controller", 		 "boom_icon.png", 			 					  "Select the geo for the excavator's boom",     													"Then press 'Next'",          "loadSelectedList",   		 "HDMAR_boom_TFBG",        "Next",    0, 							True],
    [  			 "Boom Controller", 		 "boom_icon.png",    					 "Position the curve to the pivot of your boom",    													"Then press 'Next'", "createControlsButtonPress",   								"boom",        "Next",    0, 							False],
	#arm (16)
	[  					  "Arm Controller", 		  "arm_icon.png", 			 					   "Select the geo for the excavator's arm",     													"Then press 'Next'",          "loadSelectedList",   		  "HDMAR_arm_TFBG",        "Next",    0, 							True],
    [  				 	  "Arm Controller", 		  "arm_icon.png",    					  "Position the curve to the pivot of your arm",    													"Then press 'Next'", "createControlsButtonPress",   			 				 	 "arm",        "Next",    0, 							False],
	#bucket (18)
	[  				 "Bucket Controller", 	 "bucket_icon.png", 			 			 		"Select the geo for the excavator's bucket",     													"Then press 'Next'",          "loadSelectedList",   	 "HDMAR_bucket_TFBG",        "Next",    0, 							True],
    [  				 "Bucket Controller", 	 "bucket_icon.png",    			 	 "Position the curve to the pivot of your bucket",    													"Then press 'Next'", "createControlsButtonPress",   							"bucket",        "Next",    0, 							False],
	#boom IK  (20)
 	[    				 "Set up Hook IK?",      "boom_icon.png",								"Would you like enabling an IK for the Hook?", "(Choose 'No' to skip to the excavator's track)",       	 			"IKButtonPressed",   										"",         "Yes",   21, 							False],
	#tracks (21)
 	[    				 "Set up Tracks?",      "track_icon.png",					"Would you like setting up the excavator's tracks?", 								"(This is the last set of steps)",       	 									"",   										"",         "Yes",    24, 							False],
	[  				 "Track Controller", 	  "roller_icon.png", 			 	"Select all your wheels, from the left side, in order. ",     						  "From front to back. Then press 'Next'",        "SetupGetWheelLists",   	 								  "",        "Next",    0, 							True],
	[  				 "Track Controller", 	   "track_icon.png", "Additional options for the track generation have been made available", "Choose if you wish to mirror your tracks and your tread amount", "SetupPassValuesAndCreateTrack", "", "Next",  0, 							False],
	#Done (24)
    [							 "End of Setup","everything_icon.png",       			           			 "All set! Press 'Next to finish",             									  				  	   "",                      	  "",                       "",        "Next",    0, 							False]
    ]

	#Keep track of which element you're pointing at
    smartSetupListElement = 0

    def createUI(self):
        
        #Search for duplicate windows
        if cmds.window("AutoRigger_WIN", exists = True):
            cmds.deleteUI("AutoRigger_WIN")
        
        #Create window with name
        cmds.window("AutoRigger_WIN", 
            title = "Heavy Duty Machine Auto Rigger", 
            sizeable = True, 
            widthHeight = (415, 750), #Maya doesn't size the window when instancing it
            closeCommand = self.closingWindowReminder)
        
        #Create UI layout for the window
        self.createUILayout()
        
        #Resize window
        cmds.window("AutoRigger_WIN", edit = True,
            widthHeight = (415, 750)) #It does resize the window here though
        
        #Display window
        cmds.showWindow("AutoRigger_WIN") 
    
    def closingWindowReminder(self):
        cmds.confirmDialog(title = "Disclaimer", 
                           message = "You will no longer be able to edit the controllers",  
                           defaultButton = "Understood")
        
    def createUILayout(self):
        '''
        #Create tha main layout with scrolling
        cmds.scrollLayout("HDMAR_Main_SL", 
                            horizontalScrollBarThickness=16,
                            verticalScrollBarThickness=16,
                            height=700)
        '''
        DarkGray = [0.2, 0.2, 0.2]
        DarkerGray = [0.15, 0.15, 0.15]
        Blue =   [0.15, 0.25, 0.55]
        Purple = [0.31, 0.18, 0.31]
        Green =  [0.13, 0.37, 0.13]
        Orange = [0.48, 0.25, 0]
        Red = [0.4, 0.15, 0.15]
        #Create the layout holder. This carries all the column layouts used for tabs
        cmds.tabLayout("HDMAR_TabMaster_TL", 
            scrollable = True, 
            innerMarginWidth = 5, 
            innerMarginHeight = 5) #my edit

        ###Template tab
        cmds.columnLayout("HDMAR_TemplateTab_CL")

        #Choose model frame layout. Is collapsable
        cmds.frameLayout("HDMAR_ChooseModel_FL",label = "Choose Model", 
            width = 400, 
            marginWidth= 5, 
            collapsable = True, 
            collapse = False)
        cmds.separator(style = "none", height = 5)  

        #Option Menu. In demo it has multiple templates, but for our innitial project it only has Excavator as an option
        cmds.optionMenu(label = "Select Template: ")
        cmds.separator(style = "none", height = 5)  
        cmds.menuItem(label = "Excavator")  
        
        #Image loaded
        cmds.iconTextButton(style = "iconOnly", 
            image1 = "%severything_icon.png"%self.URL_ICON_PATH, 
            label = "sphere", 
            height = 320,  
            scaleIcon = True) 
        cmds.separator(style = "none", height = 5)  
        
        #Row layout holding buttons
        cmds.rowLayout(numberOfColumns = 2, columnAlign1 = "center")
        cmds.button("HDMAR_StartSmart_BT",label = "Start Rig Smart Setup", command = self.StartSmartSetup )
        # cmds.button(label = "?", backgroundColor = (DarkGray), command = partial(self.showLink, smartRigLink)))

        #Smart Setup for proxy rigging
        cmds.setParent("HDMAR_TemplateTab_CL")
        cmds.columnLayout("HDMAR_SmartSetup_CL")
     
        #Done with the frameLayout, so we go back to the column layout
        cmds.setParent("HDMAR_TemplateTab_CL")
        cmds.separator(style = "none", height = 2)  
        
        #Generate Rig Layout
        #This framelayout is invisible until the smart setup begins
        cmds.frameLayout("HDMAR_GenerateRig_FL",label = "Rig Generation Instructions", 
            width = 400,
            marginWidth = 5, 
            # collapsable = True, 
            collapse = False,
            manage=False)
        cmds.separator(style = "none", height = 1)  
        cmds.text("HDMAR_RIG_SmartSetup_Step_Title_TX",font = "boldLabelFont", label = "Welcome to the smart setup!", align = "center")

        cmds.columnLayout(columnAlign = "center", width = 400)
        cmds.iconTextButton("HDMAR_RIG_SmartSetup_Step_Icon_ITB",style = "iconOnly", 
            image1 = "%severything_icon.png"%self.URL_ICON_PATH, 
            label = "sphere", 
            width = 100, height = 100, 
            scaleIcon = True) 
        cmds.setParent("..")
        
        cmds.text("HDMAR_RIG_SmartSetup_Step_Instruction1_TX",label = "You shouldn't be able to see this!", align = "left")
        cmds.text("HDMAR_RIG_SmartSetup_Step_Instruction2_TX",label = "", align = "left")
        cmds.separator(style = "none", height = 1)  

        #Generate additional fields for set
        cmds.columnLayout("HDMAR_track_smartSetup_additionalOptions_CL",manage=False)

        #Generate fields via a function inside our additional Options Column Layout
        self.generateTracksCheckboxAndTreadAmount("_smartSetup")
        cmds.setParent("..")

        #Add row with buttons
        cmds.rowLayout(numberOfColumns = 2)
        cmds.button("HDMAR_RIG_SmartSetup_NextAction_BT",label = "Next")
        cmds.button("HDMAR_RIG_SmartSetup_SecondAction_BT",label = "No", manage=False)
        
        #We're finally done with all of the first tab, so we go back to the mainTab
        cmds.setParent("HDMAR_TabMaster_TL")

        ###Manual tab
        cmds.columnLayout("HDMAR_ManualTab_CL")

        #Step 1 Add locators FrameLayout
        cmds.frameLayout("HDMAR_Step1_AddLocator_FL", label = "Step 1: Add Locators", 
            width = 400, 
            marginWidth = 5, 
            collapsable = True, 
            collapse = False) 
        
        self.createSubframeWithIconTextsButtonAndOptions("Master", 
            Blue, [["main","main_icon_1.png","youtube.com/watch?v=sEI9zn7nH38&t=17s"],["lowerBody","lowerBody_icon.png","youtube.com/watch?v=sEI9zn7nH38&t=52s"],["upperBody","upperBody_icon.png","youtube.com/watch?v=sEI9zn7nH38&t=70s"]])
        self.createSubframeWithIconTextsButtonAndOptions("Body", 
            Purple, [["door","door_icon.png","youtube.com/watch?v=sEI9zn7nH38&t=122s"],["steering","steering_icon.png","youtube.com/watch?v=sEI9zn7nH38&t=139s"]])
        self.createSubframeWithIconTextsButtonAndOptions("Hook", 
            Green, [["bucket","bucket_icon.png","youtube.com/watch?v=sEI9zn7nH38&t=158s"],["arm","arm_icon.png","youtube.com/watch?v=sEI9zn7nH38&t=179s"],["boom","boom_icon.png","youtube.com/watch?v=sEI9zn7nH38&t=200s"]])
        self.createSubframeWithIconTextsButtonAndOptions("Track", 
            Orange, [["frontIdler","frontIdler_icon.png","youtube.com/watch?v=sEI9zn7nH38&t=237s"],
						["rollers","roller_icon.png","youtube.com/watch?v=sEI9zn7nH38&t=246s"],
						["finalDrive","finalDrive_icon.png","youtube.com/watch?v=sEI9zn7nH38&t=258s"],
						["track","track_icon.png","youtube.com/watch?v=sEI9zn7nH38&t=261s"]])


        #Add annotations after the fact *after creating all the text icon buttons and options
        
        #Query annotation (format HDMAR_%s_individualOption_CL )
        cmds.columnLayout("HDMAR_main_individualOption_CL", edit = True,
            annotation = "This is the main controller, which controls every other controller."\
                         "Place its pivot on the model's center mass, attached to the floor. "\
                         "Best not to move it before moving the 'ROOT' controller")
        cmds.columnLayout("HDMAR_lowerBody_individualOption_CL", edit = True,
            annotation = "This is the lowerBody controller. "\
                         "Place its pivot on the model's center mass, attached to the floor. "\
                         "Best used to translate the vehicle around")
        cmds.columnLayout("HDMAR_upperBody_individualOption_CL", edit = True,
            annotation = "This is the upperBody controller. "\
                         "Place its pivot at the center of the top body you will be rotating. "\
                         "Use it to spin the top part of the vehicle.")

        cmds.columnLayout("HDMAR_door_individualOption_CL", edit = True,
            annotation = "This is the door controller. "\
                         "Place its pivot at the hinge of the door to turn it propeTXy.")
        cmds.columnLayout("HDMAR_steering_individualOption_CL", edit = True,
            annotation = "This is the steering controller. "\
                         "Place its pivot at the center of the steering wheel to twist it.")

        cmds.columnLayout("HDMAR_bucket_individualOption_CL", edit = True,
            annotation = "This is the bucket controller. "\
                         "Place its pivot where the excavator's scoop would hinge. "\
                         "Can only be rotated in a single axis.")
        cmds.columnLayout("HDMAR_arm_individualOption_CL", edit = True,
            annotation = "This is the arm controller. "\
                         "Place its pivot where the 'elbow' of the excavator's arm is. "\
                         "Can only be rotated in a single axis.")
        cmds.columnLayout("HDMAR_boom_individualOption_CL", edit = True,
            annotation = "This is the cog controller. "\
                         "Place its pivot at the base of the excavator's arm. "\
                         "Can only be rotated in a single axis.")

        cmds.columnLayout("HDMAR_finalDrive_individualOption_CL", edit = True,
            annotation = "This is the final drive controller inside the tank tread. "\
                         "Place its pivot in the center, of where the back wheel is. "\
                         "Can only be rotated in a single axis.")
        cmds.columnLayout("HDMAR_rollers_individualOption_CL", edit = True,
            annotation = "This is the controller for the rollers. "\
                         "Place the locators at the center of each one of the inner rollers. "\
                         "Can only be rotated in a single axis.")
        cmds.columnLayout("HDMAR_frontIdler_individualOption_CL", edit = True,
            annotation = "This is the cog controller. "\
                         "Place its pivot at the base of the excavator's arm. "\
                         "Can only be rotated in a single axis.")
        cmds.columnLayout("HDMAR_track_individualOption_CL", edit = True,
            annotation = "This is the track controller. "\
                         "Place its pivot at the center mass of the treads. "\
                         "Can only be rotated in a single axis.")

        #Use extra column layout HDMAR_%s_CL_extra to add the IK button for the hook
        cmds.setParent("HDMAR_Hook_CL_extra")
        cmds.button("hookIK_btn", label = "IK", 
            backgroundColor = DarkGray, 
            enable = False, 
            width= 50, 
            command = partial(self.IKButtonPressed))

        #Add Extra Options for the COG fields
        cmds.setParent("HDMAR_upperBody_individualOption_CL")
        cmds.columnLayout()
        cmds.rowLayout(numberOfColumns=1)
        cmds.checkBox("HDMAR_upperBody_Limit_CB", label = "Limit rotation and translation", 
            align = "right", 
            changeCommand = self.toggleCOGOptions)
        cmds.setParent("..")
        cmds.columnLayout()
        cmds.floatSliderGrp("HDMAR_upperBody_RotationLimit_FSG", label = "Rotation Limits",
            field = True, 
            minValue = 0, 
            maxValue = 90, 
            fieldMinValue = 0, 
            fieldMaxValue = 360, 
            value = 15, 
            columnWidth = [[1, 90], [2, 100], [3, 175]], 
            columnAlign = [[1, "left"]],
            manage = False) 
        cmds.floatSliderGrp("HDMAR_upperBody_TranslationLimit_FSG",  label = "Translation Limits", 
            field = True,
            minValue = 0, 
            maxValue = 10, 
            fieldMinValue = 0, 
            fieldMaxValue = 100, 
            value = 2.5, 
            columnWidth = [[1, 90], [2, 100], [3, 175]], 
            manage = False )

        #Hide "Create controls" buttons for the first 3 options in the "TRACK" sub frame layout "HDMAR_%s_TFBG"%name
        cmds.button("HDMAR_finalDrive_btn", edit = True, manage = False)
        cmds.button("HDMAR_rollers_btn", edit = True, manage = False)
        cmds.button("HDMAR_frontIdler_btn",edit = True,  manage = False)

        #Disable the "Track" button
        cmds.iconTextButton("HDMAR_track_ITB",edit=True, enable = False)

        #We then add change commands to the Text Field Group Buttons for "FinalDrive" and "FrontIdle"   "HDMAR_%s_TFBG"
        cmds.textFieldButtonGrp("HDMAR_finalDrive_TFBG", edit = True, changeCommand = self.CheckTreadWheels, forceChangeCommand = True )
        cmds.textFieldButtonGrp("HDMAR_frontIdler_TFBG", edit = True, changeCommand = self.CheckTreadWheels, forceChangeCommand = True )

        #Additional fields for the track button options
        cmds.setParent("HDMAR_track_individualOption_CL")
        cmds.columnLayout("HDMAR_track_individualOptionContainer_CL",edit=True,manage=False)
        cmds.separator(height = 5)
        cmds.columnLayout("HDMAR_track_additionalOptions_CL")

        #Generate fields via a function inside our additional Options Column Layout
        self.generateTracksCheckboxAndTreadAmount()
       
        #We add a row layout for the create button and question mark
        
        cmds.rowLayout(numberOfColumns=2)
        
        #We create a custom button with tyler's edit
        LightGray = [0.4, 0.4, 0.4]
        cmds.button("HDMAR_custom_track_btn", label = "Create Controls", 
            backgroundColor = LightGray, 
            enable = True, 
            command = partial(self.checkCanCreateTrack)) 
        
        cmds.button(label = "?", backgroundColor = (DarkGray), command = partial(self.showLink, "youtube.com/watch?v=sEI9zn7nH38&t=261s"))
        cmds.setParent("..")

        #Now that we're done witht he first frame layout, so we go back to the column Layout
        cmds.setParent("HDMAR_ManualTab_CL")
        cmds.separator(style = "none", height = 7)
        


        ######Following code is temporarily disabled
        ### Start of Step 2 Disabled code
        

        #Step 2 Generate rigs FrameLayout
        # generateRigsFrameLayout = cmds.frameLayout("HDMAR_Step2_GenerateRigs_FL", label = "Step 2: Generate Rigs", 
        #     width = 400, 
        #     marginWidth = 5,
        #     collapsable = True, 
        #     collapse = False) 

        # #Create a checkbox
        # cmds.checkBox(label = "Delete Locators", align = "right")
        
        # #Create a row with buttons
        # cmds.rowLayout(numberOfColumns = 2)
        # cmds.button(label = "Generate Rig")
        # cmds.button(label = "?", backgroundColor = DarkGray) 


        ### End of Step 2 Disabled code
        
        #Done with this tab so we'll go back to the mainTab Holder
        cmds.setParent("HDMAR_TabMaster_TL")
        
        ##EXTRAS tab
        #We create the last tab. A columnlayout for extras (Additional tools and video tutorials)
        extrasLayout = cmds.columnLayout("HDMAR_ExtrasTab_CL")
               
        #framelayout for additional tools
        additionalToolsFrameLayout = cmds.frameLayout(label = "Additional Tools", 
            collapsable = True, 
            collapse = False, 
            width = 400) 
        
        #Tablike frame with darker background #1
        cmds.text(l = "  Rename Selected Module", 
            align = "left", 
            backgroundColor = DarkerGray, 
            height = 20)
        #rowlayout and Label and input
        cmds.rowLayout(numberOfColumns = 2, 
            columnWidth2 = (75, 65), 
            columnAlign = [(1, "left")])
        cmds.text(label = "New Name:")
        terrainNameUser = cmds.textField("HDMAR_renameOBJ_TF",text = "")
        cmds.setParent(additionalToolsFrameLayout)
        
        #rowlayout with 2 buttons
        cmds.rowLayout(numberOfColumns = 2)
        cmds.button(label = "Rename", command = self.renameOBJ)
        cmds.button(label = "?", backgroundColor = DarkGray) 
        cmds.setParent(additionalToolsFrameLayout)
        
        
        #Tablike frame with darker background #2
        cmds.text(label = "  Override Color", 
            align = "left", 
            backgroundColor = DarkerGray, 
            height = 20)
        #rowlayout and Label and input
        cmds.rowLayout(numberOfColumns = 2)
        cmds.colorSliderGrp("HDMAR_colorOverride_CSG", label = "Color", 
            rgb = (0, 0, 1), 
            columnAlign = [(1, "left"), (2, "left"), (3, "left")],
            changeCommand = self.newColorOverride)
        cmds.setParent(additionalToolsFrameLayout)

        #Tablike frame with darker background #3
        cmds.text(label = "  Delete Selected Control", 
            align = "left", 
            backgroundColor = DarkerGray, 
            height = 20)
        #rowlayout and Label and input
        cmds.rowLayout(numberOfColumns = 2)
        cmds.button(label = "Delete", backgroundColor = Red, command = self.deleteSelectedModule)
        cmds.button(label = "?", backgroundColor = DarkGray) 
        cmds.setParent(additionalToolsFrameLayout)
        cmds.separator(style = "none", height = 1)
                  
        #parent back up 
        cmds.setParent(extrasLayout)
        
        #Frame layout: Video Tutorials
        videoTutorialsFrameLayout = cmds.frameLayout("HDMAR_VideoTutorials_FL", label = "Video Tutorials", 
            collapsable = True, 
            collapse = False, 
            width = 400, 
            marginWidth = 5) 
        #small framelayouts 5

        self.createSubframeWithIconTextsButtonForVideoTutorials("Template", 
            DarkerGray,[["Introduction","youtube.com/watch?v=IsyXRSbqDZ4"],["Rig Generation","youtube.com/watch?v=MPzCYW8iG1Q"]])
        self.createSubframeWithIconTextsButtonForVideoTutorials("Master", 
            Blue,[["Main","youtube.com/watch?v=sEI9zn7nH38&t=17s"],["Lower Body","youtube.com/watch?v=sEI9zn7nH38&t=52s"],["Upper Body","youtube.com/watch?v=sEI9zn7nH38&t=70s"]])
        self.createSubframeWithIconTextsButtonForVideoTutorials("Body", 
            Purple,[["Door","youtube.com/watch?v=sEI9zn7nH38&t=122s"],["Steering","youtube.com/watch?v=sEI9zn7nH38&t=139s"]])
        self.createSubframeWithIconTextsButtonForVideoTutorials("Hook",
            Green,[["Bucket","youtube.com/watch?v=sEI9zn7nH38&t=158s"],["Arm","youtube.com/watch?v=sEI9zn7nH38&t=179s"],["Boom","youtube.com/watch?v=sEI9zn7nH38&t=200s"]])
        self.createSubframeWithIconTextsButtonForVideoTutorials("Track",
            Orange,[["Final Drive","youtube.com/watch?v=sEI9zn7nH38&t=237s"],["Rollers","youtube.com/watch?v=sEI9zn7nH38&t=246s"],["Front Idler","youtube.com/watch?v=sEI9zn7nH38&t=258s"],["Track","youtube.com/watch?v=sEI9zn7nH38&t=261s"]])
        
        #Done with this tab so we'll go back to the mainTab Holder
        cmds.setParent("HDMAR_TabMaster_TL")
        
        #We want to create the next tab (and name the first one)
        cmds.tabLayout("HDMAR_TabMaster_TL", edit = True, 
            tabLabel = (("HDMAR_TemplateTab_CL", "Template"), 
                        ("HDMAR_ManualTab_CL", "Manual"),
                        ("HDMAR_ExtrasTab_CL", "Extras")))
    

    # FUNCTIONS 

    def SetupSetLayoutInfo(self,*args):
        cmds.text("HDMAR_RIG_SmartSetup_Step_Title_TX",edit= True, label = self.smartSetupList[self.smartSetupListElement][0])
        cmds.iconTextButton("HDMAR_RIG_SmartSetup_Step_Icon_ITB",
					edit=True, 
					image1 = "%s%s"%(self.URL_ICON_PATH,self.smartSetupList[self.smartSetupListElement][1])) 
        cmds.text("HDMAR_RIG_SmartSetup_Step_Instruction1_TX",edit = True, label=self.smartSetupList[self.smartSetupListElement][2])
        cmds.text("HDMAR_RIG_SmartSetup_Step_Instruction2_TX",edit = True, label=self.smartSetupList[self.smartSetupListElement][3])
        cmds.button("HDMAR_RIG_SmartSetup_NextAction_BT",
                            edit=True,
                            label=self.smartSetupList[self.smartSetupListElement][6],
                            command=partial(self.NextStepWithFunction,
                            self.smartSetupList[self.smartSetupListElement][4],
                            self.smartSetupList[self.smartSetupListElement][5],
                            self.smartSetupList[self.smartSetupListElement][8])),
        
        if(self.smartSetupList[self.smartSetupListElement][7]!=0):
            cmds.button("HDMAR_RIG_SmartSetup_SecondAction_BT",edit=True,manage=True)
            cmds.button("HDMAR_RIG_SmartSetup_SecondAction_BT",
							edit=True,
							command=partial(self.JumpToSmartSetupElement,self.smartSetupList[self.smartSetupListElement][7]))
        else:
            cmds.button("HDMAR_RIG_SmartSetup_SecondAction_BT",edit=True,manage=False)


    # Function to create the skeleton of the smart setup
        
    def StartSmartSetup(self,*args):

				#Disable "Start Rig Smart setup button" and Enable Instruction Frame layout
        cmds.button("HDMAR_StartSmart_BT",edit =True, enable=False)
        cmds.frameLayout("HDMAR_GenerateRig_FL",edit=True,manage=True)

        self.SetupSetLayoutInfo()
				
		
    def JumpToSmartSetupElement(self,elementNumber,*args):
			self.smartSetupListElement = elementNumber
			self.SetupSetLayoutInfo()


    #This function performs 2 functions at once, especifically to setup the Main controller
    def SetupSmartMainController(self,*args):
        self.loadSelectedList("HDMAR_main_TFBG")
        self.createControlsButtonPress("main")   

    #Receive the action's function, it's string (Optional) you want done and the next step's function
    def NextStepWithFunction(self, actionFunction = "", actionFunctionString="", requireSelection = True, *args ):

        #Do not proceed of a selection is required to continue
        if requireSelection and len(cmds.ls(selection=True, type="transform")) == 0:
            cmds.confirmDialog(title='Step alert!', message="You must have a mesh selected to continue.",defaultButton="OK")
            return
        
        if actionFunction != "":
            if actionFunctionString == "":
                    exec("self.%s()"%actionFunction)
            else:
                    exec("self.%s('%s')"%(actionFunction,actionFunctionString))
		
		#Hide the setup if it's the last step
        print "self.smartSetupListElement before adding: %s" %self.smartSetupListElement
		

        if self.smartSetupListElement+1 >= len(self.smartSetupList):
			cmds.button("HDMAR_StartSmart_BT",edit =True, enable=True)
			cmds.frameLayout("HDMAR_GenerateRig_FL",edit=True, manage=False)
			self.smartSetupListElement = 0
        else:
            self.smartSetupListElement += 1
            self.SetupSetLayoutInfo()


    #This function gets all the objects selected and puts the first and last elements as front and final driver
    #Anything in between is set as a roller
    #If the list only has 0 or 1 element it'll return false, otherwise it will return true
    def SetupGetWheelLists(self,*args):

        wheelsList = cmds.ls(selection = True, type = "transform") #from our selection, we get all transform objects

        wheelsListLength = len(wheelsList)

        if wheelsListLength <= 1:
            return
        
        #front wheel & final drive
        self.loadSelectedList("HDMAR_frontIdler_TFBG",[wheelsList[0]])
        self.loadSelectedList("HDMAR_finalDrive_TFBG",[wheelsList[wheelsListLength-1]])
        
        if wheelsListLength > 2:
            del wheelsList[-1]
            del wheelsList[0]
            self.loadSelectedList("HDMAR_rollers_TFBG",wheelsList)

            cmds.columnLayout("HDMAR_track_smartSetup_additionalOptions_CL",edit=True,manage=True)

        return

    def SetupPassValuesAndCreateTrack(self,*args):
        cmds.columnLayout("HDMAR_track_smartSetup_additionalOptions_CL",edit=True,manage=False)
        cmds.textFieldGrp("HDMAR_track_left_TFG", edit = True, text = cmds.textFieldGrp("HDMAR_track_smartSetup_left_TFG", query = True, text = True))
        cmds.textFieldGrp("HDMAR_track_right_TFG", edit = True, text = cmds.textFieldGrp("HDMAR_track_smartSetup_right_TFG", query = True, text = True))
        cmds.optionMenu("HDMAR_track_treadAmount_OM", edit = True, value = cmds.optionMenu("HDMAR_track_treadAmount_OM_smartSetup", query = True, value= True))
        cmds.checkBox("HDMAR_track_left_right_chb", edit = True, value = cmds.checkBox("HDMAR_track_smartSetup_left_right_chb", query = True, value = True))
        self.checkCanCreateTrack()

   
    #Function to toggle Manual options    
    def toggleManualOptions(self, columnLayout, itemTextButton):
        isManaged = cmds.layout(columnLayout, query = True, manage = True)
        if isManaged:
            cmds.layout(columnLayout, edit = True, manage = False)
        else:
            cmds.layout(columnLayout, edit = True, manage = True)
            
        isItemSelected = cmds.iconTextButton(itemTextButton, query = True, backgroundColor = True)[0] > 0.3
        LightGray = [0.4,0.4,0.4]
        Grey = [0.275, 0.275, 0.275]
        if isItemSelected:
            cmds.iconTextButton(itemTextButton, edit = True, backgroundColor = Grey)
        else:
            cmds.iconTextButton(itemTextButton, edit = True, backgroundColor = LightGray)

    #Function to toggle Manual options    
    def toggleCOGOptions(self, *args):
        isToggled = cmds.checkBox("HDMAR_upperBody_Limit_CB", query = True, value = True)
        if isToggled:
            cmds.layout("HDMAR_upperBody_RotationLimit_FSG", edit = True, manage = True)
            cmds.layout("HDMAR_upperBody_TranslationLimit_FSG", edit = True, manage = True)
        else:
            cmds.layout("HDMAR_upperBody_RotationLimit_FSG", edit = True, manage = False)
            cmds.layout("HDMAR_upperBody_TranslationLimit_FSG", edit = True, manage = False)



    def toggleMirrorTrackOptions(self, additionalText="", *args):
        isToggled = cmds.checkBox("HDMAR_track%s_left_right_chb"%additionalText, query = True, value = True)
        if isToggled:
            cmds.layout("HDMAR_track%s_left_TFG"%additionalText, edit = True, manage = True)
            cmds.layout("HDMAR_track%s_right_TFG"%additionalText, edit = True, manage = True)
            cmds.text("HDMAR_track%s_mirror_explain_tx"%additionalText,edit = True, manage = True)
            
        else:
            cmds.layout("HDMAR_track%s_left_TFG"%additionalText, edit = True, manage = False)
            cmds.layout("HDMAR_track%s_right_TFG"%additionalText, edit = True, manage = False)
            cmds.text("HDMAR_track%s_mirror_explain_tx"%additionalText,edit = True, manage = False)
    

            

    def createSubframeWithIconTextsButtonAndOptions(self,name,frameColor,buttonList): #name = "master", frameColor = "(0.15, 0.25, 0.55)", button list: [["root","root.png"]]
        
        #Step 1. get parent layout name

        # Master FrameLayout
        parent = "HDMAR_Step1_AddLocator_FL"
        cmds.setParent(parent)

        #step 2. create frame layout (sub frame layout)
        cmds.frameLayout("HDMAR_%s_FL"%name, label = name, 
            collapsable = True, 
            collapse = False, 
            backgroundColor = frameColor)
        #Step 3. create a column layout
        cmds.columnLayout("HDMAR_%s_CL"%name)
        #Step 4. create a row layout of X icon text buttons
        rlLength = len(buttonList)
        cmds.rowLayout("HDMAR_%s_RL"%name, numberOfColumns = rlLength+2)  #account for how many columns the rowlayout has
        for iconTextButton in buttonList: #each element is a list of a name and an image URL
            self.createIconTextButtonForManualSetup(iconTextButton[0], iconTextButton[1])  #name, imageURL
        cmds.columnLayout("HDMAR_%s_CL_extra"%name) #We create a column layout to contain any extras
        cmds.setParent("..")
        DarkGray = [0.2, 0.2, 0.2]

        #Step 5. create a column layout with the custom options for the button
        cmds.setParent("HDMAR_%s_CL"%name)
        cmds.columnLayout("HDMAR_%s_options_CL"%name)
        for optionColumn in buttonList: #each element is a list of a name and an image URL
            cmds.columnLayout("HDMAR_%s_individualOption_CL"%(optionColumn[0]), 
                backgroundColor = DarkGray, 
                manage = False)
            self.createManualOptions(optionColumn[0],optionColumn[2]) #column layout name for itself
            cmds.setParent("HDMAR_%s_options_CL"%name) 
            cmds.separator(style = "none", height = 1)  
        
        cmds.setParent(parent)


    def createManualOptions(self,name,tutorialLink = ""):

        cmds.columnLayout("HDMAR_%s_individualOptionContainer_CL"%name)
        cmds.rowLayout(numberOfColumns = 2)
        cmds.separator(style = "none", width = 180)
        cmds.text(label = "%s%s"%(name[0].upper(), name[1:]), align = "center")
        cmds.setParent("..")
        cmds.separator(style = "none", height = 5)

        # cmds.rowLayout("HDMAR_%s_optionsRename_RL", numberOfColumns = 2)
        # cmds.checkBox("HDMAR_%s_chb"%name, label = "Rename", align = "left")
        # cmds.textField("HDMAR_%s_rename_TF"%name ,text = "", width = 300)
        # cmds.setParent("..")

        print  "HDMAR_%s_TFBG"%name
        cmds.textFieldButtonGrp("HDMAR_%s_TFBG"%name, label = "Target Geometry",                 
            buttonLabel = "Load Selected",
            buttonCommand = partial(self.loadSelectedList, "HDMAR_%s_TFBG"%name),
            editable = False, 
            columnWidth = [[1, 90], [2, 200]])
        LightGray = [0.4, 0.4, 0.4]
        DarkGray = [0.2, 0.2, 0.2]

        #Create rowlayout for create controls and tutorial button
        cmds.rowLayout(numberOfColumns = 2)
        cmds.button("HDMAR_%s_btn"%name, label = "Create Controls", 
            backgroundColor = LightGray, 
            enable = False, 
            command = partial(self.createControlsButtonPress, name)) 
        cmds.button("HDMAR_%s_question_BT"%name, label = "?", backgroundColor = DarkGray, command = partial(self.showLink, tutorialLink)) #unhardcode color
        cmds.setParent("..")
       

    def loadSelectedList(self, textField, listSelected = [], *args):
        if len(listSelected) == 0:
            listSelected = cmds.ls(selection = True,type = "transform") #from our selection, we get all transform objects
        cmds.textFieldButtonGrp("%s"%textField, edit = True, text = ', '.join(listSelected),forceChangeCommand = True) # Get the Text fieldbutton group, edit the text to have all the transform object names
        self.isButtonPressable("%s_btn"%textField[:-5], "%s"%textField)
        self.getPlacerClass(textField[6:-5], listSelected)
        
    def checkIfGeometryAvailable(self, textField):
        text = cmds.textFieldButtonGrp(textField, query = True, text = True)
        if len(text) > 0:
            return True
        else:
            return False
    
    def isButtonPressable(self, button, textField):
        if self.checkIfGeometryAvailable(textField):
            cmds.button(button, edit = True,enable = True)
        else:           
            cmds.button(button, edit = True, enable = False)
        #Special check for enabling and disabling the IK Button
        self.checkIKButton("hookIK_btn")
    
    def createControlsButtonPress(self, name, *args):
        self.getAnimClass(name)
        cmds.button("HDMAR_%s_btn"%name, edit = True, enable = False) 
        cmds.textFieldButtonGrp("HDMAR_%s_TFBG"%name, edit = True, enable = False) 
        self.checkIKButton("hookIK_btn")#my edit
        
    def checkIKButton(self, button):
        if self.checkHookCanIK():
            cmds.button(button, edit = True, enable = True)
        else:           
            cmds.button(button, edit = True, enable = False)
        
    def IKButtonPressed(self, *args):
        cmds.button("hookIK_btn", 
			edit = True,
            enable = False)
        self.createhookIK()
	
    def COGExtraOptions(self, columnLayout, returnToParent):
        cmds.setParent(columnLayout)
        cmds.rowLayout(numberOfColumns = 2)
        # cmds.checkBox("%s_chb"%labelObjectName, label = "Rename", align = "left")
        cmds.textField("%s_rename_TF"%labelObjectName, text = "", width = 200)
        cmds.setParent(returnToParent)

    def generateTracksCheckboxAndTreadAmount(self,additionalText = "",*args):

        cmds.checkBox("HDMAR_track%s_left_right_chb"%additionalText, label = "Assign left and right tracks on X axis?", align = "left",changeCommand = partial(self.toggleMirrorTrackOptions,additionalText))

        cmds.separator(height = 5)
        cmds.text("HDMAR_track%s_mirror_explain_tx"%additionalText,label="Search and replace a name from each side of the track", manage = False)

        #Following fields are only seen when the 2 track checkbox is enabled
        cmds.textFieldGrp("HDMAR_track%s_left_TFG"%additionalText, label = "Left Search: ",                 
            manage = False, 
            text = "left",
            columnWidth = [[1, 109], [2, 256]])

        cmds.textFieldGrp("HDMAR_track%s_right_TFG"%additionalText, label = "Right Replace: ",                 
            manage = False, 
            text = "right",
            columnWidth = [[1, 118], [2, 247]])

        cmds.intSliderGrp("HDMAR_track%s_treadAmount_ISG"%additionalText, label = "Amount of treads",
            field = True, 
            minValue = 8, 
            maxValue = 100, 
            fieldMinValue = 0, 
            fieldMaxValue = 300, 
            value = 140, 
            columnWidth = [[1, 90], [2, 100], [3, 175]], 
            columnAlign = [[1, "left"]],
            manage = True)
        
        #Option Menu. In demo it has multiple templates, but for our innitial project it only has Excavator as an option
        cmds.optionMenu("HDMAR_track_treadAmount_OM%s"%additionalText, label = "Select Template: ")
        cmds.separator(style = "none", height = 5)  
        cmds.menuItem(label = "tread1")  

    #Function runs when adding a Wheel on the tread. When both Final drive and Front idler

    def CheckTreadWheels(self, fromSmartSetup = False, *args):
        finalDriveValue = cmds.textFieldButtonGrp("HDMAR_finalDrive_TFBG", query = True, text = True )
        frontIdlerValue = cmds.textFieldButtonGrp("HDMAR_frontIdler_TFBG", query = True, text = True )
        print "Checking..."
        print "final drive: %s"%finalDriveValue
        print "front idler: %s"%frontIdlerValue 

        if finalDriveValue != "" and frontIdlerValue != "":
            cmds.iconTextButton("HDMAR_track_ITB", edit = True, enable = True)
        else:
            cmds.iconTextButton("HDMAR_track_ITB", edit = True, enable = False)
    
    #Function to create icon text buttons for the "Manual" tab in Step 1
    def createIconTextButtonForManualSetup(self, label, imageURL): #Add itemTextButton & columnlayout
        cmds.iconTextButton("HDMAR_%s_ITB"%label, label = label, 
            style = "iconAndTextVertical", 
            image1 = "%s%s"%(self.URL_ICON_PATH,imageURL), 
            width = 60, height = 80, 
            scaleIcon = True,
            backgroundColor = (0.275,0.275,0.275),
            command = partial(self.toggleManualOptions, 
                "HDMAR_%s_individualOption_CL"%label, 
                "HDMAR_%s_ITB"%label)) 


    def createSubframeWithIconTextsButtonForVideoTutorials(self, name, frameColor, buttonList): #name = "master", frameColor = "(0.15, 0.25, 0.55)", button list: [["root","youtube.com"]]
        #Step 1. get parent layout name

        # Master FrameLayout
        parent = "HDMAR_VideoTutorials_FL"
        cmds.setParent(parent)

        #step 2. create frame layout (sub frame layout)
        cmds.frameLayout("HDMAR_video_%s_FL"%name, label = name, 
            collapsable = True, 
            collapse = False, 
            backgroundColor = frameColor)
        #Step 3. create a column layout
        cmds.columnLayout("HDMAR_video_%s_CL"%name)
        #Step 4. create a row layout of X icon text buttons
        for button in buttonList: #each element is a list of a name and an image URL
            self.createHelpButtonWithLink(button[0], button[1])
        
        cmds.setParent(parent)
    

    #Function to Create help buttons for the "Extras" tab
    def createHelpButtonWithLink(self,buttonLabel, link = "youtube.com"):
        LighterGray = [0.5, 0.5, 0.5]
        cmds.button(label = buttonLabel, 
            backgroundColor = LighterGray, 
            width = 380,
            command = partial(self.showLink, link))
    
    def showLink(self, link, *args):
        cmds.showHelp("http://www.%s"%link, absolute = True)
        

### Windy Functions

    def newColorOverride(self, *args):
        # get the object list
        colorChange = cmds.ls( sl = True)
        colorShapes = cmds.listRelatives( colorChange, shapes = True )
        #get the color
        newColor = cmds.colorSliderGrp("HDMAR_colorOverride_CSG", query=True, rgb=True)
        # check if anything selected
        if colorShapes == None:
            cmds.warning("Please select an object.")
        # change color
        else:
            for curve in colorShapes:
                cmds.setAttr("%s.overrideRGBColors"%curve,1)
                cmds.setAttr("%s.overrideColorRGB"%curve, newColor[0],newColor[1],newColor[2])
  
                
    def renameOBJ(self, *args):
        userNewName = cmds.textField("HDMAR_renameOBJ_TF", query = True, text = True)
        listed_renameItem = cmds.ls(sl = True)
        # check if user selected more than one obj
        if len(listed_renameItem) > 1:
            cmds.warning("You can only select one control at a time.")
        # check if user selected anything
        elif listed_renameItem == None:
            cmds.warning("Please select an object.")
        # check if user typed anything
        elif userNewName == "":
            cmds.warning("Please type a new name.")    
        else:
            # get the name of selected obj
            listed_splitedName = listed_renameItem[0].split("_",1)
            # define related item list to find
            #look_for = ["%s_ctr"%listed_splitedName[0],"%s_ctr_shp*"%listed_splitedName[0],"%s_ctr_grp"%listed_splitedName[0],"%s_geo"%listed_splitedName[0],"%s_jnt"%listed_splitedName[0],"%s_jnt_prtCt"%listed_splitedName[0]]
            #allRelatedItem = cmds.ls(look_for)
            allRelatedItem = cmds.ls("%s*"%listed_splitedName[0],type = ("nurbsCurve","transform","mesh","joint","parentConstraint","shadingEngine"))
            
            # rename all related objects
            for obj in allRelatedItem:
                # split names
                obj_splitedName = obj.split("_",1)
                # rename to user input
                cmds.rename(obj, userNewName + "_%s"%obj_splitedName[1], ignoreShape = True)
                #self.checkNameDuplicates()
            return              
    
    def checkNameDuplicates(self,*args):
        # check if there are any duplicates
        # get all obj in the scene        
        allOBJ = cmds.ls(tr=True,sn=True,fl=True)
        for obj in allOBJ:
            # find duplicated names
            if (obj.find("|")>=0):
                # get the last name
                repeated_splitedName = obj.split("|")
                # rename duplicates
                newName = cmds.rename(obj,"%s_#"%repeated_splitedName[-1])
                return newName
            else:
                pass
                
    def deleteSelectedModule(self,*args):
        # get selected item
        deleteItem = cmds.ls(sl = True)

        if len(deleteItem) > 1:
            cmds.warning("You can only select one control at a time.")
        elif deleteItem == None:
            cmds.warning("Please select the control you want to delete.")
        else:
            # get part name
            delete_part = deleteItem[0].split("_",1)
            # get related joint
            delete_joint = cmds.ls("%s*"%delete_part[0],type = "joint")
            delete_prtCt = cmds.ls("%s*"%delete_part[0],type = "parentConstraint")
            # DELETE JOINTS
            if delete_joint == []:
                pass
            else:
                # delete joint and constraint
                cmds.removeJoint(delete_joint)
                cmds.delete(delete_prtCt)
            
            # get the relative items
            delete_parent = cmds.listRelatives(deleteItem, parent = True)
            topParent = cmds.listRelatives(delete_parent, parent = True)
            botChildren = cmds.listRelatives(deleteItem, children = True, type = "transform")
            multiChildren = cmds.listRelatives(delete_parent, children = True)

            # DELETE CONTROL GROUP
            # for end items: door, steering, bucket
            if botChildren == None:
                cmds.delete(delete_parent)
            # for mid items with multiple children: move, lowerBody, upperBody
            elif 5>len(multiChildren)>1:
                cmds.ungroup(multiChildren, world = True)
                cmds.delete(delete_parent)
                childrenItem = cmds.ls(sl = True)
                cmds.parent(childrenItem, topParent)
            # for end items with multiple children: leftTrack, rightTrack
            elif len(multiChildren)>=5:
                cmds.delete(delete_parent)
            # for mid items with one children: boom, arm
            else:    
                cmds.ungroup(world = True)
                cmds.delete(delete_parent)
                cmds.parent(botChildren, topParent)
                
            return
    
if __name__ == "__main__":       
    UiInstance = MainUI()
    UiInstance.createUI()


