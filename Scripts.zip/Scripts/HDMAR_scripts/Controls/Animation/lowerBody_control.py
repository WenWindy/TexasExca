'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By windy wen
#With assistance from BCIT
#creates curves for the lowerBody (the user will animate with)
#Location ...
'''

import maya.cmds as cmds

#what does it look like
class LowerBody_control():
    def create(self):

        print "create shape"
        
        #create 2 circles
        circleInner = cmds.circle( name = "lowerBody", normalX = 0, normalY = 1, normalZ = 0, radius = 15)
        circleOutter = cmds.circle( name = "lowerBody", normalX = 0, normalY = 1, normalZ = 0, radius = 15.3)

        # create text 1
        innerText1 = cmds.textCurves(name = "lowerBody", font = "Calibri", text = "LowerBody Control")
        cmds.rotate(-90, -90, 0, relative = True)
        cmds.scale(2, 2, 2, relative = True)
        cmds.CenterPivot()
        # create text 2
        innerText2 = cmds.textCurves(name = "lowerBody", font = "Calibri", text = "LowerBody Control")
        cmds.rotate(-90, 90, 0, relative = True)
        cmds.scale(2, 2, 2, relative = True)
        cmds.CenterPivot()        

        # match transform to circle
        cmds.matchTransform(innerText1, innerText2 ,circleInner, position = True)
        
        # transform texts
        cmds.move(-12, 0, 0, innerText1, relative = True)
        cmds.move(12, 0, 0, innerText2, relative = True)
        
        # delete makeTextCurve
        cmds.delete(innerText1[1], innerText2[1])
        
        # freeze rotation
        cmds.makeIdentity(innerText1[0], innerText2[0], apply = True)       

        #get shapes
        textCurves1 = cmds.listRelatives(innerText1[0], allDescendents = True, type = "nurbsCurve", fullPath = True)
        textCurves2 = cmds.listRelatives(innerText2[0], allDescendents = True, type = "nurbsCurve", fullPath = True)
        circleCurvesInner = cmds.listRelatives(circleInner[0], shapes = True, fullPath = True)
        circleCurvesOutter = cmds.listRelatives(circleOutter[0], shapes = True, fullPath = True)
        
        #combine texts
        ctrlGrp = cmds.group(name = "control", world = True, empty = True)
        cmds.parent(textCurves1, textCurves2, circleCurvesInner, circleCurvesOutter, ctrlGrp, shape = True, relative = True)                    
        cmds.delete(circleInner, circleOutter, innerText1[0], innerText2[0])
        

        for curve in cmds.listRelatives(ctrlGrp, allDescendents = True, type = "nurbsCurve", fullPath = True):

            cmds.setAttr("%s.overrideEnabled"%curve, 1)
            cmds.setAttr("%s.overrideColor"%curve, 18)
        
        cmds.select(clear = True)
        return ctrlGrp


#test your code, please comment this to avoid doubles in the final build
if __name__ == "__main__":

    classInstance = LowerBody_control()
    classInstance.create()