'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By windy Wen
#With assistance from BCIT
#creates curves for the Main/Root (the user will animate with)
#Location ...
'''

import maya.cmds as cmds

#what does it look like
class Main_control():
    def create(self):
        print "create shape"
        
        #create 2 circles
        circleInner = cmds.circle( name = "Main", normal=(0,1,0), radius = 19.7)
        circleOutter = cmds.circle( name = "Main", normal=(0,1,0), radius = 21)

        # create arrow
        arrowShape = cmds.curve( name= "arrow", degree = 3, point = [
            (-5, 0, -19),
            (-4.222222, 0, -21.230769),
            (-2.666667, 0, -25.692308),
            (-14.333333, 0, -22.230769),
            (0, 0, -29.384615),
            (14.333333, 0, -22.230769),
            (2.666667, 0, -25.692308),
            (4.222222, 0, -21.230769),
            (5, 0, -19)] )

        # create text 1
        innerText1 = cmds.textCurves(name = "Main", font = "Calibri", text = "Main")
        cmds.rotate(-90, 0, 0, relative = True)
        cmds.scale(3, 3, 3, relative = True)
        cmds.CenterPivot()        
        # create text 2
        innerText2 = cmds.textCurves(name = "Main", font = "Calibri", text = "Ctrl")
        cmds.rotate(-90, 0, 0, relative = True)
        cmds.scale(3, 3, 3, relative = True)
        cmds.CenterPivot()        
        # match transform to circle
        cmds.matchTransform(innerText1, innerText2 ,circleInner, position = True)        
        # transform texts
        cmds.move(0, 0, -25, innerText1, relative = True)
        cmds.move(0, 0, -22.5, innerText2, relative = True)        
        # delete makeTextCurve
        cmds.delete(innerText1[1], innerText2[1])        
        # freeze rotation
        cmds.makeIdentity(innerText1[0], innerText2[0], apply = True)       

        #get shapes
        textCurves1 = cmds.listRelatives(innerText1[0], allDescendents = True, type = "nurbsCurve", fullPath = True)
        textCurves2 = cmds.listRelatives(innerText2[0], allDescendents = True, type = "nurbsCurve", fullPath = True)
        circleCurvesInner = cmds.listRelatives(circleInner[0], shapes = True, fullPath = True)
        circleCurvesOutter = cmds.listRelatives(circleOutter[0], shapes = True, fullPath = True)
        arrowCurve = cmds.listRelatives(arrowShape, shapes = True )
        
        #combine curves
        ctrlGrp = cmds.group(name = "control", world = True, empty = True)
        cmds.parent(textCurves1, textCurves2, circleCurvesInner, circleCurvesOutter, arrowCurve, ctrlGrp, shape = True, relative = True)                    
        cmds.delete(circleInner, circleOutter, arrowShape, innerText1[0], innerText2[0])

        for curve in cmds.listRelatives(ctrlGrp, allDescendents = True, type = "nurbsCurve", fullPath = True):
            cmds.setAttr("%s.overrideEnabled"%curve, 1)
            cmds.setAttr("%s.overrideColor"%curve, 6)
        # ??? this loop can only work for once
        
        cmds.DeleteHistory()
        cmds.select(clear = True)
        return ctrlGrp
        

#test your code, please comment this to avoid doubles in the final build
if __name__ == "__main__":
    classInstance = Main_control()
    classInstance.create()