'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By windy wen
#With assistance from BCIT
#creates curves for the Main/right track (the user will animate with)
#Location ...
'''
import maya.cmds as cmds

#what does it look like
class RightTrack_control():
    def create(self):
        print "create shape"

        # create arrow
        arrowShape = cmds.curve( name= "arrow", degree = 1, point = [
            (0, 1, -5),
            (0, 2, -5),
            (0, 0, -7),
            (0, -2, -5),
            (0, -1, -5),
            (0, -1, 5),
            (0, -2, 5),
            (0, 0, 7),
            (0, 2, 5),
            (0, 1, 5),
            (0, 1, -5)] )
            
        arrowShape2 = cmds.curve( name= "arrow", degree = 1, point = [
            (0, 0.85, -5.15),
            (0, 1.7, -5.15),
            (0, 0, -6.85),
            (0, -1.7, -5.15),
            (0, -0.85, -5.15),
            (0, -0.85, 5.15),
            (0, -1.7, 5.15),
            (0, 0, 6.85),
            (0, 1.7, 5.15),
            (0, 0.85, 5.15),
            (0, 0.85, -5.15)] )

        # create text 
        innerText1 = cmds.textCurves(name = "Track", font = "Calibri", text = "Right Track Ctrl")
        cmds.rotate(0, 90, 0, relative = True)
        cmds.scale(1.75, 1.75, 1.75, relative = True)
        cmds.CenterPivot()        
        # match transform to circle
        cmds.matchTransform(innerText1 , arrowShape , position = True)              
        # delete makeTextCurve
        cmds.delete(innerText1[1])        
        # freeze rotation
        cmds.makeIdentity(innerText1[0], apply = True)       

        #get shapes
        textCurves1 = cmds.listRelatives(innerText1[0], allDescendents = True, type = "nurbsCurve", fullPath = True)
        arrowCurve = cmds.listRelatives(arrowShape, shapes = True )
        arrowCurve2 = cmds.listRelatives(arrowShape2, shapes = True )
        
        #combine curves
        ctrlGrp = cmds.group(name = "control", world = True, empty = True)
        cmds.parent( textCurves1, arrowCurve, arrowCurve2, ctrlGrp, shape = True, relative = True)                    
        cmds.delete( innerText1[0], arrowShape, arrowShape2)

        for curve in cmds.listRelatives(ctrlGrp, allDescendents = True, type = "nurbsCurve", fullPath = True):
            cmds.setAttr("%s.overrideEnabled"%curve, 1)
            cmds.setAttr("%s.overrideColor"%curve, 13)
        
        cmds.DeleteHistory()
        cmds.select(clear = True)
        return ctrlGrp
        

#test your code, please comment this to avoid doubles in the final build
if __name__ == "__main__":
    classInstance = RightTrack_control()
    classInstance.create()