'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By windy wen
#With assistance from BCIT
#creates curves for the Hook (boom, Boom, bucket) (the user will animate with)
#Location ...
'''
import maya.cmds as cmds

class Bucket_control():
    def create(self):
        print "create shape"
        #create circle
        circleInner = cmds.circle( name = "Bucket", normalX = 1, normalY = 0, normalZ = 0, radius = 2.2)
        circleOutter = cmds.circle( name = "Bucket", normalX = 1, normalY = 0, normalZ = 0, radius = 2.2*1.1)
        # create text
        innerText1 = cmds.textCurves(name = "Bucket", font = "Calibri", text = "Bucket")
        cmds.rotate(0, 90, 0, relative = True)
        cmds.CenterPivot()
        innerText2 = cmds.textCurves(name = "rotator", font = "Calibri", text = "Rotator")
        cmds.rotate(0, 90, 0, relative = True)
        cmds.CenterPivot()
        cmds.matchTransform(innerText1, innerText2, circleInner, position = True)
        cmds.setAttr("BucketShape.ty", 0.3)
        cmds.setAttr("rotatorShape.ty", -0.7)
        cmds.delete(innerText1[1], innerText2[1]) 
        #freeze transforms
        cmds.makeIdentity(innerText1[0], innerText2[0], apply = True)
        #get shapes
        textCurves1 = cmds.listRelatives(innerText1[0], allDescendents = True, type = "nurbsCurve", fullPath = True)
        textCurves2 = cmds.listRelatives(innerText2[0], allDescendents = True, type = "nurbsCurve", fullPath = True)
        circleCurvesInner = cmds.listRelatives(circleInner[0], shapes = True, fullPath = True)
        circleCurvesOutter = cmds.listRelatives(circleOutter[0], shapes = True, fullPath = True)
        #combine texts
        ctrlGrp = cmds.group(name = "control", world = True, empty = True)
        cmds.parent(textCurves1, textCurves2, circleCurvesInner, circleCurvesOutter, ctrlGrp, shape = True, relative = True)                    
        cmds.delete(circleInner, circleOutter, innerText1[0], innerText2[0])
        
        for curve in cmds.listRelatives(ctrlGrp, allDescendents = True, type = "nurbsCurve", fullPath = True):
            cmds.setAttr("%s.overrideEnabled"%curve, 1)
            cmds.setAttr("%s.overrideColor"%curve, 14)
        
        cmds.select(clear = True)
        return ctrlGrp
        

#test your code, please comment this to avoid doubles in the final build
if __name__ == "__main__":
    classInstance = Bucket_control()
    classInstance.create()