'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By windy wen
#With assistance from BCIT
#creates curves for the Hook (boom, arm, bucket) (the user will animate with)
#Location ...
'''

import maya.cmds as cmds

#what does it look like
class createTextCurve():
    def __init__(self,name,text,radius):
        self.name = name
        self.text_ = text
        self.radius = radius
        
    def create(self):
        name = self.name 
        text = self.text_ 
        radius = self.radius
    
        #create circles
        CircleInner=cmds.circle(name="%sControlInner"%name,normalX=1,normalY=0,normalZ=0,radius=radius)
        CircleOutter=cmds.circle(name="%sControlOuter"%name,normalX=1,normalY=0,normalZ=0,radius=radius*1.1)
        
        #create text
        InnerText=cmds.textCurves(name="%sCtrl"%name,font="Calibri",text=text) #Wen's question: how to change font size?
        cmds.setAttr("%sCtrlShape.ry"%name,90)
        cmds.CenterPivot()
        cmds.matchTransform(InnerText,CircleInner,position=True)
        cmds.delete(InnerText[1]) 
        #freeze transforms
        cmds.makeIdentity(InnerText[0], apply=True)
        
        #combine texts
        CtrlGrp=cmds.group(name="%sCtrlGrp"%name)
        TextCurves=cmds.listRelatives(InnerText[0], allDescendents = True, type = "nurbsCurve", fullPath = True)
        CircleCurvesInner=cmds.listRelatives(CircleInner[0], allDescendents = True, type = "nurbsCurve", fullPath = True)
        CircleCurvesOutter=cmds.listRelatives(CircleOutter[0], allDescendents = True, type = "nurbsCurve", fullPath = True)
        cmds.parent(TextCurves,CircleCurvesInner,CircleCurvesOutter, CtrlGrp, shape = True, relative = True)              
        cmds.select(CircleInner,CircleOutter)
        cmds.DeleteHistory()        
        cmds.delete(CircleInner,CircleOutter,InnerText[0])
        
        # create group for tranformation
        Ctrl=cmds.group(empty=True,name="%sCtrl"%name)
        cmds.parent(CtrlGrp,Ctrl)  
        cmds.select(clear = True)
        
        # Lock Attributes
        cmds.setAttr("%sCtrl.ry"%name,lock=True,keyable=False,channelBox=False)
        cmds.setAttr("%sCtrl.rz"%name,lock=True,keyable=False,channelBox=False)
        cmds.setAttr("%sCtrl.sx"%name,lock=True,keyable=False,channelBox=False)
        cmds.setAttr("%sCtrl.sy"%name,lock=True,keyable=False,channelBox=False)
        cmds.setAttr("%sCtrl.sz"%name,lock=True,keyable=False,channelBox=False)
        # Wen's Question: Boom,Arm,Bucket controls need to lock different attributes, how can I define each?
        
        # Color override 
        cmds.setAttr("%sCtrl.overrideEnabled"%name,1)
        cmds.setAttr("%sCtrl.overrideColor"%name,14)
        
        #cmds.select(CtrlGrp)
        return CtrlGrp  # Wen's Question: Still don't know what this does...
        

#test your code, please comment this to avoid doubles in the final build

# User Input Mockup
UserInput_Boom="Boom"

# Create Class Instances
'''BoomControl = Hook_control()
BoomControl.createTextCurve(UserInput_Boom,"%s \n Rotator"%UserInput_Boom,2.7) 

ArmControl=Hook_control()
ArmControl.createTextCurve("Arm","Arm \n Rotator",2.2)

BucketControl=Hook_control()
BucketControl.createTextCurve("Bucket","Bucket \n Rotator",2.2)'''

#Wen's Question: how to delete the weird squares '\n' creates?