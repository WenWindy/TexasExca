'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By windy wen
#With assistance from BCIT
#creates curves for the Hook (boom, arm, bucket) (the user will animate with)
#Location ...
'''
import maya.cmds as cmds

#what does it look like
class FrontIdler_placeHolder():
    def create(self):
        print "create shape"
            
        #create circle
        circleInner = cmds.circle( name = "Track", normalX = 1, normalY = 0, normalZ = 0, radius = 1)
        circleOutter = cmds.circle( name = "Track", normalX = 0, normalY = 1, normalZ = 0, radius = 1)
        circleZ = cmds.circle( name = "Track", normalX = 0, normalY = 0, normalZ = 1, radius = 1)
        # create text
        innerText1 = cmds.textCurves(name = "Track", font = "Calibri", text = "Front Idler Locator")
        cmds.rotate(0, 90, 0, relative = True)
        cmds.scale(0.3, 0.3, 0.3, relative = True)
        cmds.CenterPivot()
        # match transform
        cmds.matchTransform(innerText1, circleInner, position = True)
        # delete make curve
        cmds.delete(innerText1[1]) 
        #freeze transforms
        cmds.makeIdentity(innerText1[0], apply = True)
        
        
        #get shapes
        textCurves1 = cmds.listRelatives(innerText1[0], allDescendents = True, type = "nurbsCurve", fullPath = True)
        circleCurvesInner = cmds.listRelatives(circleInner[0], shapes = True, fullPath = True)
        circleCurvesOutter = cmds.listRelatives(circleOutter[0], shapes = True, fullPath = True)
        circleCurvesZ = cmds.listRelatives(circleZ[0], shapes = True, fullPath = True)
       
        #combine curves
        ctrlGrp = cmds.group(name = "Front Idler Locator", world = True, empty = True)
        cmds.parent(textCurves1, circleCurvesInner, circleCurvesOutter, circleCurvesZ, ctrlGrp, shape = True, relative = True)                    
        cmds.delete(circleInner, circleOutter, circleZ, innerText1[0])
        
        #add locatershape in ctrlGrp
        cmds.spaceLocator(name = "ctrlGrpCtrlLoc1")
        cmds.select("ctrlGrpCtrlLoc1Shape", ctrlGrp)
        cmds.parent(relative = True, shape = True)
        cmds.delete("ctrlGrpCtrlLoc1")
        
        #increase overall size
        cmds.select(ctrlGrp)
        cmds.scale(3.0, 3.0, 3.0, relative = True)
        cmds.makeIdentity( apply = True)
        
        # override color
        for curve in cmds.listRelatives(ctrlGrp, allDescendents = True, type = "nurbsCurve", fullPath = True):
            cmds.setAttr("%s.overrideEnabled"%curve, 1)
            cmds.setAttr("%s.overrideColor"%curve, 13)
        
        cmds.select(clear = True)
        return ctrlGrp
        

#test your code, please comment this to avoid doubles in the final build
if __name__ == "__main__":
    classInstance = FrontIdler_placeHolder()
    classInstance.create()