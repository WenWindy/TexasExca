'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By ...
#With assistance from BCIT
#creates shapes for a wheel (the user will position to model for getting placement)
#Location ...
'''

import maya.cmds as cmds

#what does it look like
class Wheel_placeHolder():
    def create(self):
        pass