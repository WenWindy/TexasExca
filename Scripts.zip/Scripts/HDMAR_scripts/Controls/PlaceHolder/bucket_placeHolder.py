'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By windy wen
#With assistance from BCIT
#creates shapes for a Hook (Boom, arm, bucket) (the user will position to model for getting placement)
#Location ...
'''

import maya.cmds as cmds

#what does it look like
class Bucket_placeHolder():
    def create(self):
        
        #create text
        innerText = cmds.textCurves(name = "BucketLoc", font = "Calibri", text = "Bucket Locator")   
        cmds.scale(0.17, 0.17, 0.17, relative = True)
        cmds.rotate(0, 90, 0, relative = True)
        cmds.CenterPivot()
        
        cmds.delete(innerText[1])         
        #freeze transforms
        cmds.makeIdentity(innerText[0], apply = True)
        #get shapes
        textCurves = cmds.listRelatives(innerText[0], allDescendents = True, type = "nurbsCurve", fullPath = True)


        #createcube
        cubeShape = cmds.polyCube(name = "cubeShape")
        
        #selectEdges
        cmds.select("cubeShape.e[1]", "cubeShape.e[5]", "cubeShape.e[0]", "cubeShape.e[4]")
        #convert edge to curve
        cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve1")

        cmds.select("cubeShape.e[2]", "cubeShape.e[8]", "cubeShape.e[3]", "cubeShape.e[9]")
        cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve2")

        cmds.select("cubeShape.e[7]")
        cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve3")

        cmds.select("cubeShape.e[11]")
        cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve4")

        cmds.select("cubeShape.e[10]")
        cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve5")

        cmds.select("cubeShape.e[6]")
        cmds.polyToCurve(form= 2, degree = 1, conformToSmoothMeshPreview = 0, name = "ctrlGrpCtrlCurve6")
        
        #creategroup
        Bucket_Loc = cmds.group( em=True, name='Bucket_Locator')
        
        #combine curves to group
        cmds.select("ctrlGrpCtrlCurve1Shape", "ctrlGrpCtrlCurve1Shape", "ctrlGrpCtrlCurve2Shape", "ctrlGrpCtrlCurve3Shape", "ctrlGrpCtrlCurve4Shape", "ctrlGrpCtrlCurve5Shape", "ctrlGrpCtrlCurve6Shape", textCurves, Bucket_Loc)
        
        cmds.parent(relative = True, shape = True)
        
        #add locatershape in grp
        cmds.spaceLocator(name = "ctrlGrpCtrlLoc1")
        cmds.select("ctrlGrpCtrlLoc1Shape", Bucket_Loc)
        cmds.parent(relative = True, shape = True)
        
        #delete Cube and empty groups
        cmds.select(cubeShape, "ctrlGrpCtrlCurve1", "ctrlGrpCtrlCurve2", "ctrlGrpCtrlCurve3", "ctrlGrpCtrlCurve4", "ctrlGrpCtrlCurve5", "ctrlGrpCtrlCurve6", "ctrlGrpCtrlLoc1","BucketLocShape")
        cmds.delete()
        
        #increase Overall Size
        cmds.select(Bucket_Loc)
        cmds.scale(2.0, 2.0, 2.0, relative = True)
        cmds.makeIdentity( apply = True, scale = True)
        
        #rename the shape nodes for code reuse
        cmds.select(Bucket_Loc)
        ctrlGrpShapes = cmds.ls(sl=True, dag=True, shapes=True)
        for shape in ctrlGrpShapes:
            cmds.rename(shape, "{0}Shape".format(cmds.listRelatives(shape, parent=True)[0]))

        #override color
        for curve in cmds.listRelatives(Bucket_Loc, allDescendents = True, type = "nurbsCurve", fullPath = True):
                    cmds.setAttr("%s.overrideEnabled"%curve, 1)
                    cmds.setAttr("%s.overrideColor"%curve, 14)
        
        return Bucket_Loc
        
#test your code, please comment this to avoid doubles in the final build
if __name__ == "__main__":
    classInstance = Bucket_placeHolder()
    classInstance.create()

