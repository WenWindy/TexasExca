'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By windy wen
#With assistance from BCIT
#creates shapes for a Steering (the user will position to model for getting placement)
#Location ...
'''

import maya.cmds as cmds

#what does it look like
class Steering_placeHolder():
    def create(self):
        
        print "create shape"
        
        #create 2 circles
        circleInner = cmds.circle( name = "Steering", normalX = 0, normalY = 1, normalZ = 0, radius = 1)
        circleOutter = cmds.circle( name = "Steering", normalX = 0, normalY = 1, normalZ = 0, radius = 1.1)

        # create cross
        
        curve1 = cmds.curve( name= "linear", degree = 1, point = [(0, 0, -1), (0, 0, 1)])
        curve2 = cmds.curve( name= "linear", degree = 1, point = [(-1, 0, 0), (1, 0, 0)])
        curve3 = cmds.curve( name= "linear", degree = 1, point = [(0, -0.5, 0), (0, 0.5, 0)])

        # create text 1
        innerText1 = cmds.textCurves(name = "Steering", font = "Calibri", text = "Left")
        cmds.rotate(-90, 0, 0, relative = True)
        cmds.scale(0.3, 0.3, 0.3, relative = True)
        cmds.CenterPivot()
        # create text 2
        innerText2 = cmds.textCurves(name = "Steering", font = "Calibri", text = "Right")
        cmds.rotate(-90, 0, 0, relative = True)
        cmds.scale(0.3, 0.3, 0.3, relative = True)
        cmds.CenterPivot()        

        # match transform to circle
        cmds.matchTransform(innerText1, innerText2 ,circleInner, position = True)
        
        # transform texts
        cmds.move(-0.6, 0, 0, innerText1, relative = True)
        cmds.move(0.6, 0, 0, innerText2, relative = True)
        
        # delete makeTextCurve
        cmds.delete(innerText1[1], innerText2[1])
        
        # freeze rotation
        cmds.makeIdentity(innerText1[0], innerText2[0], apply = True)       

        #get shapes
        textCurves1 = cmds.listRelatives(innerText1[0], allDescendents = True, type = "nurbsCurve", fullPath = True)
        textCurves2 = cmds.listRelatives(innerText2[0], allDescendents = True, type = "nurbsCurve", fullPath = True)
        circleCurvesInner = cmds.listRelatives(circleInner[0], shapes = True, fullPath = True)
        circleCurvesOutter = cmds.listRelatives(circleOutter[0], shapes = True, fullPath = True)
        curve1Curve = cmds.listRelatives(curve1, shapes = True)
        curve2Curve = cmds.listRelatives(curve2, shapes = True)
        curve3Curve = cmds.listRelatives(curve3, shapes = True)
    
        #combine texts
        ctrlGrp = cmds.group(name = "control", world = True, empty = True)
        cmds.parent(textCurves1, textCurves2, 
                    circleCurvesInner, circleCurvesOutter, 
                    curve1Curve, curve2Curve, curve3Curve,
                    ctrlGrp, shape = True, relative = True)                    
        cmds.delete(circleInner, circleOutter, 
                    innerText1[0], innerText2[0],
                    curve1, curve2, curve3)

        # override color
        for curve in cmds.listRelatives(ctrlGrp, allDescendents = True, type = "nurbsCurve", fullPath = True):
            cmds.setAttr("%s.overrideEnabled"%curve, 1)
            cmds.setAttr("%s.overrideColor"%curve, 9)
        
        cmds.select(clear = True)
        return ctrlGrp
        
#test your code, please comment this to avoid doubles in the final build
if __name__ == "__main__":
    classInstance = Steering_placeHolder()
    classInstance.create()