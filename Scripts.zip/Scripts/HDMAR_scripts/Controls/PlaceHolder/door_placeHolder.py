'''
#Team Rodolfo (tyler, rodolfo, windy)
#Heavy Duty Machine Auto-Rigger (HDMAR) Project
#Script By Tyler Millossi
#With assistance from BCIT
#creates shapes for a door (the user will position to model for getting placement)
#Location ...
'''

import maya.cmds as cmds

#what does it look like
class Door_placeHolder():
    def create(self):
        print "create shape"
        curve1 = cmds.curve(degree = 1, 
            point = [(0.07257, 0, -0.0546559), 
            (0.0525062, 0, -0.0632546),
            (0.0338755, 0, -0.0783025), 
            (0.0245602, 0, -0.0969331 ),
            (0.0202608, 0, -0.11628), 
            (0.0173946, 0, -0.490326 ),
            (0.0238436, 0, -0.507524), 
            (0.28324, 0, -0.834993 ),
            (0.321217, 0, -0.869388 ),
            (0.364928, 0, -0.899484 ),
            (0.42082, 0, -0.923847), 
            (0.470979, 0, -0.938895 ),
            (0.493909, 0, -0.938178 ),
            (0.940328, 0, -0.943194 ),
            (0.963258, 0, -0.934596 ),
            (0.969707, 0, -0.92528 ),
            (0.980456, 0, -0.905217), 
            (0.984039, 0, -0.112698 ),
            (0.97329, 0, -0.0912006), 
            (0.961109, 0, -0.0711368 ),
            (0.928863, 0, -0.056089 ),
            (0.0732865, 0, -0.0553724)])
        curve2 = cmds.curve(degree = 1, 
            point = [(0.163715, 0, -0.529656), 
            (0.888882, 0, -0.530775), 
            (0.886644, 0, -0.846357), 
            (0.491607, 0, -0.845238 ),
            (0.443486, 0, -0.834047 ),
            (0.396485, 0, -0.813903 ),
            (0.355079, 0, -0.774735 ),
            (0.164834, 0, -0.528537)])
        
        curve3 = cmds.curve(degree = 1, 
            point = [(0.727948, 0, -0.395639), 
            (0.841246, 0, -0.394475 ),
            (0.849783, 0, -0.398743 ),
            (0.857155, 0, -0.407667 ),
            (0.857543, 0, -0.425903 ),
            (0.852499, 0, -0.433275 ),
            (0.844351, 0, -0.437932), 
            (0.730664, 0, -0.44026), 
            (0.718636, 0, -0.434439), 
            (0.713204, 0, -0.424739 ),
            (0.713204, 0, -0.412323), 
            (0.718248, 0, -0.403011), 
            (0.727948, 0, -0.395251)])

        curve4 = cmds.curve(degree = 1, point = [
            (0.557497, 0, -0.560445 ),
            (0.595828, 0, -0.55848 ),
            (0.757998, 0, -0.8209 ),
            (0.715735, 0, -0.8209 ),
            (0.556514, 0, -0.55848 ),])

        curve5 = cmds.curve(degree = 1, point = [
            (0.629245, 0, -0.55848 ),
            (0.691164, 0, -0.556514 ),
            (0.851369, 0, -0.819917 ),
            (0.785518, 0, -0.8209 ),
            (0.628262, 0, -0.559462),])
            
        group = cmds.group(name = "control", world = True, empty = True)
        allCurves = [curve1, curve2, curve3, curve4, curve5]
        i = 1
        for curve in allCurves:
            shape = cmds.listRelatives(curve, shapes = True)
            cmds.select(shape, group)
            cmds.parent(relative = True, shape = True) 
            cmds.rename(shape[0], "control_shp%s"%i)#maybe not needed
            i += 1
        cmds.delete(allCurves)
        
        cmds.move(0, 0, -0.5, "%s.scalePivot"%group, "%s.rotatePivot"%group, absolute=True)
        cmds.select(group)
        cmds.move(0, 0, 0.5)
        cmds.makeIdentity(apply = True)
        cmds.DeleteHistory()
        cmds.select(clear = True)
        
        return group

#test your code, please comment this to avoid doubles in the final build
#classInstance = Door_placeHolder()
#classInstance.create()